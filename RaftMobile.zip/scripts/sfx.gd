extends Node

const RATE = 11025

var sounds = {}
var players = []
var amb_player = null
var sfx_vol = 0.85
var amb_vol = 0.55
var reel_cd = 0.0


func _ready():
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in range(6):
		var p = AudioStreamPlayer.new()
		add_child(p)
		players.append(p)
	_build_sounds()
	amb_player = AudioStreamPlayer.new()
	if sounds.has("ocean_loop"):
		amb_player.stream = sounds["ocean_loop"]
	amb_player.volume_db = _to_db(amb_vol * 0.28)
	add_child(amb_player)
	amb_player.play()


func _process(delta):
	if reel_cd > 0.0:
		reel_cd = max(0.0, reel_cd - delta)


func _to_db(lin):
	if lin <= 0.001:
		return -80.0
	return clamp(linear_to_db(float(lin)), -60.0, 6.0)


func update_volumes(sv, av):
	sfx_vol = clamp(float(sv), 0.0, 1.0)
	amb_vol = clamp(float(av), 0.0, 1.0)
	if amb_player != null:
		if amb_vol <= 0.01:
			amb_player.volume_db = -80.0
		else:
			amb_player.volume_db = _to_db(amb_vol * 0.28)
			if not amb_player.playing:
				amb_player.play()


func play(id, pitch = 1.0, vol_mul = 1.0):
	if sfx_vol <= 0.01 or players.is_empty() or not sounds.has(id):
		return
	var chosen = players[0]
	for p in players:
		if not p.playing:
			chosen = p
			break
	chosen.stream = sounds[id]
	chosen.pitch_scale = max(0.3, float(pitch) + randf_range(-0.04, 0.04))
	chosen.volume_db = _to_db(sfx_vol * float(vol_mul))
	chosen.play()


func play_reel_tick():
	if reel_cd > 0.0:
		return
	reel_cd = 0.09
	play("reel", randf_range(0.95, 1.12), 0.65)


func _make_tone(f_start, f_end, duration, noise_mix, gain, loop_on = false):
	var count = max(16, int(float(RATE) * float(duration)))
	var data = PackedByteArray()
	data.resize(count * 2)
	var ph = 0.0
	for i in range(count):
		var prog = float(i) / float(count)
		var env = sin(prog * PI) if loop_on else ((1.0 - prog) * (1.0 - prog))
		var freq = lerp(float(f_start), float(f_end), prog)
		ph += TAU * freq / float(RATE)
		var wave_val = sin(ph) * (1.0 - float(noise_mix)) + randf_range(-1.0, 1.0) * float(noise_mix)
		var pcm = clampi(roundi(wave_val * env * float(gain) * 26000.0), -32000, 32000)
		data.encode_s16(i * 2, pcm)
	var wav = AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BIT
	wav.mix_rate = RATE
	wav.stereo = false
	wav.data = data
	if loop_on:
		wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
		wav.loop_begin = 0
		wav.loop_end = count
	return wav


func _build_sounds():
	sounds["hook_throw"] = _make_tone(240.0, 560.0, 0.20, 0.45, 0.70)
	sounds["splash"] = _make_tone(320.0, 110.0, 0.30, 0.75, 0.80)
	sounds["snag"] = _make_tone(580.0, 820.0, 0.14, 0.20, 0.75)
	sounds["reel"] = _make_tone(400.0, 350.0, 0.04, 0.35, 0.55)
	sounds["pickup"] = _make_tone(520.0, 780.0, 0.18, 0.05, 0.70)
	sounds["spear"] = _make_tone(380.0, 140.0, 0.15, 0.50, 0.70)
	sounds["hit"] = _make_tone(180.0, 65.0, 0.20, 0.35, 0.85)
	sounds["bite"] = _make_tone(140.0, 50.0, 0.28, 0.55, 0.85)
	sounds["build"] = _make_tone(260.0, 320.0, 0.20, 0.30, 0.80)
	sounds["consume"] = _make_tone(300.0, 440.0, 0.20, 0.15, 0.65)
	sounds["ui"] = _make_tone(660.0, 720.0, 0.035, 0.05, 0.55)
	sounds["ocean_loop"] = _make_tone(95.0, 115.0, 2.20, 0.88, 0.32, true)
