extends Node

const RATE = 22050

var sounds = {}
var players = []
var amb_player = null
var rain_player = null
var sfx_vol = 0.90
var amb_vol = 0.65
var reel_cd = 0.0
var wake_cd = 0.0


func _ready():
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in range(8):
		var p = AudioStreamPlayer.new()
		p.bus = "Master"
		add_child(p)
		players.append(p)
	_build_sounds()

	amb_player = AudioStreamPlayer.new()
	amb_player.bus = "Master"
	if sounds.has("ocean_loop"):
		amb_player.stream = sounds["ocean_loop"]
	amb_player.volume_db = _to_db(amb_vol * 0.55)
	add_child(amb_player)
	amb_player.play()

	rain_player = AudioStreamPlayer.new()
	rain_player.bus = "Master"
	if sounds.has("rain_loop"):
		rain_player.stream = sounds["rain_loop"]
	rain_player.volume_db = -80.0
	add_child(rain_player)


func _process(delta):
	if reel_cd > 0.0:
		reel_cd = max(0.0, reel_cd - delta)
	if wake_cd > 0.0:
		wake_cd = max(0.0, wake_cd - delta)


func _to_db(lin):
	if lin <= 0.001:
		return -80.0
	# Boosted by +3.5 dB so procedural WAV streams sound crisp and loud on Android phone speakers
	return clamp(linear_to_db(float(lin)) + 3.5, -50.0, 6.0)


func update_volumes(sv, av):
	sfx_vol = clamp(float(sv), 0.0, 1.0)
	amb_vol = clamp(float(av), 0.0, 1.0)
	if amb_player != null:
		if amb_vol <= 0.01:
			amb_player.volume_db = -80.0
		else:
			amb_player.volume_db = _to_db(amb_vol * 0.55)
			if not amb_player.playing:
				amb_player.play()


func set_rain_intensity(intensity):
	if rain_player == null:
		return
	var v = clamp(float(intensity) * amb_vol, 0.0, 1.0)
	if v <= 0.02:
		if rain_player.playing:
			rain_player.stop()
	else:
		rain_player.volume_db = _to_db(v * 0.65)
		if not rain_player.playing:
			rain_player.play()


func play(id, pitch = 1.0, vol_mul = 1.0):
	if sfx_vol <= 0.01 or players.is_empty() or not sounds.has(id):
		return
	var chosen = players[0]
	for p in players:
		if not p.playing:
			chosen = p
			break
	chosen.stream = sounds[id]
	chosen.pitch_scale = max(0.3, float(pitch) + randf_range(-0.04, 0.04))
	chosen.volume_db = _to_db(sfx_vol * float(vol_mul))
	chosen.play()


func play_reel_tick():
	if reel_cd > 0.0:
		return
	reel_cd = 0.085
	play("reel", randf_range(0.95, 1.15), 0.78)


func play_wake_tick():
	if wake_cd > 0.0:
		return
	wake_cd = 0.48
	play("paddle", randf_range(0.88, 1.06), 0.45)


func _make_tone(f_start, f_end, duration, noise_mix, gain, loop_on = false):
	var count = max(32, int(float(RATE) * float(duration)))
	var data = PackedByteArray()
	data.resize(count * 2)
	var ph = 0.0
	var ph2 = 0.0
	var filt = 0.0
	for i in range(count):
		var prog = float(i) / float(count)
		var env = sin(prog * PI) if loop_on else pow(1.0 - prog, 1.45)
		if not loop_on and prog < 0.04:
			env *= (prog / 0.04)
		var freq = lerp(float(f_start), float(f_end), prog)
		ph += TAU * freq / float(RATE)
		ph2 += TAU * (freq * 1.5) / float(RATE)
		var tone_v = (sin(ph) * 0.75 + sin(ph2) * 0.25)
		var raw_n = randf_range(-1.0, 1.0)
		filt = lerp(filt, raw_n, 0.32)
		var wave_val = tone_v * (1.0 - float(noise_mix)) + filt * float(noise_mix)
		var pcm = clampi(roundi(wave_val * env * float(gain) * 30500.0), -32500, 32500)
		data.encode_s16(i * 2, pcm)
	var wav = AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BIT
	wav.mix_rate = RATE
	wav.stereo = false
	wav.data = data
	if loop_on:
		wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
		wav.loop_begin = 0
		wav.loop_end = count
	return wav


func _build_sounds():
	sounds["hook_throw"] = _make_tone(260.0, 620.0, 0.22, 0.42, 0.90)
	sounds["splash"] = _make_tone(340.0, 95.0, 0.34, 0.78, 0.95)
	sounds["snag"] = _make_tone(580.0, 880.0, 0.16, 0.18, 0.90)
	sounds["reel"] = _make_tone(440.0, 360.0, 0.045, 0.30, 0.75)
	sounds["pickup"] = _make_tone(540.0, 860.0, 0.19, 0.05, 0.88)
	sounds["spear"] = _make_tone(400.0, 140.0, 0.16, 0.48, 0.88)
	sounds["bow_shoot"] = _make_tone(520.0, 220.0, 0.18, 0.32, 0.90)
	sounds["paddle"] = _make_tone(220.0, 110.0, 0.28, 0.72, 0.82)
	sounds["hit"] = _make_tone(190.0, 65.0, 0.22, 0.38, 0.95)
	sounds["bite"] = _make_tone(150.0, 48.0, 0.30, 0.58, 0.96)
	sounds["build"] = _make_tone(280.0, 360.0, 0.20, 0.28, 0.92)
	sounds["repair"] = _make_tone(360.0, 520.0, 0.18, 0.20, 0.90)
	sounds["consume"] = _make_tone(320.0, 480.0, 0.22, 0.14, 0.85)
	sounds["seagull"] = _make_tone(920.0, 640.0, 0.26, 0.18, 0.80)
	sounds["sleep"] = _make_tone(280.0, 420.0, 0.45, 0.08, 0.80)
	sounds["ui"] = _make_tone(680.0, 760.0, 0.04, 0.04, 0.75)
	sounds["ocean_loop"] = _make_tone(95.0, 118.0, 2.40, 0.88, 0.48, true)
	sounds["rain_loop"] = _make_tone(420.0, 380.0, 1.80, 0.95, 0.52, true)
