extends Node

const MIX_RATE = 22050

var sounds = {}
var players = []
var amb_player = null
var sfx_vol = 0.85
var amb_vol = 0.55
var reel_cd = 0.0


func _ready():
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build_all_sounds()
	for i in range(8):
		var p = AudioStreamPlayer.new()
		add_child(p)
		players.append(p)
	amb_player = AudioStreamPlayer.new()
	amb_player.stream = sounds["ocean_loop"]
	amb_player.volume_db = _lin_to_db(amb_vol * 0.32)
	add_child(amb_player)
	amb_player.play()


func _process(delta):
	if reel_cd > 0.0:
		reel_cd = max(0.0, reel_cd - delta)


func _lin_to_db(v):
	if v <= 0.001:
		return -80.0
	return clamp(20.0 * log(v) / log(10.0), -60.0, 6.0)


func update_volumes(s_vol, a_vol):
	sfx_vol = clamp(s_vol, 0.0, 1.0)
	amb_vol = clamp(a_vol, 0.0, 1.0)
	if amb_player != null:
		if amb_vol <= 0.01:
			amb_player.volume_db = -80.0
		else:
			amb_player.volume_db = _lin_to_db(amb_vol * 0.32)
			if not amb_player.playing:
				amb_player.play()


func play(id, pitch = 1.0, vol_mul = 1.0):
	if sfx_vol <= 0.01 or not sounds.has(id):
		return
	var chosen = players[0]
	for p in players:
		if not p.playing:
			chosen = p
			break
	chosen.stream = sounds[id]
	chosen.pitch_scale = max(0.2, pitch + randf_range(-0.04, 0.04))
	chosen.volume_db = _lin_to_db(sfx_vol * vol_mul)
	chosen.play()


func play_reel_tick():
	if reel_cd > 0.0:
		return
	reel_cd = 0.09
	play("reel", randf_range(0.95, 1.12), 0.65)


func _make_wav(samples, loop = false):
	var n = samples.size()
	var bytes = PackedByteArray()
	bytes.resize(n * 2)
	for i in range(n):
		var s = int(clamp(samples[i], -1.0, 1.0) * 32767.0)
		if s < 0:
			s += 65536
		bytes[i * 2] = s & 0xFF
		bytes[i * 2 + 1] = (s >> 8) & 0xFF
	var wav = AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BIT
	wav.mix_rate = MIX_RATE
	wav.stereo = false
	wav.data = bytes
	if loop:
		wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
		wav.loop_begin = 0
		wav.loop_end = n
	return wav


func _build_all_sounds():
	# 1. Hook Throw (whoosh + rope unspool click)
	var s_throw = PackedFloat32Array()
	var n_throw = int(MIX_RATE * 0.28)
	s_throw.resize(n_throw)
	var ph = 0.0
	for i in range(n_throw):
		var t = float(i) / float(MIX_RATE)
		var env = sin(clamp(t / 0.28, 0.0, 1.0) * PI)
		var freq = lerp(220.0, 620.0, t / 0.28)
		ph += TAU * freq / float(MIX_RATE)
		var noise = randf_range(-1.0, 1.0) * 0.55
		var click = 0.35 if (i % 420 < 35) else 0.0
		s_throw[i] = (sin(ph) * 0.35 + noise + click) * env * 0.65
	sounds["hook_throw"] = _make_wav(s_throw)

	# 2. Water Splash
	var s_splash = PackedFloat32Array()
	var n_splash = int(MIX_RATE * 0.42)
	s_splash.resize(n_splash)
	var lp = 0.0
	for i in range(n_splash):
		var t = float(i) / float(MIX_RATE)
		var env = exp(-t * 7.5)
		var raw = randf_range(-1.0, 1.0)
		var alpha = clamp(0.18 + 0.35 * sin(t * 38.0), 0.05, 0.6)
		lp = lp + alpha * (raw - lp)
		var bubble = sin(TAU * (280.0 + 180.0 * sin(t * 45.0)) * t) * 0.3
		s_splash[i] = (lp * 0.8 + bubble) * env * 0.75
	sounds["splash"] = _make_wav(s_splash)

	# 3. Hook Snag (metallic latch onto debris)
	var s_snag = PackedFloat32Array()
	var n_snag = int(MIX_RATE * 0.18)
	s_snag.resize(n_snag)
	for i in range(n_snag):
		var t = float(i) / float(MIX_RATE)
		var env = exp(-t * 18.0)
		var tone = sin(TAU * 520.0 * t) * 0.5 + sin(TAU * 880.0 * t) * 0.4 + randf_range(-0.3, 0.3)
		s_snag[i] = tone * env * 0.7
	sounds["snag"] = _make_wav(s_snag)

	# 4. Reel Tick (mechanical rope ratchet)
	var s_reel = PackedFloat32Array()
	var n_reel = int(MIX_RATE * 0.045)
	s_reel.resize(n_reel)
	for i in range(n_reel):
		var t = float(i) / float(MIX_RATE)
		var env = exp(-t * 55.0)
		var tone = sin(TAU * 390.0 * t) * 0.6 + randf_range(-0.5, 0.5) * 0.4
		s_reel[i] = tone * env * 0.55
	sounds["reel"] = _make_wav(s_reel)

	# 5. Item Pickup (retro pixel chime)
	var s_pick = PackedFloat32Array()
	var n_pick = int(MIX_RATE * 0.22)
	s_pick.resize(n_pick)
	for i in range(n_pick):
		var t = float(i) / float(MIX_RATE)
		var env = exp(-t * 10.0)
		var f = 523.25 if t < 0.08 else (659.25 if t < 0.15 else 783.99)
		var sq = 0.45 if sin(TAU * f * t) >= 0.0 else -0.45
		s_pick[i] = (sq + sin(TAU * f * t) * 0.4) * env * 0.55
	sounds["pickup"] = _make_wav(s_pick)

	# 6. Spear Thrust
	var s_spear = PackedFloat32Array()
	var n_spear = int(MIX_RATE * 0.18)
	s_spear.resize(n_spear)
	for i in range(n_spear):
		var t = float(i) / float(MIX_RATE)
		var env = sin(clamp(t / 0.18, 0.0, 1.0) * PI)
		var f = lerp(420.0, 160.0, t / 0.18)
		s_spear[i] = (sin(TAU * f * t) * 0.45 + randf_range(-0.6, 0.6) * 0.55) * env * 0.65
	sounds["spear"] = _make_wav(s_spear)

	# 7. Hit Shark
	var s_hit = PackedFloat32Array()
	var n_hit = int(MIX_RATE * 0.24)
	s_hit.resize(n_hit)
	for i in range(n_hit):
		var t = float(i) / float(MIX_RATE)
		var env = exp(-t * 14.0)
		var f = lerp(180.0, 65.0, t / 0.24)
		s_hit[i] = (sin(TAU * f * t) * 0.7 + randf_range(-0.5, 0.5) * 0.4) * env * 0.8
	sounds["hit"] = _make_wav(s_hit)

	# 8. Shark Bite (crunch + low danger thud)
	var s_bite = PackedFloat32Array()
	var n_bite = int(MIX_RATE * 0.38)
	s_bite.resize(n_bite)
	for i in range(n_bite):
		var t = float(i) / float(MIX_RATE)
		var env = exp(-t * 6.5)
		var crunch = randf_range(-1.0, 1.0) * (0.7 if (i % 180 < 90) else 0.2)
		var bass = sin(TAU * lerp(140.0, 52.0, t / 0.38) * t) * 0.75
		s_bite[i] = (crunch + bass) * env * 0.85
	sounds["bite"] = _make_wav(s_bite)

	# 9. Build / Hammer Wood
	var s_build = PackedFloat32Array()
	var n_build = int(MIX_RATE * 0.26)
	s_build.resize(n_build)
	for i in range(n_build):
		var t = float(i) / float(MIX_RATE)
		var t2 = t if t < 0.13 else (t - 0.13)
		var env = exp(-t2 * 24.0)
		var f = 240.0 if t < 0.13 else 310.0
		s_build[i] = (sin(TAU * f * t2) * 0.65 + randf_range(-0.4, 0.4) * 0.35) * env * 0.75
	sounds["build"] = _make_wav(s_build)

	# 10. Eat / Drink
	var s_eat = PackedFloat32Array()
	var n_eat = int(MIX_RATE * 0.25)
	s_eat.resize(n_eat)
	for i in range(n_eat):
		var t = float(i) / float(MIX_RATE)
		var env = sin(clamp(t / 0.25, 0.0, 1.0) * PI)
		var f = 320.0 + 140.0 * sin(t * 36.0)
		s_eat[i] = (sin(TAU * f * t) * 0.55 + randf_range(-0.2, 0.2)) * env * 0.6
	sounds["consume"] = _make_wav(s_eat)

	# 11. UI Button Click (crisp pixel tap)
	var s_ui = PackedFloat32Array()
	var n_ui = int(MIX_RATE * 0.035)
	s_ui.resize(n_ui)
	for i in range(n_ui):
		var t = float(i) / float(MIX_RATE)
		var env = exp(-t * 70.0)
		s_ui[i] = sin(TAU * 720.0 * t) * env * 0.5
	sounds["ui"] = _make_wav(s_ui)

	# 12. Ocean Waves Loop (4.0 seconds gentle surf wash)
	var s_ocean = PackedFloat32Array()
	var n_ocean = int(MIX_RATE * 4.0)
	s_ocean.resize(n_ocean)
	var brown = 0.0
	for i in range(n_ocean):
		var t = float(i) / float(MIX_RATE)
		var white = randf_range(-1.0, 1.0)
		brown = clamp((brown + white * 0.04) * 0.985, -1.0, 1.0)
		var swell = 0.55 + 0.45 * sin(TAU * t / 4.0)
		s_ocean[i] = brown * swell * 0.45
	sounds["ocean_loop"] = _make_wav(s_ocean, true)
