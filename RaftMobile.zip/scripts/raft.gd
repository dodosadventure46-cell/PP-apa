extends Node3D

const OceanScript = preload("res://scripts/ocean.gd")
const PixelUI = preload("res://scripts/pixel_ui.gd")

const TILE = 3.0
const INVALID = Vector2i(99999, 99999)
const DIRS = [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]

var tiles = {}
var hp = {}
var prop_nodes = []
var ghost
var ghost_cell = INVALID
var ghost_valid = false
var mat_wood
var mat_log
var mat_rope
var mat_ok
var mat_bad
var sail_mesh = null
var flag_mesh = null
var purifier_count = 0
var grill_count = 0
var lantern_count = 0
var frame_motion = Vector3.ZERO


func _ready():
	_make_materials()
	for c in [Vector2i(0, 0), Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1)]:
		add_tile(c)
	_make_mast()
	_make_ghost()


func rebuild_from_game_state():
	for c in tiles.keys():
		if tiles[c] != null and is_instance_valid(tiles[c]):
			tiles[c].queue_free()
	tiles.clear()
	hp.clear()
	for p in prop_nodes:
		if p != null and is_instance_valid(p):
			p.queue_free()
	prop_nodes.clear()
	purifier_count = 0
	grill_count = 0
	lantern_count = 0

	var list = Game.saved_tiles
	if list == null or list.is_empty():
		list = [[0, 0], [1, 0], [0, 1], [1, 1]]
	for pair in list:
		if pair is Array and pair.size() >= 2:
			add_tile(Vector2i(int(pair[0]), int(pair[1])))
		elif pair is Vector2i:
			add_tile(pair)
	if tiles.is_empty():
		for c in [Vector2i(0, 0), Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1)]:
			add_tile(c)

	for i in range(Game.purifiers):
		add_purifier_visual()
	for i in range(Game.grills):
		add_grill_visual()
	for i in range(Game.lanterns):
		add_lantern_visual()
	set_ghost_active(false)


func export_tile_list():
	var out = []
	for c in tiles.keys():
		out.append([c.x, c.y])
	return out


func _physics_process(delta):
	var prev_pos = global_position
	var c_local = _local_center()
	var cx = c_local.x
	var cz = c_local.z
	var span = 2.4

	# Sample ocean wave height at 4 corners + center of the raft footprint
	var h_front = OceanScript.height(cx, cz - span)
	var h_back = OceanScript.height(cx, cz + span)
	var h_left = OceanScript.height(cx - span, cz)
	var h_right = OceanScript.height(cx + span, cz)
	var h_mid = OceanScript.height(cx, cz)

	var avg_h = (h_front + h_back + h_left + h_right + h_mid * 2.0) / 6.0
	var surge = OceanScript.current_surge()

	var target_pos = Vector3(surge.x, avg_h - 0.02, surge.y)
	global_position = global_position.lerp(target_pos, clamp(delta * 8.5, 0.0, 1.0))
	frame_motion = global_position - prev_pos

	# Calculate hydrostatic wave slope (pitch & roll) scaled by wave strength
	var slope_pitch = (h_back - h_front) / (span * 2.0)
	var slope_roll = (h_left - h_right) / (span * 2.0)
	var target_pitch = clamp(atan(slope_pitch) * 1.65, -0.30, 0.30)
	var target_roll = clamp(atan(slope_roll) * 1.65, -0.30, 0.30)
	var target_yaw = sin(OceanScript.wave_time * 0.58) * 0.045 * OceanScript.wave_amp

	rotation.x = lerp(rotation.x, target_pitch, clamp(delta * 7.5, 0.0, 1.0))
	rotation.z = lerp(rotation.z, target_roll, clamp(delta * 7.5, 0.0, 1.0))
	rotation.y = lerp(rotation.y, target_yaw, clamp(delta * 5.0, 0.0, 1.0))


func _process(_delta):
	var t = OceanScript.wave_time
	var w_amp = OceanScript.wave_amp
	if sail_mesh != null:
		sail_mesh.rotation.y = sin(t * 1.8) * 0.09 * w_amp
	if flag_mesh != null:
		flag_mesh.rotation.y = sin(t * 4.5) * 0.26 * w_amp


func is_point_over_raft(wx, wz):
	var lp = to_local(Vector3(wx, global_position.y, wz))
	var cell = Vector2i(roundi(lp.x / TILE), roundi(lp.z / TILE))
	if tiles.has(cell):
		return true
	var info = nearest_tile_info(Vector3(wx, 0, wz))
	return info["dist"] <= 0.25


func get_deck_height_at(wx, wz):
	var lp = to_local(Vector3(wx, global_position.y, wz))
	lp.y = 0.31
	var gp = to_global(lp)
	return gp.y


func _make_materials():
	# Pure TEXTURE_FILTER_NEAREST (no mipmap blurring!) for razor-sharp pixel-art 3D wood planks
	mat_wood = PixelUI.make_3d_mat("wood_deck", Vector3(0.5, 0.5, 0.5), true, 0.0, 0.88)
	mat_log = PixelUI.make_3d_mat("wood_log", Vector3(1.0, 2.0, 1.0), false, 0.0, 0.90)
	mat_rope = PixelUI.make_3d_mat("rope_3d", Vector3(1.0, 1.0, 1.0), false, 0.0, 0.88)

	mat_ok = StandardMaterial3D.new()
	mat_ok.albedo_color = Color(0.2, 1.0, 0.35, 0.48)
	mat_ok.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat_ok.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED

	mat_bad = StandardMaterial3D.new()
	mat_bad.albedo_color = Color(1.0, 0.22, 0.2, 0.48)
	mat_bad.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat_bad.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED


func _local_center():
	var s = Vector3.ZERO
	for c in tiles:
		s += Vector3(c.x * TILE, 0.0, c.y * TILE)
	return s / float(max(1, tiles.size()))


func cell_pos(cell):
	return to_global(Vector3(cell.x * TILE, 0.0, cell.y * TILE))


func add_tile(cell):
	if tiles.has(cell):
		return
	var body = StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	var shape = CollisionShape3D.new()
	var box = BoxShape3D.new()
	box.size = Vector3(TILE + 0.04, 0.4, TILE + 0.04)
	shape.shape = box
	body.add_child(shape)

	var mi = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = Vector3(TILE - 0.06, 0.22, TILE - 0.06)
	mi.mesh = bm
	mi.material_override = mat_wood
	mi.position = Vector3(0, 0.09, 0)
	body.add_child(mi)

	for lx in [-1.05, 0.0, 1.05]:
		var log_mi = MeshInstance3D.new()
		var cm = CylinderMesh.new()
		cm.top_radius = 0.18
		cm.bottom_radius = 0.18
		cm.height = TILE - 0.08
		log_mi.mesh = cm
		log_mi.material_override = mat_log
		log_mi.rotation.x = PI / 2.0
		log_mi.position = Vector3(lx, -0.1, 0)
		body.add_child(log_mi)

	# Rope corner bindings for authentic pixel survival raft look
	for rx in [-1.15, 1.15]:
		for rz in [-1.15, 1.15]:
			var lashing = MeshInstance3D.new()
			var lbm = BoxMesh.new()
			lbm.size = Vector3(0.26, 0.26, 0.26)
			lashing.mesh = lbm
			lashing.material_override = mat_rope
			lashing.position = Vector3(rx, 0.04, rz)
			body.add_child(lashing)

	add_child(body)
	body.position = Vector3(cell.x * TILE, 0.1, cell.y * TILE)
	tiles[cell] = body
	hp[cell] = 4


func _make_mast():
	var pole = MeshInstance3D.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 0.06
	cm.bottom_radius = 0.08
	cm.height = 3.6
	pole.mesh = cm
	pole.material_override = mat_log
	pole.position = Vector3(-1.1, 2.0, -1.1)
	add_child(pole)

	var yard = MeshInstance3D.new()
	var ym = CylinderMesh.new()
	ym.top_radius = 0.04
	ym.bottom_radius = 0.04
	ym.height = 1.8
	yard.mesh = ym
	yard.material_override = mat_log
	yard.rotation.z = PI / 2.0
	yard.position = Vector3(-0.35, 3.35, -1.1)
	add_child(yard)

	var cloth = PixelUI.make_3d_mat("sail_cloth", Vector3(1, 1, 1), false, 0.0, 0.90)
	sail_mesh = MeshInstance3D.new()
	var sm = BoxMesh.new()
	sm.size = Vector3(1.55, 1.3, 0.05)
	sail_mesh.mesh = sm
	sail_mesh.material_override = cloth
	sail_mesh.position = Vector3(-0.35, 2.65, -1.1)
	add_child(sail_mesh)

	var flag_mat = PixelUI.make_3d_mat("rust_metal", Vector3(1, 1, 1), false, 0.0, 0.85, Color(0.92, 0.28, 0.22))
	flag_mesh = MeshInstance3D.new()
	var fm = BoxMesh.new()
	fm.size = Vector3(0.45, 0.18, 0.02)
	flag_mesh.mesh = fm
	flag_mesh.material_override = flag_mat
	flag_mesh.position = Vector3(-0.9, 3.72, -1.1)
	add_child(flag_mesh)


func _make_ghost():
	ghost = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = Vector3(TILE - 0.1, 0.42, TILE - 0.1)
	ghost.mesh = bm
	ghost.material_override = mat_bad
	ghost.visible = false
	add_child(ghost)


func set_ghost_active(on):
	if ghost == null:
		return
	if not on:
		ghost.visible = false
		ghost_valid = false
		ghost_cell = INVALID


func ray_to_cell(origin, dir):
	if dir.y > -0.02:
		return INVALID
	var deck_h = global_position.y + 0.3
	var t = (deck_h - origin.y) / dir.y
	if t < 0.0 or t > 15.0:
		return INVALID
	var p = to_local(origin + dir * t)
	return Vector2i(roundi(p.x / TILE), roundi(p.z / TILE))


func can_place(cell):
	if tiles.has(cell):
		return false
	for d in DIRS:
		if tiles.has(cell + d):
			return true
	return false


func update_ghost(origin, dir):
	if ghost == null:
		return
	var cell = ray_to_cell(origin, dir)
	ghost_cell = cell
	if cell == INVALID:
		ghost.visible = false
		ghost_valid = false
		return
	ghost.visible = true
	ghost.position = Vector3(cell.x * TILE, 0.12, cell.y * TILE)
	ghost_valid = can_place(cell)
	if ghost_valid:
		ghost.material_override = mat_ok
	else:
		ghost.material_override = mat_bad


func center():
	var s = Vector3.ZERO
	for c in tiles:
		s += cell_pos(c)
	return s / float(max(1, tiles.size()))


func nearest_tile_info(p):
	var best = Vector3(0, 0.3, 0)
	var bd = 1000000.0
	for c in tiles:
		var tp = cell_pos(c)
		var d = max(abs(p.x - tp.x), abs(p.z - tp.z)) - TILE * 0.5
		if d < bd:
			bd = d
			best = Vector3(tp.x, tp.y + 0.3, tp.z)
	return {"pos": best, "dist": bd}


func _is_exposed(cell):
	for d in DIRS:
		if not tiles.has(cell + d):
			return true
	return false


func attack_point(cell, from):
	var tp = cell_pos(cell)
	var best = tp
	var bd = 1000000.0
	for d in DIRS:
		if tiles.has(cell + d):
			continue
		var pt = tp + Vector3(d.x, 0, d.y) * (TILE * 0.5 + 1.0)
		var dd = Vector2(pt.x - from.x, pt.z - from.z).length()
		if dd < bd:
			bd = dd
			best = pt
	return best


func nearest_edge_cell(from):
	var best = INVALID
	var bd = 1000000.0
	for c in tiles:
		if c == Vector2i(0, 0):
			continue
		if not _is_exposed(c):
			continue
		var pt = attack_point(c, from)
		var dd = Vector2(pt.x - from.x, pt.z - from.z).length()
		if dd < bd:
			bd = dd
			best = c
	return best


func bite(cell):
	if not tiles.has(cell) or cell == Vector2i(0, 0):
		return false
	hp[cell] -= 1
	Game.play_sfx("bite", 1.0, 0.95)
	if hp[cell] <= 0:
		tiles[cell].queue_free()
		tiles.erase(cell)
		hp.erase(cell)
		Game.save_current_world(export_tile_list())
		Game.say("Sebuah pondasi rakit hancur digigit hiu!")
		return true
	return false


func add_purifier_visual():
	purifier_count += 1
	var n = purifier_count - 1
	var holder = Node3D.new()
	var mat_tank = PixelUI.make_3d_mat("plastic_blue", Vector3(1, 1, 1), false, 0.1, 0.4)
	var mat_top = PixelUI.make_3d_mat("metal_steel", Vector3(1, 1, 1), false, 0.65, 0.45)
	var tank = MeshInstance3D.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 0.3
	cm.bottom_radius = 0.3
	cm.height = 0.9
	tank.mesh = cm
	tank.material_override = mat_tank
	tank.position = Vector3(0, 0.45, 0)
	holder.add_child(tank)
	var cone = MeshInstance3D.new()
	var cn = CylinderMesh.new()
	cn.top_radius = 0.0
	cn.bottom_radius = 0.38
	cn.height = 0.35
	cone.mesh = cn
	cone.material_override = mat_top
	cone.position = Vector3(0, 1.05, 0)
	holder.add_child(cone)
	add_child(holder)
	holder.position = Vector3(-0.8 + 0.85 * (n % 3), 0.3, 1.0 - 0.85 * floori(n / 3.0))
	prop_nodes.append(holder)


func add_grill_visual():
	grill_count += 1
	var n = grill_count - 1
	var holder = Node3D.new()
	var base = MeshInstance3D.new()
	var bm = CylinderMesh.new()
	bm.top_radius = 0.36
	bm.bottom_radius = 0.40
	bm.height = 0.25
	base.mesh = bm
	base.material_override = PixelUI.make_3d_mat("metal_steel", Vector3(1, 1, 1), false, 0.75, 0.5, Color(0.45, 0.46, 0.50))
	base.position = Vector3(0, 0.15, 0)
	holder.add_child(base)

	var ember = MeshInstance3D.new()
	var em = CylinderMesh.new()
	em.top_radius = 0.28
	em.bottom_radius = 0.28
	em.height = 0.08
	ember.mesh = em
	var m_fire = StandardMaterial3D.new()
	m_fire.albedo_color = Color(0.92, 0.38, 0.10)
	m_fire.emission_enabled = true
	m_fire.emission = Color(0.92, 0.34, 0.08)
	m_fire.emission_energy_multiplier = 1.4
	ember.material_override = m_fire
	ember.position = Vector3(0, 0.26, 0)
	holder.add_child(ember)

	add_child(holder)
	holder.position = Vector3(2.2 + 0.9 * (n % 2), 0.3, 0.6 + 0.9 * floori(n / 2.0))
	prop_nodes.append(holder)


func add_lantern_visual():
	lantern_count += 1
	var n = lantern_count - 1
	var holder = Node3D.new()
	var post = MeshInstance3D.new()
	var pm = CylinderMesh.new()
	pm.top_radius = 0.04
	pm.bottom_radius = 0.05
	pm.height = 1.6
	post.mesh = pm
	post.material_override = mat_log
	post.position = Vector3(0, 0.8, 0)
	holder.add_child(post)

	var bulb = MeshInstance3D.new()
	var sm = SphereMesh.new()
	sm.radius = 0.14
	sm.height = 0.28
	bulb.mesh = sm
	var m_glow = StandardMaterial3D.new()
	m_glow.albedo_color = Color(0.96, 0.82, 0.46)
	m_glow.emission_enabled = true
	m_glow.emission = Color(0.95, 0.76, 0.38)
	m_glow.emission_energy_multiplier = 1.6
	bulb.material_override = m_glow
	bulb.position = Vector3(0, 1.65, 0)
	holder.add_child(bulb)

	var omni = OmniLight3D.new()
	omni.light_color = Color(0.98, 0.82, 0.52)
	omni.light_energy = 1.35
	omni.omni_range = 13.0
	omni.position = Vector3(0, 1.7, 0)
	holder.add_child(omni)

	add_child(holder)
	holder.position = Vector3(1.5 - 1.4 * (n % 2), 0.3, 1.5 - 1.4 * floori(n / 2.0))
	prop_nodes.append(holder)
