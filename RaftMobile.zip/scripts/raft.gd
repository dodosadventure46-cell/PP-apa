extends Node3D

const OceanScript = preload("res://scripts/ocean.gd")
const PixelUI = preload("res://scripts/pixel_ui.gd")

const TILE = 3.0
const INVALID = Vector2i(99999, 99999)
const DIRS = [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
const PAINT_TINTS = [
	Color(1.0, 1.0, 1.0),
	Color(0.92, 0.52, 0.48),
	Color(0.55, 0.78, 0.96),
	Color(0.58, 0.90, 0.62),
	Color(0.96, 0.95, 0.90),
]

var tiles = {}
var hp = {}
var max_hp = {}
var structures = []
var structure_nodes = []
var net_positions = []
var prop_nodes = []
var wake_strips = []
var bow_splash_nodes = []

var ghost
var ghost_cell = INVALID
var ghost_valid = false
var mat_wood
var mat_log
var mat_rope
var mat_steel
var mat_ok
var mat_bad
var mat_wake

var sail_pivot = null
var sail_canvas = null
var wind_streamer = null
var anchor_rope_mesh = null

var purifier_count = 0
var grill_count = 0
var lantern_count = 0
var crop_count = 0
var hammock_count = 0
var pot_count = 0
var scarecrow_count = 0
var research_count = 0
var chest_count = 0
var has_anchor_visual = false
var has_sail_visual = false
var frame_motion = Vector3.ZERO


func _ready():
	_make_materials()
	for c in [Vector2i(0, 0), Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1)]:
		add_tile(c)
	# Point #5: NO default mast or flag at start! Sail must be crafted.
	_make_ghost()
	_make_wake_fx()
	Game.settings_changed.connect(_apply_paint_theme)


func _apply_paint_theme():
	if mat_wood != null:
		var idx = clampi(Game.paint_theme, 0, PAINT_TINTS.size() - 1)
		mat_wood.albedo_color = PAINT_TINTS[idx]


func rebuild_from_game_state():
	for c in tiles.keys():
		if tiles[c] != null and is_instance_valid(tiles[c]):
			tiles[c].queue_free()
	tiles.clear()
	hp.clear()
	max_hp.clear()

	for sn in structure_nodes:
		if sn != null and is_instance_valid(sn):
			sn.queue_free()
	structure_nodes.clear()
	structures.clear()
	net_positions.clear()

	for p in prop_nodes:
		if p != null and is_instance_valid(p):
			p.queue_free()
	prop_nodes.clear()

	purifier_count = 0
	grill_count = 0
	lantern_count = 0
	crop_count = 0
	hammock_count = 0
	pot_count = 0
	scarecrow_count = 0
	research_count = 0
	chest_count = 0
	has_anchor_visual = false
	has_sail_visual = false
	anchor_rope_mesh = null
	sail_pivot = null
	sail_canvas = null
	wind_streamer = null

	var list = Game.saved_tiles
	if list == null or list.is_empty():
		list = [[0, 0], [1, 0], [0, 1], [1, 1]]
	for pair in list:
		if pair is Array and pair.size() >= 2:
			add_tile(Vector2i(int(pair[0]), int(pair[1])))
		elif pair is Vector2i:
			add_tile(pair)
	if tiles.is_empty():
		for c in [Vector2i(0, 0), Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1)]:
			add_tile(c)

	if Game.saved_structures is Array:
		for sd in Game.saved_structures:
			if sd is Dictionary:
				place_structure(
					str(sd.get("type", "wall")),
					Vector2i(int(sd.get("cx", 0)), int(sd.get("cy", 0))),
					int(sd.get("rot", 0)),
					false
				)

	for i in range(Game.purifiers):
		add_purifier_visual()
	for i in range(Game.grills):
		add_grill_visual()
	for i in range(Game.lanterns):
		add_lantern_visual()
	for i in range(Game.crop_plots):
		add_crop_plot_visual()
	for i in range(Game.hammocks):
		add_hammock_visual()
	for i in range(Game.cooking_pots):
		add_cooking_pot_visual()
	for i in range(Game.scarecrows):
		add_scarecrow_visual()
	for i in range(Game.research_tables):
		add_research_table_visual()
	for i in range(Game.chests):
		add_chest_visual()
	if Game.has_anchor:
		add_anchor_visual()
	if Game.has_sail:
		add_sail_visual()
	_apply_paint_theme()
	set_ghost_active(false)


func export_tile_list():
	var out = []
	for c in tiles.keys():
		out.append([c.x, c.y])
	return out


# Point #2: Balanced Center-of-Mass Buoyancy so the raft NEVER submerges underwater!
func _physics_process(delta):
	var prev_pos = global_position
	var c_local = _local_center()
	var cx = c_local.x
	var cz = c_local.z
	var span = 2.6

	var h_front = OceanScript.height(cx, cz - span)
	var h_back = OceanScript.height(cx, cz + span)
	var h_left = OceanScript.height(cx - span, cz)
	var h_right = OceanScript.height(cx + span, cz)
	var h_mid = OceanScript.height(cx, cz)

	var max_wave = max(h_mid, max(max(h_front, h_back), max(h_left, h_right)))
	var avg_h = (h_front + h_back + h_left + h_right + h_mid * 2.0) / 6.0
	var base_float_y = lerp(avg_h, max_wave, 0.55) + 0.18

	var slope_pitch = (h_back - h_front) / (span * 2.0)
	var slope_roll = (h_left - h_right) / (span * 2.0)
	# Gentle, realistic 3.5-degree max tilt so no corner of the raft ever dips below the waves
	var target_pitch = clamp(atan(slope_pitch) * 0.48, -0.065, 0.065)
	var target_roll = clamp(atan(slope_roll) * 0.48, -0.065, 0.065)
	var target_yaw = sin(OceanScript.wave_time * 0.52) * 0.018 * OceanScript.wave_amp

	rotation.x = lerp(rotation.x, target_pitch, clamp(delta * 6.0, 0.0, 1.0))
	rotation.z = lerp(rotation.z, target_roll, clamp(delta * 6.0, 0.0, 1.0))
	rotation.y = lerp(rotation.y, target_yaw, clamp(delta * 4.5, 0.0, 1.0))

	# Compensate vertical height for local center-of-mass offset so rotation pivots around the center of the raft, NOT (0,0)!
	var pivot_comp_y = c_local.z * sin(rotation.x) - c_local.x * sin(rotation.z)

	var surge = OceanScript.current_surge()
	if Game.anchor_down:
		surge *= 0.15

	var target_pos = Vector3(surge.x, base_float_y + pivot_comp_y, surge.y)
	global_position = global_position.lerp(target_pos, clamp(delta * 8.0, 0.0, 1.0))
	frame_motion = global_position - prev_pos


func _process(delta):
	var t = OceanScript.wave_time
	if sail_pivot != null:
		sail_pivot.rotation.y = lerp_angle(sail_pivot.rotation.y, -Game.sail_angle + PI / 2.0, clamp(delta * 8.0, 0.0, 1.0))
	if sail_canvas != null:
		var target_sy = 1.0 if Game.sail_open else 0.18
		sail_canvas.scale.y = lerp(sail_canvas.scale.y, target_sy, clamp(delta * 8.0, 0.0, 1.0))
		sail_canvas.scale.z = 1.0 + (0.28 * sin(t * 2.4) if Game.sail_open else 0.0)
	if wind_streamer != null:
		wind_streamer.rotation.y = -Game.wind_angle + sin(t * 5.2) * 0.18
	if anchor_rope_mesh != null:
		anchor_rope_mesh.scale.y = 2.8 if Game.anchor_down else 0.45
		anchor_rope_mesh.position.y = -0.95 if Game.anchor_down else 0.25

	# Point #3 / B: Collection Nets automatically catch nearby floating debris!
	if not net_positions.is_empty():
		for d in get_tree().get_nodes_in_group("debris"):
			if d == null or not is_instance_valid(d) or d.hooked:
				continue
			for np in net_positions:
				var w_np = to_global(np)
				if Vector2(d.global_position.x - w_np.x, d.global_position.z - w_np.z).length() <= 2.35:
					var k = d.kind
					d.queue_free()
					Game.collect(k)
					break

	# Point #5: Water Wake & Bow Foam Splash effects when the raft is moving!
	_update_wake_fx(delta, t)


func _make_wake_fx():
	mat_wake = StandardMaterial3D.new()
	mat_wake.albedo_color = Color(0.76, 0.90, 0.98, 0.72)
	mat_wake.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat_wake.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED

	for i in range(8):
		var strip = MeshInstance3D.new()
		var bm = BoxMesh.new()
		bm.size = Vector3(0.55 + i * 0.14, 0.04, 1.15)
		strip.mesh = bm
		strip.material_override = mat_wake
		strip.visible = false
		add_child(strip)
		wake_strips.append(strip)

	for i in range(4):
		var sp = MeshInstance3D.new()
		var cm = CylinderMesh.new()
		cm.top_radius = 0.42
		cm.bottom_radius = 0.25
		cm.height = 0.06
		sp.mesh = cm
		sp.material_override = mat_wake
		sp.visible = false
		add_child(sp)
		bow_splash_nodes.append(sp)


func _update_wake_fx(_delta, t):
	var moving = Game.is_raft_moving()
	if not moving:
		for s in wake_strips:
			s.visible = false
		for b in bow_splash_nodes:
			b.visible = false
		return

	Game.play_wake_tick()
	var c_loc = _local_center()
	var move_dir = Vector3(cos(Game.sail_angle), 0.0, sin(Game.sail_angle)).normalized()
	var side_dir = Vector3(-move_dir.z, 0.0, move_dir.x)

	for i in range(wake_strips.size()):
		var s = wake_strips[i]
		s.visible = true
		var side_sign = -1.0 if (i % 2 == 0) else 1.0
		var row = int(i / 2) + 1
		var phase_off = fmod(t * 2.6 + float(row) * 0.45, 2.2)
		var back_dist = 2.8 + phase_off * 2.4
		var spread = 1.4 + phase_off * 1.1
		var lp = c_loc - move_dir * back_dist + side_dir * (side_sign * spread)
		lp.y = -0.08
		s.position = lp
		s.rotation.y = -Game.sail_angle + side_sign * 0.35

	for i in range(bow_splash_nodes.size()):
		var b = bow_splash_nodes[i]
		b.visible = true
		var side_s = (float(i) - 1.5) * 1.25
		var pulse = 0.7 + 0.4 * sin(t * 6.5 + float(i) * 1.7)
		var lp = c_loc + move_dir * 3.2 + side_dir * side_s
		lp.y = -0.05
		b.position = lp
		b.scale = Vector3(pulse, 1.0, pulse)


func is_point_over_raft(wx, wz):
	var lp = to_local(Vector3(wx, global_position.y, wz))
	var cell = Vector2i(roundi(lp.x / TILE), roundi(lp.z / TILE))
	if tiles.has(cell):
		return true
	var info = nearest_tile_info(Vector3(wx, 0, wz))
	return info["dist"] <= 0.25


func get_deck_height_at(wx, wz):
	var lp = to_local(Vector3(wx, global_position.y, wz))
	lp.y = 0.31
	var gp = to_global(lp)
	return gp.y


func _make_materials():
	mat_wood = PixelUI.make_3d_mat("wood_deck", Vector3(0.5, 0.5, 0.5), true, 0.0, 0.88)
	mat_log = PixelUI.make_3d_mat("wood_log", Vector3(1.0, 2.0, 1.0), false, 0.0, 0.90)
	mat_rope = PixelUI.make_3d_mat("rope_3d", Vector3(1.0, 1.0, 1.0), false, 0.0, 0.88)
	mat_steel = PixelUI.make_3d_mat("metal_steel", Vector3(1.0, 1.0, 1.0), false, 0.78, 0.38)

	mat_ok = StandardMaterial3D.new()
	mat_ok.albedo_color = Color(0.2, 1.0, 0.35, 0.48)
	mat_ok.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat_ok.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED

	mat_bad = StandardMaterial3D.new()
	mat_bad.albedo_color = Color(1.0, 0.22, 0.2, 0.48)
	mat_bad.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat_bad.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED


func _local_center():
	var s = Vector3.ZERO
	for c in tiles:
		s += Vector3(c.x * TILE, 0.0, c.y * TILE)
	return s / float(max(1, tiles.size()))


func cell_pos(cell):
	return to_global(Vector3(cell.x * TILE, 0.0, cell.y * TILE))


func add_tile(cell):
	if tiles.has(cell):
		return
	var body = StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	var shape = CollisionShape3D.new()
	var box = BoxShape3D.new()
	box.size = Vector3(TILE + 0.04, 0.4, TILE + 0.04)
	shape.shape = box
	body.add_child(shape)

	var mi = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = Vector3(TILE - 0.06, 0.22, TILE - 0.06)
	mi.mesh = bm
	mi.material_override = mat_wood
	mi.position = Vector3(0, 0.09, 0)
	body.add_child(mi)

	for lx in [-1.05, 0.0, 1.05]:
		var log_mi = MeshInstance3D.new()
		var cm = CylinderMesh.new()
		cm.top_radius = 0.18
		cm.bottom_radius = 0.18
		cm.height = TILE - 0.08
		log_mi.mesh = cm
		log_mi.material_override = mat_log
		log_mi.rotation.x = PI / 2.0
		log_mi.position = Vector3(lx, -0.1, 0)
		body.add_child(log_mi)

	for rx in [-1.15, 1.15]:
		for rz in [-1.15, 1.15]:
			var lashing = MeshInstance3D.new()
			var lbm = BoxMesh.new()
			lbm.size = Vector3(0.26, 0.26, 0.26)
			lashing.mesh = lbm
			lashing.material_override = mat_rope
			lashing.position = Vector3(rx, 0.04, rz)
			body.add_child(lashing)

	add_child(body)
	body.position = Vector3(cell.x * TILE, 0.1, cell.y * TILE)
	tiles[cell] = body
	hp[cell] = 4
	max_hp[cell] = 4


# F12: Repair damaged foundation tile with Repair Hammer
func repair_tile(cell):
	if not tiles.has(cell):
		return
	var cur = int(hp.get(cell, 4))
	var mx = int(max_hp.get(cell, 4))
	if cur >= mx:
		Game.say("Pondasi ini sudah kondisi penuh (%d/%d HP)!" % [cur, mx])
		return
	if Game.count("wood") < 1:
		Game.say("Butuh 1 Kayu Apung untuk memperbaiki pondasi!")
		return
	Game.spend({"wood": 1})
	hp[cell] = mx
	Game.play_sfx("repair", 1.08, 0.9)
	Game.say("Pondasi rakit berhasil diperbaiki ke %d/%d HP!" % [mx, mx])


# Point #3 & F13 & F15: Place modular structures on raft tiles (Walls, Windows, Fences, Roofs, Stairs, Nets, Armor Tiles, Decor)
func place_structure(stype, cell, rot_idx = 0, save_now = true):
	if not tiles.has(cell):
		return false
	var holder = StaticBody3D.new()
	holder.collision_layer = 1
	holder.collision_mask = 0
	holder.position = Vector3(cell.x * TILE, 0.25, cell.y * TILE)
	holder.rotation.y = float(rot_idx % 4) * (PI / 2.0)

	match stype:
		"wall":
			var cs = CollisionShape3D.new()
			var bs = BoxShape3D.new()
			bs.size = Vector3(TILE, 2.3, 0.22)
			cs.shape = bs
			cs.position = Vector3(0, 1.15, -TILE * 0.46)
			holder.add_child(cs)
			var w_mi = MeshInstance3D.new()
			var wbm = BoxMesh.new()
			wbm.size = Vector3(TILE - 0.04, 2.3, 0.18)
			w_mi.mesh = wbm
			w_mi.material_override = mat_wood
			w_mi.position = Vector3(0, 1.15, -TILE * 0.46)
			holder.add_child(w_mi)

		"window_wall":
			var cs = CollisionShape3D.new()
			var bs = BoxShape3D.new()
			bs.size = Vector3(TILE, 2.3, 0.22)
			cs.shape = bs
			cs.position = Vector3(0, 1.15, -TILE * 0.46)
			holder.add_child(cs)
			for by in [Vector2(0.45, 0.9), Vector2(1.95, 0.7)]:
				var p_mi = MeshInstance3D.new()
				var pbm = BoxMesh.new()
				pbm.size = Vector3(TILE - 0.04, by.y, 0.18)
				p_mi.mesh = pbm
				p_mi.material_override = mat_wood
				p_mi.position = Vector3(0, by.x, -TILE * 0.46)
				holder.add_child(p_mi)
			for sx in [-1.1, 1.1]:
				var s_mi = MeshInstance3D.new()
				var sbm = BoxMesh.new()
				sbm.size = Vector3(0.75, 0.85, 0.18)
				s_mi.mesh = sbm
				s_mi.material_override = mat_wood
				s_mi.position = Vector3(sx, 1.25, -TILE * 0.46)
				holder.add_child(s_mi)

		"fence":
			var cs = CollisionShape3D.new()
			var bs = BoxShape3D.new()
			bs.size = Vector3(TILE, 1.05, 0.20)
			cs.shape = bs
			cs.position = Vector3(0, 0.52, -TILE * 0.46)
			holder.add_child(cs)
			for ry in [0.38, 0.82]:
				var rail = MeshInstance3D.new()
				var rbm = BoxMesh.new()
				rbm.size = Vector3(TILE - 0.06, 0.12, 0.12)
				rail.mesh = rbm
				rail.material_override = mat_wood
				rail.position = Vector3(0, ry, -TILE * 0.46)
				holder.add_child(rail)
			for px in [-1.25, 0.0, 1.25]:
				var post = MeshInstance3D.new()
				var pcm = CylinderMesh.new()
				pcm.top_radius = 0.08
				pcm.bottom_radius = 0.09
				pcm.height = 1.05
				post.mesh = pcm
				post.material_override = mat_log
				post.position = Vector3(px, 0.52, -TILE * 0.46)
				holder.add_child(post)

		"roof":
			var cs = CollisionShape3D.new()
			var bs = BoxShape3D.new()
			bs.size = Vector3(TILE, 0.22, TILE)
			cs.shape = bs
			cs.position = Vector3(0, 2.35, 0)
			holder.add_child(cs)
			var rf = MeshInstance3D.new()
			var rbm = BoxMesh.new()
			rbm.size = Vector3(TILE, 0.18, TILE)
			rf.mesh = rbm
			rf.material_override = mat_wood
			rf.position = Vector3(0, 2.35, 0)
			holder.add_child(rf)
			for px in [-1.3, 1.3]:
				for pz in [-1.3, 1.3]:
					var pil = MeshInstance3D.new()
					var pcm = CylinderMesh.new()
					pcm.top_radius = 0.09
					pcm.bottom_radius = 0.10
					pcm.height = 2.35
					pil.mesh = pcm
					pil.material_override = mat_log
					pil.position = Vector3(px, 1.17, pz)
					holder.add_child(pil)

		"stairs":
			for i in range(6):
				var frac = float(i + 1) / 6.0
				var step_b = MeshInstance3D.new()
				var sbm = BoxMesh.new()
				sbm.size = Vector3(1.4, 0.14, 0.48)
				step_b.mesh = sbm
				step_b.material_override = mat_wood
				step_b.position = Vector3(0, frac * 2.3, 1.2 - frac * 2.4)
				holder.add_child(step_b)
				var scs = CollisionShape3D.new()
				var sbs = BoxShape3D.new()
				sbs.size = Vector3(1.4, 0.22, 0.52)
				scs.shape = sbs
				scs.position = step_b.position
				holder.add_child(scs)

		"net":
			var net_mi = MeshInstance3D.new()
			var nbm = BoxMesh.new()
			nbm.size = Vector3(TILE - 0.1, 0.55, 0.65)
			net_mi.mesh = nbm
			net_mi.material_override = mat_rope
			net_mi.position = Vector3(0, -0.05, -TILE * 0.55)
			holder.add_child(net_mi)
			var local_net_pos = holder.position + holder.transform.basis * Vector3(0, 0, -TILE * 0.55)
			net_positions.append(local_net_pos)

		"armor_tile":
			max_hp[cell] = 12
			hp[cell] = 12
			var rim = MeshInstance3D.new()
			var rbm = BoxMesh.new()
			rbm.size = Vector3(TILE + 0.02, 0.26, TILE + 0.02)
			rim.mesh = rbm
			rim.material_override = mat_steel
			rim.position = Vector3(0, -0.05, 0)
			holder.add_child(rim)

		"decor":
			var tbl = MeshInstance3D.new()
			var tbm = BoxMesh.new()
			tbm.size = Vector3(1.1, 0.65, 0.8)
			tbl.mesh = tbm
			tbl.material_override = mat_wood
			tbl.position = Vector3(0, 0.32, 0)
			holder.add_child(tbl)

	add_child(holder)
	structure_nodes.append(holder)
	structures.append({"type": stype, "cx": cell.x, "cy": cell.y, "rot": rot_idx % 4})
	if save_now:
		Game.save_current_world(export_tile_list(), structures)
	return true


# Point #5 & F1: Craftable 360°-Steerable Ship Sail + Wind Streamer (NO red flag at start!)
func add_sail_visual():
	if has_sail_visual:
		return
	has_sail_visual = true
	var holder = Node3D.new()
	holder.position = Vector3(-0.9, 0.25, -0.9)
	add_child(holder)
	prop_nodes.append(holder)

	var pole = MeshInstance3D.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 0.07
	cm.bottom_radius = 0.10
	cm.height = 3.8
	pole.mesh = cm
	pole.material_override = mat_log
	pole.position = Vector3(0, 1.9, 0)
	holder.add_child(pole)

	sail_pivot = Node3D.new()
	sail_pivot.position = Vector3(0, 2.5, 0)
	holder.add_child(sail_pivot)

	var yard_top = MeshInstance3D.new()
	var ym = CylinderMesh.new()
	ym.top_radius = 0.045
	ym.bottom_radius = 0.045
	ym.height = 2.2
	yard_top.mesh = ym
	yard_top.material_override = mat_log
	yard_top.rotation.z = PI / 2.0
	yard_top.position = Vector3(0, 0.85, 0)
	sail_pivot.add_child(yard_top)

	var yard_bot = MeshInstance3D.new()
	yard_bot.mesh = ym
	yard_bot.material_override = mat_log
	yard_bot.rotation.z = PI / 2.0
	yard_bot.position = Vector3(0, -0.75, 0)
	sail_pivot.add_child(yard_bot)

	var cloth_mat = PixelUI.make_3d_mat("sail_cloth", Vector3(1, 1, 1), false, 0.0, 0.88)
	sail_canvas = Node3D.new()
	sail_pivot.add_child(sail_canvas)
	# Multi-panel curved billowing ship sail
	for i in range(3):
		var seg = MeshInstance3D.new()
		var sbm = BoxMesh.new()
		sbm.size = Vector3(2.05, 0.52, 0.06)
		seg.mesh = sbm
		seg.material_override = cloth_mat
		var arch_z = -0.18 if i == 1 else -0.06
		seg.position = Vector3(0, 0.50 - i * 0.50, arch_z)
		sail_canvas.add_child(seg)

	# F1: Wind Streamer Ribbon at top of mast
	wind_streamer = Node3D.new()
	wind_streamer.position = Vector3(0, 3.85, 0)
	holder.add_child(wind_streamer)
	var rib = MeshInstance3D.new()
	var rbm = BoxMesh.new()
	rbm.size = Vector3(0.65, 0.10, 0.02)
	rib.mesh = rbm
	rib.material_override = PixelUI.make_3d_mat("sail_cloth", Vector3(1, 1, 1), false, 0.0, 0.8, Color(0.35, 0.88, 0.98))
	rib.position = Vector3(0.32, 0, 0)
	wind_streamer.add_child(rib)


func _make_ghost():
	ghost = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = Vector3(TILE - 0.1, 0.42, TILE - 0.1)
	ghost.mesh = bm
	ghost.material_override = mat_bad
	ghost.visible = false
	add_child(ghost)


func set_ghost_active(on):
	if ghost == null:
		return
	if not on:
		ghost.visible = false
		ghost_valid = false
		ghost_cell = INVALID


func ray_to_cell(origin, dir):
	if dir.y > -0.02:
		return INVALID
	var deck_h = global_position.y + 0.3
	var t = (deck_h - origin.y) / dir.y
	if t < 0.0 or t > 15.0:
		return INVALID
	var p = to_local(origin + dir * t)
	return Vector2i(roundi(p.x / TILE), roundi(p.z / TILE))


func ray_to_existing_cell(origin, dir):
	var c = ray_to_cell(origin, dir)
	if tiles.has(c):
		return c
	return INVALID


func can_place(cell, b_type = "foundation"):
	if b_type == "foundation":
		if tiles.has(cell):
			return false
		for d in DIRS:
			if tiles.has(cell + d):
				return true
		return false
	return tiles.has(cell)


func update_ghost(origin, dir, b_type = "foundation", rot_idx = 0):
	if ghost == null:
		return
	var cell = ray_to_cell(origin, dir)
	ghost_cell = cell
	if cell == INVALID:
		ghost.visible = false
		ghost_valid = false
		return
	ghost.visible = true
	ghost.rotation.y = float(rot_idx % 4) * (PI / 2.0)
	if b_type in ["wall", "window_wall"]:
		ghost.scale = Vector3(1.0, 5.2, 0.12)
		ghost.position = Vector3(cell.x * TILE, 1.25, cell.y * TILE)
	elif b_type == "fence":
		ghost.scale = Vector3(1.0, 2.4, 0.12)
		ghost.position = Vector3(cell.x * TILE, 0.65, cell.y * TILE)
	elif b_type == "roof":
		ghost.scale = Vector3(1.0, 0.5, 1.0)
		ghost.position = Vector3(cell.x * TILE, 2.45, cell.y * TILE)
	else:
		ghost.scale = Vector3.ONE
		ghost.position = Vector3(cell.x * TILE, 0.18, cell.y * TILE)
	ghost_valid = can_place(cell, b_type)
	ghost.material_override = mat_ok if ghost_valid else mat_bad


func center():
	var s = Vector3.ZERO
	for c in tiles:
		s += cell_pos(c)
	return s / float(max(1, tiles.size()))


func nearest_tile_info(p):
	var best = Vector3(0, 0.3, 0)
	var bd = 1000000.0
	for c in tiles:
		var tp = cell_pos(c)
		var d = max(abs(p.x - tp.x), abs(p.z - tp.z)) - TILE * 0.5
		if d < bd:
			bd = d
			best = Vector3(tp.x, tp.y + 0.3, tp.z)
	return {"pos": best, "dist": bd}


func _is_exposed(cell):
	for d in DIRS:
		if not tiles.has(cell + d):
			return true
	return false


func attack_point(cell, from):
	var tp = cell_pos(cell)
	var best = tp
	var bd = 1000000.0
	for d in DIRS:
		if tiles.has(cell + d):
			continue
		var pt = tp + Vector3(d.x, 0, d.y) * (TILE * 0.5 + 1.0)
		var dd = Vector2(pt.x - from.x, pt.z - from.z).length()
		if dd < bd:
			bd = dd
			best = pt
	return best


func nearest_edge_cell(from):
	var best = INVALID
	var bd = 1000000.0
	for c in tiles:
		if c == Vector2i(0, 0):
			continue
		if not _is_exposed(c):
			continue
		var pt = attack_point(c, from)
		var dd = Vector2(pt.x - from.x, pt.z - from.z).length()
		if dd < bd:
			bd = dd
			best = c
	return best


func bite(cell):
	if not tiles.has(cell) or cell == Vector2i(0, 0):
		return false
	hp[cell] -= 1
	Game.play_sfx("bite", 1.0, 0.95)
	if hp[cell] <= 0:
		tiles[cell].queue_free()
		tiles.erase(cell)
		hp.erase(cell)
		max_hp.erase(cell)
		Game.save_current_world(export_tile_list(), structures)
		Game.say("Sebuah pondasi rakit hancur digigit hiu!")
		return true
	return false


func add_anchor_visual():
	if has_anchor_visual:
		return
	has_anchor_visual = true
	var holder = Node3D.new()
	var winch = MeshInstance3D.new()
	var wm = BoxMesh.new()
	wm.size = Vector3(0.55, 0.52, 0.45)
	winch.mesh = wm
	winch.material_override = mat_log
	winch.position = Vector3(0, 0.26, 0)
	holder.add_child(winch)

	var drum = MeshInstance3D.new()
	var dm = CylinderMesh.new()
	dm.top_radius = 0.16
	dm.bottom_radius = 0.16
	dm.height = 0.48
	drum.mesh = dm
	drum.material_override = mat_steel
	drum.rotation.z = PI / 2.0
	drum.position = Vector3(0, 0.42, 0)
	holder.add_child(drum)

	anchor_rope_mesh = MeshInstance3D.new()
	var rm = CylinderMesh.new()
	rm.top_radius = 0.035
	rm.bottom_radius = 0.035
	rm.height = 1.0
	anchor_rope_mesh.mesh = rm
	anchor_rope_mesh.material_override = mat_rope
	anchor_rope_mesh.position = Vector3(0, 0.25, -0.32)
	holder.add_child(anchor_rope_mesh)

	add_child(holder)
	holder.position = Vector3(0.2, 0.25, -1.2)
	prop_nodes.append(holder)


func add_purifier_visual():
	purifier_count += 1
	var n = purifier_count - 1
	var holder = Node3D.new()
	var mat_tank = PixelUI.make_3d_mat("plastic_blue", Vector3(1, 1, 1), false, 0.1, 0.4)
	var tank = MeshInstance3D.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 0.3
	cm.bottom_radius = 0.3
	cm.height = 0.9
	tank.mesh = cm
	tank.material_override = mat_tank
	tank.position = Vector3(0, 0.45, 0)
	holder.add_child(tank)
	var cone = MeshInstance3D.new()
	var cn = CylinderMesh.new()
	cn.top_radius = 0.0
	cn.bottom_radius = 0.38
	cn.height = 0.35
	cone.mesh = cn
	cone.material_override = mat_steel
	cone.position = Vector3(0, 1.05, 0)
	holder.add_child(cone)
	add_child(holder)
	holder.position = Vector3(-0.8 + 0.85 * (n % 3), 0.25, 1.0 - 0.85 * floori(n / 3.0))
	prop_nodes.append(holder)


func add_grill_visual():
	grill_count += 1
	var n = grill_count - 1
	var holder = Node3D.new()
	var base = MeshInstance3D.new()
	var bm = CylinderMesh.new()
	bm.top_radius = 0.36
	bm.bottom_radius = 0.40
	bm.height = 0.25
	base.mesh = bm
	base.material_override = mat_steel
	base.position = Vector3(0, 0.15, 0)
	holder.add_child(base)

	var ember = MeshInstance3D.new()
	var em = CylinderMesh.new()
	em.top_radius = 0.28
	em.bottom_radius = 0.28
	em.height = 0.08
	ember.mesh = em
	var m_fire = StandardMaterial3D.new()
	m_fire.albedo_color = Color(0.92, 0.38, 0.10)
	m_fire.emission_enabled = true
	m_fire.emission = Color(0.92, 0.34, 0.08)
	m_fire.emission_energy_multiplier = 1.4
	ember.material_override = m_fire
	ember.position = Vector3(0, 0.26, 0)
	holder.add_child(ember)

	add_child(holder)
	holder.position = Vector3(2.2 + 0.9 * (n % 2), 0.25, 0.6 + 0.9 * floori(n / 2.0))
	prop_nodes.append(holder)


func add_lantern_visual():
	lantern_count += 1
	var n = lantern_count - 1
	var holder = Node3D.new()
	var post = MeshInstance3D.new()
	var pm = CylinderMesh.new()
	pm.top_radius = 0.04
	pm.bottom_radius = 0.05
	pm.height = 1.6
	post.mesh = pm
	post.material_override = mat_log
	post.position = Vector3(0, 0.8, 0)
	holder.add_child(post)

	var bulb = MeshInstance3D.new()
	var sm = SphereMesh.new()
	sm.radius = 0.14
	sm.height = 0.28
	bulb.mesh = sm
	var m_glow = StandardMaterial3D.new()
	m_glow.albedo_color = Color(0.96, 0.82, 0.46)
	m_glow.emission_enabled = true
	m_glow.emission = Color(0.95, 0.76, 0.38)
	m_glow.emission_energy_multiplier = 1.6
	bulb.material_override = m_glow
	bulb.position = Vector3(0, 1.65, 0)
	holder.add_child(bulb)

	var omni = OmniLight3D.new()
	omni.light_color = Color(0.98, 0.82, 0.52)
	omni.light_energy = 1.35
	omni.omni_range = 13.0
	omni.position = Vector3(0, 1.7, 0)
	holder.add_child(omni)

	add_child(holder)
	holder.position = Vector3(1.5 - 1.4 * (n % 2), 0.25, 1.5 - 1.4 * floori(n / 2.0))
	prop_nodes.append(holder)


func add_crop_plot_visual():
	crop_count += 1
	var n = crop_count - 1
	var holder = Node3D.new()
	var box = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = Vector3(0.85, 0.24, 0.85)
	box.mesh = bm
	box.material_override = mat_log
	box.position = Vector3(0, 0.12, 0)
	holder.add_child(box)

	var plant = MeshInstance3D.new()
	var pm = CylinderMesh.new()
	pm.top_radius = 0.05
	pm.bottom_radius = 0.08
	pm.height = 0.95
	plant.mesh = pm
	plant.material_override = PixelUI.make_3d_mat("palm_leaf", Vector3(1, 1, 1))
	plant.position = Vector3(0, 0.55, 0)
	holder.add_child(plant)

	add_child(holder)
	holder.position = Vector3(-0.8 + 1.0 * (n % 3), 0.25, 2.5 + 1.0 * floori(n / 3.0))
	prop_nodes.append(holder)


func add_hammock_visual():
	hammock_count += 1
	var holder = Node3D.new()
	var bed = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = Vector3(1.5, 0.18, 0.75)
	bed.mesh = bm
	bed.material_override = PixelUI.make_3d_mat("sail_cloth", Vector3(1, 1, 1))
	bed.position = Vector3(0, 0.22, 0)
	holder.add_child(bed)
	add_child(holder)
	holder.position = Vector3(3.2, 0.25, 2.2)
	prop_nodes.append(holder)


func add_cooking_pot_visual():
	pot_count += 1
	var holder = Node3D.new()
	var pot = MeshInstance3D.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 0.34
	cm.bottom_radius = 0.30
	cm.height = 0.45
	pot.mesh = cm
	pot.material_override = mat_steel
	pot.position = Vector3(0, 0.24, 0)
	holder.add_child(pot)
	add_child(holder)
	holder.position = Vector3(3.1, 0.25, -0.5)
	prop_nodes.append(holder)


func add_scarecrow_visual():
	scarecrow_count += 1
	var holder = Node3D.new()
	var pole = MeshInstance3D.new()
	var pm = CylinderMesh.new()
	pm.top_radius = 0.05
	pm.bottom_radius = 0.06
	pm.height = 1.65
	pole.mesh = pm
	pole.material_override = mat_log
	pole.position = Vector3(0, 0.82, 0)
	holder.add_child(pole)

	var arms = MeshInstance3D.new()
	var am = CylinderMesh.new()
	am.top_radius = 0.04
	am.bottom_radius = 0.04
	am.height = 1.15
	arms.mesh = am
	arms.material_override = mat_log
	arms.rotation.z = PI / 2.0
	arms.position = Vector3(0, 1.22, 0)
	holder.add_child(arms)

	var hd = MeshInstance3D.new()
	var sm = SphereMesh.new()
	sm.radius = 0.18
	sm.height = 0.36
	hd.mesh = sm
	hd.material_override = mat_rope
	hd.position = Vector3(0, 1.58, 0)
	holder.add_child(hd)

	add_child(holder)
	holder.position = Vector3(0.4, 0.25, 2.8)
	prop_nodes.append(holder)


func add_research_table_visual():
	research_count += 1
	var holder = Node3D.new()
	var desk = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = Vector3(1.15, 0.68, 0.72)
	desk.mesh = bm
	desk.material_override = mat_wood
	desk.position = Vector3(0, 0.34, 0)
	holder.add_child(desk)
	add_child(holder)
	holder.position = Vector3(1.2, 0.25, -1.0)
	prop_nodes.append(holder)


func add_chest_visual():
	chest_count += 1
	var n = chest_count - 1
	var holder = Node3D.new()
	var box = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = Vector3(0.78, 0.52, 0.54)
	box.mesh = bm
	box.material_override = PixelUI.make_3d_mat("wood_crate", Vector3(1, 1, 1))
	box.position = Vector3(0, 0.26, 0)
	holder.add_child(box)
	add_child(holder)
	holder.position = Vector3(2.8, 0.25, 1.2 + 0.8 * n)
	prop_nodes.append(holder)
