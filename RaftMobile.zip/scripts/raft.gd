extends Node3D

const TILE = 3.0
const INVALID = Vector2i(99999, 99999)
const DIRS = [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]

var tiles = {}
var hp = {}
var ghost
var ghost_cell = INVALID
var ghost_valid = false
var mat_wood
var mat_ok
var mat_bad
var purifier_count = 0


func _ready():
	_make_materials()
	for c in [Vector2i(0, 0), Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1)]:
		add_tile(c)
	_make_mast()
	_make_ghost()


func _make_wood_texture():
	var img = Image.create(64, 64, false, Image.FORMAT_RGB8)
	for y in range(64):
		var plank = floori(y / 16.0)
		var base = Color(0.58, 0.4, 0.22)
		if plank % 2 == 1:
			base = Color(0.5, 0.34, 0.18)
		for x in range(64):
			var c = base.darkened(0.07 * (0.5 + 0.5 * sin(x * 0.45 + plank * 2.7)))
			var ly = y % 16
			if ly == 0 or ly == 15:
				c = Color(0.24, 0.15, 0.07)
			img.set_pixel(x, y, c)
	return ImageTexture.create_from_image(img)


func _make_materials():
	mat_wood = StandardMaterial3D.new()
	mat_wood.albedo_texture = _make_wood_texture()
	mat_wood.uv1_triplanar = true
	mat_wood.uv1_scale = Vector3(0.6, 0.6, 0.6)
	mat_wood.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS
	mat_wood.roughness = 0.9
	mat_ok = StandardMaterial3D.new()
	mat_ok.albedo_color = Color(0.2, 1.0, 0.3, 0.45)
	mat_ok.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat_ok.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat_bad = StandardMaterial3D.new()
	mat_bad.albedo_color = Color(1.0, 0.2, 0.2, 0.45)
	mat_bad.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat_bad.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED


func cell_pos(cell):
	return Vector3(cell.x * TILE, 0.0, cell.y * TILE)


func add_tile(cell):
	var body = StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	var shape = CollisionShape3D.new()
	var box = BoxShape3D.new()
	box.size = Vector3(TILE + 0.04, 0.4, TILE + 0.04)
	shape.shape = box
	body.add_child(shape)
	var mi = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = Vector3(TILE - 0.06, 0.4, TILE - 0.06)
	mi.mesh = bm
	mi.material_override = mat_wood
	body.add_child(mi)
	add_child(body)
	body.position = Vector3(cell.x * TILE, 0.1, cell.y * TILE)
	tiles[cell] = body
	hp[cell] = 4


func _make_mast():
	var dark = StandardMaterial3D.new()
	dark.albedo_color = Color(0.3, 0.2, 0.1)
	var pole = MeshInstance3D.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 0.06
	cm.bottom_radius = 0.07
	cm.height = 3.4
	pole.mesh = cm
	pole.material_override = dark
	pole.position = Vector3(-1.1, 2.0, -1.1)
	add_child(pole)
	var cloth = StandardMaterial3D.new()
	cloth.albedo_color = Color(0.95, 0.95, 0.9)
	var sail = MeshInstance3D.new()
	var sm = BoxMesh.new()
	sm.size = Vector3(1.5, 1.2, 0.04)
	sail.mesh = sm
	sail.material_override = cloth
	sail.position = Vector3(-0.35, 2.7, -1.1)
	add_child(sail)


func _make_ghost():
	ghost = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = Vector3(TILE - 0.1, 0.42, TILE - 0.1)
	ghost.mesh = bm
	ghost.material_override = mat_bad
	ghost.visible = false
	add_child(ghost)


func set_ghost_active(on):
	if not on:
		ghost.visible = false
		ghost_valid = false
		ghost_cell = INVALID


func ray_to_cell(origin, dir):
	if dir.y > -0.02:
		return INVALID
	var t = (0.3 - origin.y) / dir.y
	if t < 0.0 or t > 14.0:
		return INVALID
	var p = origin + dir * t
	return Vector2i(roundi(p.x / TILE), roundi(p.z / TILE))


func can_place(cell):
	if tiles.has(cell):
		return false
	for d in DIRS:
		if tiles.has(cell + d):
			return true
	return false


func update_ghost(origin, dir):
	var cell = ray_to_cell(origin, dir)
	ghost_cell = cell
	if cell == INVALID:
		ghost.visible = false
		ghost_valid = false
		return
	ghost.visible = true
	ghost.position = Vector3(cell.x * TILE, 0.12, cell.y * TILE)
	ghost_valid = can_place(cell)
	if ghost_valid:
		ghost.material_override = mat_ok
	else:
		ghost.material_override = mat_bad


func center():
	var s = Vector3.ZERO
	for c in tiles:
		s += cell_pos(c)
	return s / float(max(1, tiles.size()))


func nearest_tile_info(p):
	var best = Vector3(0, 0.3, 0)
	var bd = 1000000.0
	for c in tiles:
		var tp = cell_pos(c)
		var d = max(abs(p.x - tp.x), abs(p.z - tp.z)) - TILE * 0.5
		if d < bd:
			bd = d
			best = Vector3(tp.x, 0.3, tp.z)
	return {"pos": best, "dist": bd}


func _is_exposed(cell):
	for d in DIRS:
		if not tiles.has(cell + d):
			return true
	return false


func attack_point(cell, from):
	var tp = cell_pos(cell)
	var best = tp
	var bd = 1000000.0
	for d in DIRS:
		if tiles.has(cell + d):
			continue
		var pt = tp + Vector3(d.x, 0, d.y) * (TILE * 0.5 + 1.0)
		var dd = Vector2(pt.x - from.x, pt.z - from.z).length()
		if dd < bd:
			bd = dd
			best = pt
	return best


func nearest_edge_cell(from):
	var best = INVALID
	var bd = 1000000.0
	for c in tiles:
		if c == Vector2i(0, 0):
			continue
		if not _is_exposed(c):
			continue
		var pt = attack_point(c, from)
		var dd = Vector2(pt.x - from.x, pt.z - from.z).length()
		if dd < bd:
			bd = dd
			best = c
	return best


func bite(cell):
	if not tiles.has(cell) or cell == Vector2i(0, 0):
		return false
	hp[cell] -= 1
	if hp[cell] <= 0:
		tiles[cell].queue_free()
		tiles.erase(cell)
		hp.erase(cell)
		Game.say("Sebuah pondasi hancur digigit hiu!")
		return true
	return false


func add_purifier_visual():
	purifier_count += 1
	var n = purifier_count - 1
	var holder = Node3D.new()
	var mat_tank = StandardMaterial3D.new()
	mat_tank.albedo_color = Color(0.3, 0.6, 0.85)
	var mat_top = StandardMaterial3D.new()
	mat_top.albedo_color = Color(0.6, 0.6, 0.65)
	var tank = MeshInstance3D.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 0.3
	cm.bottom_radius = 0.3
	cm.height = 0.9
	tank.mesh = cm
	tank.material_override = mat_tank
	tank.position = Vector3(0, 0.45, 0)
	holder.add_child(tank)
	var cone = MeshInstance3D.new()
	var cn = CylinderMesh.new()
	cn.top_radius = 0.0
	cn.bottom_radius = 0.38
	cn.height = 0.35
	cone.mesh = cn
	cone.material_override = mat_top
	cone.position = Vector3(0, 1.05, 0)
	holder.add_child(cone)
	add_child(holder)
	holder.position = Vector3(-0.8 + 0.8 * (n % 3), 0.3, 1.0 - 0.8 * floori(n / 3.0))
