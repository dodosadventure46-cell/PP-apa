extends Node3D

const OceanScript = preload("res://scripts/ocean.gd")
const RaftScript = preload("res://scripts/raft.gd")
const PlayerScript = preload("res://scripts/player.gd")
const DebrisScript = preload("res://scripts/debris.gd")
const SharkScript = preload("res://scripts/shark.gd")
const HudScript = preload("res://scripts/hud.gd")

var ocean
var raft
var player
var hud
var sun
var world_env
var sky_mat
var spawn_timer = 1.2
var shark_timer = 52.0
var build_mode = false


func _ready():
	_setup_environment()
	ocean = OceanScript.new()
	add_child(ocean)
	raft = RaftScript.new()
	add_child(raft)
	player = PlayerScript.new()
	player.raft = raft
	add_child(player)
	player.setup_world_fx(self)
	player.global_position = Vector3(1.5, 0.65, 1.5)
	hud = HudScript.new()
	hud.player = player
	hud.main_node = self
	add_child(hud)
	Game.purifier_added.connect(raft.add_purifier_visual)
	Game.grill_added.connect(raft.add_grill_visual)
	Game.lantern_added.connect(raft.add_lantern_visual)
	Game.settings_changed.connect(_apply_env_settings)
	Game.world_loaded.connect(_on_world_loaded)
	_apply_env_settings()
	for i in range(11):
		spawn_debris(true)


func _on_world_loaded():
	set_build_mode_state(false)
	for s in get_tree().get_nodes_in_group("shark"):
		if s != null and is_instance_valid(s):
			s.queue_free()
	for d in get_tree().get_nodes_in_group("debris"):
		if d != null and is_instance_valid(d):
			d.queue_free()
	raft.rebuild_from_game_state()
	player._reset_hook()
	player.fishing = false
	player.velocity = Vector3.ZERO
	player.global_position = Vector3(1.5, 0.65, 1.5)
	for i in range(11):
		spawn_debris(true)
	shark_timer = 55.0


func _setup_environment():
	var env = Environment.new()
	var sky = Sky.new()
	sky_mat = ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.06, 0.15, 0.32)
	sky_mat.sky_horizon_color = Color(0.16, 0.28, 0.44)
	sky_mat.ground_horizon_color = Color(0.10, 0.20, 0.34)
	sky_mat.ground_bottom_color = Color(0.02, 0.06, 0.14)
	sky.sky_material = sky_mat
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.48
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 0.72
	env.fog_enabled = true
	env.fog_light_color = Color(0.12, 0.22, 0.36)
	env.fog_density = 0.0045
	world_env = WorldEnvironment.new()
	world_env.environment = env
	add_child(world_env)

	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48.0, -30.0, 0.0)
	sun.light_energy = 0.68
	sun.shadow_enabled = false
	sun.directional_shadow_max_distance = 45.0
	add_child(sun)


func _apply_env_settings():
	if sun != null:
		sun.shadow_enabled = bool(Game.settings.get("shadows", false))
	if world_env != null and world_env.environment != null:
		var vd = int(Game.settings.get("view_dist", 1))
		if vd <= 0:
			world_env.environment.fog_density = 0.0085
		elif vd == 1:
			world_env.environment.fog_density = 0.0045
		else:
			world_env.environment.fog_density = 0.0022
		var br = clamp(float(Game.settings.get("brightness", 0.75)), 0.30, 1.30)
		world_env.environment.tonemap_exposure = clamp(br * 0.92, 0.28, 1.25)


func _update_day_night():
	if sun == null or sky_mat == null or world_env == null:
		return
	var tod = Game.time_of_day
	var elev = sin((tod - 0.22) * TAU)
	var day_f = clamp(elev * 1.4 + 0.5, 0.0, 1.0)
	var sunset_f = clamp(1.0 - abs(elev) * 3.2, 0.0, 1.0)
	var br = clamp(float(Game.settings.get("brightness", 0.75)), 0.30, 1.30)

	# Darker, soothing deep-marine sky colors so the screen is never blinding
	var top_day = Color(0.06, 0.16, 0.34) * clamp(br * 1.15, 0.45, 1.25)
	var top_night = Color(0.015, 0.035, 0.09)
	var hor_day = Color(0.16, 0.28, 0.44) * clamp(br * 1.12, 0.45, 1.25)
	var hor_sunset = Color(0.58, 0.30, 0.16) * clamp(br * 1.1, 0.45, 1.2)
	var hor_night = Color(0.03, 0.06, 0.13)

	var cur_top = top_night.lerp(top_day, day_f)
	var cur_hor = hor_night.lerp(hor_day, day_f).lerp(hor_sunset, sunset_f * 0.60)
	sky_mat.sky_top_color = cur_top
	sky_mat.sky_horizon_color = cur_hor
	sky_mat.ground_horizon_color = cur_hor.darkened(0.25)
	world_env.environment.fog_light_color = cur_hor.darkened(0.18)
	world_env.environment.ambient_light_energy = lerp(0.24, 0.56, day_f) * clamp(br * 1.15, 0.40, 1.35)
	world_env.environment.tonemap_exposure = clamp(br * 0.92, 0.28, 1.25)
	sun.light_energy = lerp(0.12, 0.72, day_f) * clamp(br * 1.15, 0.35, 1.35)
	sun.light_color = Color(0.94, 0.91, 0.84).lerp(Color(0.92, 0.54, 0.30), sunset_f * 0.65)
	sun.rotation_degrees = Vector3(lerp(-18.0, -62.0, day_f), -30.0 + tod * 120.0, 0.0)


func spawn_debris(initial):
	var kinds = ["wood", "wood", "wood", "plastic", "plastic", "scrap", "leaf", "leaf", "barrel", "crate"]
	var d = DebrisScript.new()
	d.kind = kinds.pick_random()
	add_child(d)
	var x = randf_range(-56.0, -38.0)
	if initial:
		x = randf_range(-40.0, 24.0)
	d.global_position = Vector3(x, 0.0, randf_range(-15.0, 18.0))


func spawn_shark():
	var s = SharkScript.new()
	s.raft = raft
	s.player = player
	add_child(s)
	var ang = randf() * TAU
	s.angle = ang
	s.global_position = raft.center() + Vector3(cos(ang), 0.0, sin(ang)) * 26.0
	Game.say("Hiu mendekat ke rakit! Siapkan Tombak!")
	Game.play_sfx("bite", 0.75, 0.7)


func set_build_mode_state(on):
	build_mode = on
	if raft != null:
		raft.set_ghost_active(build_mode)
	if hud != null:
		hud.set_build_mode(build_mode)
	Game.play_sfx("ui", 1.0, 0.8)


func toggle_build():
	set_build_mode_state(not build_mode)
	if build_mode:
		Game.say("MODE BANGUN AKTIF: Arahkan + ke pinggir rakit lalu tekan PASANG")
	else:
		Game.say("Mode Bangun dinonaktifkan")


func place_foundation():
	if not build_mode:
		return
	if Game.count("foundation") < 1:
		Game.say("Belum punya Pondasi. Buat dulu di menu TAS")
		return
	if not raft.ghost_valid:
		Game.say("Arahkan + ke air tepat di samping rakit (kotak hijau)")
		return
	raft.add_tile(raft.ghost_cell)
	Game.spend({"foundation": 1})
	Game.save_current_world(raft.export_tile_list())
	Game.say("Pondasi baru berhasil dipasang!")
	Game.play_sfx("build", 1.0, 0.95)


func _process(delta):
	_update_day_night()
	if Game.dead or not Game.in_world or Game.menu_open:
		raft.set_ghost_active(false)
		return
	spawn_timer -= delta
	if spawn_timer <= 0.0:
		spawn_timer = randf_range(1.9, 3.8)
		if get_tree().get_nodes_in_group("debris").size() < 20:
			spawn_debris(false)
	shark_timer -= delta
	if shark_timer <= 0.0:
		shark_timer = randf_range(55.0, 88.0)
		var max_sharks = 1
		if raft.tiles.size() >= 10:
			max_sharks = 2
		if get_tree().get_nodes_in_group("shark").size() < max_sharks:
			spawn_shark()
	if build_mode:
		var cam = player.cam
		raft.update_ghost(cam.global_position, -cam.global_transform.basis.z)
	else:
		raft.set_ghost_active(false)
