extends Node3D

const OceanScript = preload("res://scripts/ocean.gd")
const RaftScript = preload("res://scripts/raft.gd")
const PlayerScript = preload("res://scripts/player.gd")
const DebrisScript = preload("res://scripts/debris.gd")
const SharkScript = preload("res://scripts/shark.gd")
const HudScript = preload("res://scripts/hud.gd")
const PixelUI = preload("res://scripts/pixel_ui.gd")


class IslandNode extends Area3D:
	var node_kind = "tree"
	var hp = 3.0

	func _init(k = "tree"):
		node_kind = k
		add_to_group("island_node")
		collision_layer = 4
		collision_mask = 0
		monitoring = false

	func get_prompt_text():
		if node_kind == "tree":
			return "POHON KELAPA (Pukul dgn SERANG / HOOK)"
		elif node_kind == "rock":
			return "BATU BESI TUA (Tambang dgn SERANG)"
		return "PETI HARTA PULAU! (Buka dgn SERANG)"

	func hit(dmg):
		hp -= dmg
		scale = Vector3(0.92, 1.08, 0.92)
		var tw = create_tween()
		tw.tween_property(self, "scale", Vector3.ONE, 0.14)
		Game.play_sfx("build" if node_kind != "chest" else "pickup", 1.0, 0.9)
		if hp <= 0.0:
			if node_kind == "tree":
				Game.add_item("wood", 2)
				Game.add_item("leaf", 2)
				Game.add_item("coconut", 1)
				Game.say("Pohon Kelapa ditebang: +2 Kayu, +2 Daun, +1 Kelapa!")
			elif node_kind == "rock":
				Game.add_item("scrap", 2)
				Game.add_item("plastic", 1)
				Game.say("Batu Karang ditambang: +2 Besi Tua, +1 Plastik!")
			elif node_kind == "chest":
				Game.add_item("can", 2)
				Game.add_item("water", 2)
				Game.add_item("scrap", 2)
				Game.add_item("rope", 2)
				Game.say("PETI HARTA PULAU DIBUKA: +2 Kaleng, +2 Air, +2 Besi, +2 Tali!")
			Game.play_sfx("pickup", 1.12, 0.95)
			queue_free()


class TropicalIsland extends Node3D:
	var drift_speed = 0.72

	func _ready():
		add_to_group("island")
		_build_island()

	func _build_island():
		# Walkable Beach & Plateau Collision Body (Layer 1 so player can walk on it!)
		var body = StaticBody3D.new()
		body.collision_layer = 1
		body.collision_mask = 0
		add_child(body)

		var cs_beach = CollisionShape3D.new()
		var cyl_shape = CylinderShape3D.new()
		cyl_shape.radius = 11.2
		cyl_shape.height = 1.6
		cs_beach.shape = cyl_shape
		cs_beach.position = Vector3(0, 0.35, 0)
		body.add_child(cs_beach)

		var beach_mi = MeshInstance3D.new()
		var bm = CylinderMesh.new()
		bm.top_radius = 9.2
		bm.bottom_radius = 13.0
		bm.height = 1.8
		beach_mi.mesh = bm
		beach_mi.material_override = PixelUI.make_3d_mat("sand_beach", Vector3(4, 2, 4), true, 0.0, 0.92)
		beach_mi.position = Vector3(0, 0.25, 0)
		body.add_child(beach_mi)

		var grass_mi = MeshInstance3D.new()
		var gm = CylinderMesh.new()
		gm.top_radius = 6.2
		gm.bottom_radius = 8.4
		gm.height = 0.85
		grass_mi.mesh = gm
		grass_mi.material_override = PixelUI.make_3d_mat("grass_island", Vector3(3, 2, 3), true, 0.0, 0.90)
		grass_mi.position = Vector3(0, 1.25, 0)
		body.add_child(grass_mi)

		# 3 Harvestable Palm Trees
		for pt in [Vector3(-2.6, 1.5, -2.0), Vector3(2.8, 1.5, -1.6), Vector3(0.4, 1.5, 2.8)]:
			_add_palm_tree(pt)

		# 2 Harvestable Scrap/Rock Ore Nodes
		for rk in [Vector3(-4.5, 1.1, 2.2), Vector3(4.2, 1.1, 2.4)]:
			_add_rock_node(rk)

		# 1 Island Treasure Chest at the center peak
		_add_treasure_chest(Vector3(0.0, 1.68, -0.2))

	func _add_palm_tree(pos):
		var tree = IslandNode.new("tree")
		tree.hp = 3.0
		tree.position = pos
		var cs = CollisionShape3D.new()
		var bs = BoxShape3D.new()
		bs.size = Vector3(1.6, 4.4, 1.6)
		cs.shape = bs
		cs.position = Vector3(0, 2.1, 0)
		tree.add_child(cs)

		var mat_trunk = PixelUI.make_3d_mat("wood_log", Vector3(1, 2, 1), false, 0.0, 0.9)
		var mat_leaf = PixelUI.make_3d_mat("palm_leaf", Vector3(1, 1, 1), false, 0.0, 0.85)
		var trunk = MeshInstance3D.new()
		var cm = CylinderMesh.new()
		cm.top_radius = 0.20
		cm.bottom_radius = 0.32
		cm.height = 3.8
		trunk.mesh = cm
		trunk.material_override = mat_trunk
		trunk.position = Vector3(0, 1.9, 0)
		tree.add_child(trunk)

		for i in range(6):
			var frond = MeshInstance3D.new()
			var fm = BoxMesh.new()
			fm.size = Vector3(0.45, 0.08, 2.2)
			frond.mesh = fm
			frond.material_override = mat_leaf
			var ang = float(i) * TAU / 6.0
			frond.position = Vector3(sin(ang) * 0.9, 3.7, cos(ang) * 0.9)
			frond.rotation = Vector3(0.32, ang, 0.0)
			tree.add_child(frond)

		add_child(tree)

	func _add_rock_node(pos):
		var rk = IslandNode.new("rock")
		rk.hp = 3.0
		rk.position = pos
		var cs = CollisionShape3D.new()
		var sp = SphereShape3D.new()
		sp.radius = 1.25
		cs.shape = sp
		cs.position = Vector3(0, 0.5, 0)
		rk.add_child(cs)

		var m_rock = PixelUI.make_3d_mat("rock_stone", Vector3(2, 2, 2), true, 0.2, 0.85)
		var m_rust = PixelUI.make_3d_mat("rust_metal", Vector3(1, 1, 1), false, 0.65, 0.55)
		var b1 = MeshInstance3D.new()
		var bm1 = BoxMesh.new()
		bm1.size = Vector3(1.3, 0.9, 1.2)
		b1.mesh = bm1
		b1.material_override = m_rock
		b1.position = Vector3(0, 0.4, 0)
		b1.rotation = Vector3(0.15, 0.4, -0.1)
		rk.add_child(b1)

		var b2 = MeshInstance3D.new()
		var bm2 = BoxMesh.new()
		bm2.size = Vector3(0.75, 0.65, 0.75)
		b2.mesh = bm2
		b2.material_override = m_rust
		b2.position = Vector3(0.25, 0.75, 0.1)
		rk.add_child(b2)
		add_child(rk)

	func _add_treasure_chest(pos):
		var ch = IslandNode.new("chest")
		ch.hp = 1.5
		ch.position = pos
		var cs = CollisionShape3D.new()
		var bs = BoxShape3D.new()
		bs.size = Vector3(1.4, 1.2, 1.2)
		cs.shape = bs
		cs.position = Vector3(0, 0.45, 0)
		ch.add_child(cs)

		var box = MeshInstance3D.new()
		var bm = BoxMesh.new()
		bm.size = Vector3(0.95, 0.65, 0.68)
		box.mesh = bm
		box.material_override = PixelUI.make_3d_mat("wood_crate", Vector3(1, 1, 1), false, 0.1, 0.8)
		box.position = Vector3(0, 0.32, 0)
		ch.add_child(box)

		var band = MeshInstance3D.new()
		var bdm = BoxMesh.new()
		bdm.size = Vector3(0.99, 0.18, 0.72)
		band.mesh = bdm
		band.material_override = PixelUI.make_3d_mat("metal_steel", Vector3(1, 1, 1), false, 0.85, 0.3, Color(1.0, 0.84, 0.28))
		band.position = Vector3(0, 0.52, 0)
		ch.add_child(band)
		add_child(ch)

	func _process(delta):
		if not Game.anchor_down:
			global_position.x += drift_speed * delta
		global_position.y = OceanScript.height(global_position.x, global_position.z) * 0.25 - 0.15
		if global_position.x > 88.0:
			queue_free()


var ocean
var raft
var player
var hud
var sun
var world_env
var sky_mat
var spawn_timer = 1.2
var shark_timer = 52.0
var island_timer = 18.0
var build_mode = false


func _ready():
	_setup_environment()
	ocean = OceanScript.new()
	add_child(ocean)
	raft = RaftScript.new()
	add_child(raft)
	player = PlayerScript.new()
	player.raft = raft
	add_child(player)
	player.setup_world_fx(self)
	player.global_position = Vector3(1.5, 0.65, 1.5)
	hud = HudScript.new()
	hud.player = player
	hud.main_node = self
	add_child(hud)
	Game.purifier_added.connect(raft.add_purifier_visual)
	Game.grill_added.connect(raft.add_grill_visual)
	Game.lantern_added.connect(raft.add_lantern_visual)
	Game.anchor_added.connect(raft.add_anchor_visual)
	Game.settings_changed.connect(_apply_env_settings)
	Game.world_loaded.connect(_on_world_loaded)
	_apply_env_settings()
	for i in range(11):
		spawn_debris(true)
	spawn_island(true)


func _on_world_loaded():
	set_build_mode_state(false)
	for s in get_tree().get_nodes_in_group("shark"):
		if s != null and is_instance_valid(s):
			s.queue_free()
	for d in get_tree().get_nodes_in_group("debris"):
		if d != null and is_instance_valid(d):
			d.queue_free()
	for isl in get_tree().get_nodes_in_group("island"):
		if isl != null and is_instance_valid(isl):
			isl.queue_free()
	raft.rebuild_from_game_state()
	player._reset_hook()
	player.fishing = false
	player.velocity = Vector3.ZERO
	player.global_position = Vector3(1.5, 0.65, 1.5)
	for i in range(11):
		spawn_debris(true)
	spawn_island(true)
	shark_timer = 55.0
	island_timer = 45.0


func spawn_island(initial = false):
	if get_tree().get_nodes_in_group("island").size() >= 1:
		return
	var isl = TropicalIsland.new()
	add_child(isl)
	var ix = -36.0 if initial else -68.0
	var iz = randf_range(-24.0, -18.0) if randf() < 0.5 else randf_range(18.0, 25.0)
	isl.global_position = Vector3(ix, -0.15, iz)
	if not initial:
		Game.say("PULAU TROPIS terlihat di cakrawala! Siapkan Jangkar untuk mendarat.")


func _setup_environment():
	var env = Environment.new()
	var sky = Sky.new()
	sky_mat = ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.06, 0.15, 0.32)
	sky_mat.sky_horizon_color = Color(0.16, 0.28, 0.44)
	sky_mat.ground_horizon_color = Color(0.10, 0.20, 0.34)
	sky_mat.ground_bottom_color = Color(0.02, 0.06, 0.14)
	sky.sky_material = sky_mat
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.48
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 0.72
	env.fog_enabled = true
	env.fog_light_color = Color(0.12, 0.22, 0.36)
	env.fog_density = 0.0045
	world_env = WorldEnvironment.new()
	world_env.environment = env
	add_child(world_env)

	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48.0, -30.0, 0.0)
	sun.light_energy = 0.68
	sun.shadow_enabled = false
	sun.directional_shadow_max_distance = 45.0
	add_child(sun)


func _apply_env_settings():
	if sun != null:
		sun.shadow_enabled = bool(Game.settings.get("shadows", false))
	if world_env != null and world_env.environment != null:
		var vd = int(Game.settings.get("view_dist", 1))
		if vd <= 0:
			world_env.environment.fog_density = 0.0085
		elif vd == 1:
			world_env.environment.fog_density = 0.0045
		else:
			world_env.environment.fog_density = 0.0022
		var br = clamp(float(Game.settings.get("brightness", 0.75)), 0.30, 1.30)
		world_env.environment.tonemap_exposure = clamp(br * 0.92, 0.28, 1.25)


func _update_day_night():
	if sun == null or sky_mat == null or world_env == null:
		return
	var tod = Game.time_of_day
	var elev = sin((tod - 0.22) * TAU)
	var day_f = clamp(elev * 1.4 + 0.5, 0.0, 1.0)
	var sunset_f = clamp(1.0 - abs(elev) * 3.2, 0.0, 1.0)
	var br = clamp(float(Game.settings.get("brightness", 0.75)), 0.30, 1.30)

	var top_day = Color(0.06, 0.16, 0.34) * clamp(br * 1.15, 0.45, 1.25)
	var top_night = Color(0.015, 0.035, 0.09)
	var hor_day = Color(0.16, 0.28, 0.44) * clamp(br * 1.12, 0.45, 1.25)
	var hor_sunset = Color(0.58, 0.30, 0.16) * clamp(br * 1.1, 0.45, 1.2)
	var hor_night = Color(0.03, 0.06, 0.13)

	var cur_top = top_night.lerp(top_day, day_f)
	var cur_hor = hor_night.lerp(hor_day, day_f).lerp(hor_sunset, sunset_f * 0.60)
	sky_mat.sky_top_color = cur_top
	sky_mat.sky_horizon_color = cur_hor
	sky_mat.ground_horizon_color = cur_hor.darkened(0.25)
	world_env.environment.fog_light_color = cur_hor.darkened(0.18)
	world_env.environment.ambient_light_energy = lerp(0.24, 0.56, day_f) * clamp(br * 1.15, 0.40, 1.35)
	world_env.environment.tonemap_exposure = clamp(br * 0.92, 0.28, 1.25)
	sun.light_energy = lerp(0.12, 0.72, day_f) * clamp(br * 1.15, 0.35, 1.35)
	sun.light_color = Color(0.94, 0.91, 0.84).lerp(Color(0.92, 0.54, 0.30), sunset_f * 0.65)
	sun.rotation_degrees = Vector3(lerp(-18.0, -62.0, day_f), -30.0 + tod * 120.0, 0.0)


func spawn_debris(initial):
	var kinds = ["wood", "wood", "wood", "plastic", "plastic", "scrap", "leaf", "leaf", "barrel", "crate"]
	var d = DebrisScript.new()
	d.kind = kinds.pick_random()
	add_child(d)
	var x = randf_range(-56.0, -38.0)
	if initial:
		x = randf_range(-40.0, 24.0)
	d.global_position = Vector3(x, 0.0, randf_range(-15.0, 18.0))


func spawn_shark():
	var s = SharkScript.new()
	s.raft = raft
	s.player = player
	add_child(s)
	var ang = randf() * TAU
	s.angle = ang
	s.global_position = raft.center() + Vector3(cos(ang), 0.0, sin(ang)) * 26.0
	Game.say("Hiu mendekat ke rakit! Siapkan Tombak!")
	Game.play_sfx("bite", 0.75, 0.7)


func set_build_mode_state(on):
	build_mode = on
	if raft != null:
		raft.set_ghost_active(build_mode)
	if hud != null:
		hud.set_build_mode(build_mode)
	Game.play_sfx("ui", 1.0, 0.8)


func toggle_build():
	set_build_mode_state(not build_mode)
	if build_mode:
		Game.say("MODE BANGUN AKTIF: Arahkan + ke pinggir rakit lalu tekan PASANG")
	else:
		Game.say("Mode Bangun dinonaktifkan")


func place_foundation():
	if not build_mode and Game.get_selected_item_id() != "foundation":
		return
	if Game.count("foundation") < 1:
		Game.say("Belum punya Pondasi. Buat dulu di menu TAS")
		return
	if not raft.ghost_valid:
		Game.say("Arahkan + ke air tepat di samping rakit (kotak hijau)")
		return
	raft.add_tile(raft.ghost_cell)
	Game.spend({"foundation": 1})
	Game.save_current_world(raft.export_tile_list())
	Game.say("Pondasi baru berhasil dipasang!")
	Game.play_sfx("build", 1.0, 0.95)


func _process(delta):
	_update_day_night()
	if Game.dead or not Game.in_world or Game.menu_open:
		raft.set_ghost_active(false)
		return
	if not Game.anchor_down:
		spawn_timer -= delta
		if spawn_timer <= 0.0:
			spawn_timer = randf_range(1.9, 3.8)
			if get_tree().get_nodes_in_group("debris").size() < 20:
				spawn_debris(false)
		island_timer -= delta
		if island_timer <= 0.0:
			island_timer = randf_range(40.0, 65.0)
			spawn_island(false)
	shark_timer -= delta
	if shark_timer <= 0.0:
		shark_timer = randf_range(55.0, 88.0)
		var max_sharks = 1
		if raft.tiles.size() >= 10:
			max_sharks = 2
		if get_tree().get_nodes_in_group("shark").size() < max_sharks:
			spawn_shark()
	var want_ghost = build_mode or (Game.get_selected_item_id() == "foundation")
	if want_ghost:
		var cam = player.cam
		raft.update_ghost(cam.global_position, -cam.global_transform.basis.z)
	else:
		raft.set_ghost_active(false)
