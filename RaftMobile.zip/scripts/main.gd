extends Node3D

const OceanScript = preload("res://scripts/ocean.gd")
const RaftScript = preload("res://scripts/raft.gd")
const PlayerScript = preload("res://scripts/player.gd")
const HudScript = preload("res://scripts/hud.gd")
const DebrisScript = preload("res://scripts/debris.gd")
const SharkScript = preload("res://scripts/shark.gd")

var raft
var player
var hud
var spawn_timer = 1.0
var shark_timer = 60.0
var build_mode = false


func _ready():
	randomize()
	Game.reset()
	_setup_environment()

	var ocean = OceanScript.new()
	add_child(ocean)

	raft = RaftScript.new()
	add_child(raft)

	player = PlayerScript.new()
	player.raft = raft
	add_child(player)
	player.global_position = Vector3(1.5, 0.6, 1.5)

	hud = HudScript.new()
	hud.player = player
	hud.main_node = self
	add_child(hud)

	Game.purifier_added.connect(raft.add_purifier_visual)

	for i in range(9):
		spawn_debris(true)


func _setup_environment():
	var env = Environment.new()
	var sky = Sky.new()
	var sm = ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.25, 0.5, 0.85)
	sm.sky_horizon_color = Color(0.7, 0.85, 0.95)
	sm.ground_horizon_color = Color(0.7, 0.85, 0.95)
	sm.ground_bottom_color = Color(0.3, 0.5, 0.65)
	sky.sky_material = sm
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 1.0
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.7, 0.85, 0.95)
	env.fog_density = 0.006
	var we = WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-45.0, -30.0, 0.0)
	sun.light_energy = 1.2
	sun.shadow_enabled = false
	add_child(sun)


func spawn_debris(initial):
	var kinds = ["wood", "wood", "wood", "plastic", "plastic", "scrap", "leaf", "barrel"]
	var d = DebrisScript.new()
	d.kind = kinds.pick_random()
	add_child(d)
	var x = randf_range(-55.0, -38.0)
	if initial:
		x = randf_range(-40.0, 25.0)
	d.global_position = Vector3(x, 0.0, randf_range(-14.0, 17.0))


func spawn_shark():
	var s = SharkScript.new()
	s.raft = raft
	s.player = player
	add_child(s)
	var ang = randf() * TAU
	s.angle = ang
	s.global_position = raft.center() + Vector3(cos(ang), 0.0, sin(ang)) * 26.0
	Game.say("Hiu mendekat! Siapkan tombak")


func toggle_build():
	build_mode = not build_mode
	raft.set_ghost_active(build_mode)
	hud.set_build_mode(build_mode)


func place_foundation():
	if not build_mode:
		return
	if Game.count("foundation") < 1:
		Game.say("Belum punya Pondasi. Buat dulu di menu TAS")
		return
	if not raft.ghost_valid:
		Game.say("Arahkan + ke air di samping rakit (kotak hijau)")
		return
	raft.add_tile(raft.ghost_cell)
	Game.spend({"foundation": 1})
	Game.say("Pondasi dipasang")


func _process(delta):
	if Game.dead:
		return
	spawn_timer -= delta
	if spawn_timer <= 0.0:
		spawn_timer = randf_range(2.0, 4.0)
		if get_tree().get_nodes_in_group("debris").size() < 18:
			spawn_debris(false)
	shark_timer -= delta
	if shark_timer <= 0.0:
		shark_timer = randf_range(55.0, 90.0)
		var max_sharks = 1
		if raft.tiles.size() >= 10:
			max_sharks = 2
		if get_tree().get_nodes_in_group("shark").size() < max_sharks:
			spawn_shark()
	if build_mode:
		var cam = player.cam
		raft.update_ghost(cam.global_position, -cam.global_transform.basis.z)
