extends Node

signal inventory_changed
signal stats_changed
signal message(text)
signal player_died
signal purifier_added
signal grill_added
signal lantern_added
signal settings_changed
signal world_loaded

const SETTINGS_PATH = "user://raft_settings.cfg"
const WORLDS_PATH = "user://raft_worlds.cfg"

const ITEM_NAMES = {
	"wood": "Kayu Apung",
	"plastic": "Plastik",
	"scrap": "Besi Tua",
	"leaf": "Daun Palem",
	"rope": "Tali Serat",
	"coconut": "Kelapa Segar",
	"can": "Makanan Kaleng",
	"water": "Air Minum",
	"fish": "Ikan Mentah",
	"cooked_fish": "Ikan Bakar",
	"meat": "Daging Hiu",
	"cooked_meat": "Steak Hiu Bakar",
	"foundation": "Pondasi Rakit",
}

const USABLE = ["water", "coconut", "cooked_fish", "cooked_meat", "can", "fish", "meat"]

const RECIPES = [
	{"id": "foundation", "name": "Pondasi Rakit (+Perluas)", "cost": {"wood": 4, "plastic": 2}},
	{"id": "rope", "name": "Tali Serat (x2)", "cost": {"leaf": 2}},
	{"id": "spear", "name": "Tombak Besi (Senjata Hiu)", "cost": {"wood": 3, "scrap": 2}},
	{"id": "rod", "name": "Alat Pancing Laut", "cost": {"wood": 2, "plastic": 2, "leaf": 1}},
	{"id": "purifier", "name": "Penyaring Air Laut Otomatis", "cost": {"wood": 5, "plastic": 4, "scrap": 2}},
	{"id": "grill", "name": "Pemanggang Ikan & Daging", "cost": {"wood": 4, "scrap": 2, "leaf": 2}},
	{"id": "lantern", "name": "Lentera Rakit (Penerang Malam)", "cost": {"wood": 2, "scrap": 2, "plastic": 1}},
]

var inventory = {}
var health = 100.0
var hunger = 100.0
var thirst = 100.0
var dead = false
var menu_open = true
var in_world = false
var current_slot = 1
var world_name = "Samudra Biru #1"
var world_difficulty = "survival"
var saved_tiles = [[0, 0], [1, 0], [0, 1], [1, 1]]

var has_rod = false
var has_spear = false
var purifiers = 0
var grills = 0
var lanterns = 0
var purifier_timer = 0.0
var grill_timer = 0.0
var stat_timer = 0.0
var autosave_timer = 0.0
var day_count = 1
var time_of_day = 0.32

var worlds_meta = {}

var settings = {
	"gfx_preset": "medium",
	"res_scale": 1.0,
	"max_fps": 60,
	"shadows": false,
	"wave_quality": 2,
	"view_dist": 1,
	"fov": 75.0,
	"show_fps": true,
	"sfx_vol": 0.85,
	"amb_vol": 0.55,
	"sens": 1.0,
	"invert_y": false,
	"hook_charge_mode": true,
	"auto_reel": true,
	"hud_scale": 1.0,
	"hud_opacity": 0.92,
	"custom_hud": {},
}


func _ready():
	load_settings()
	load_worlds_index()
	reset()
	apply_settings()


func play_sfx(id, pitch = 1.0, vol_mul = 1.0):
	var sfx_node = get_node_or_null("/root/Sfx")
	if sfx_node != null and sfx_node.has_method("play"):
		sfx_node.play(id, pitch, vol_mul)


func play_reel_tick():
	var sfx_node = get_node_or_null("/root/Sfx")
	if sfx_node != null and sfx_node.has_method("play_reel_tick"):
		sfx_node.play_reel_tick()


func reset():
	if world_difficulty == "peaceful":
		inventory = {"wood": 16, "plastic": 12, "scrap": 6, "leaf": 8, "water": 4, "coconut": 3, "can": 2}
	elif world_difficulty == "hardcore":
		inventory = {"wood": 4, "plastic": 4, "scrap": 1, "leaf": 2, "water": 1}
	else:
		inventory = {"wood": 8, "plastic": 6, "scrap": 2, "leaf": 4, "water": 2, "coconut": 1, "can": 1}
	health = 100.0
	hunger = 100.0
	thirst = 100.0
	dead = false
	has_rod = false
	has_spear = false
	purifiers = 0
	grills = 0
	lanterns = 0
	purifier_timer = 0.0
	grill_timer = 0.0
	day_count = 1
	time_of_day = 0.32
	saved_tiles = [[0, 0], [1, 0], [0, 1], [1, 1]]
	inventory_changed.emit()
	stats_changed.emit()


func load_worlds_index():
	worlds_meta = {}
	var cfg = ConfigFile.new()
	if cfg.load(WORLDS_PATH) != OK:
		return
	for slot in [1, 2, 3, 4]:
		var sec = "world_%d" % slot
		if cfg.has_section(sec):
			worlds_meta[slot] = {
				"name": cfg.get_value(sec, "name", "Dunia #%d" % slot),
				"difficulty": cfg.get_value(sec, "difficulty", "survival"),
				"day_count": cfg.get_value(sec, "day_count", 1),
				"time_of_day": cfg.get_value(sec, "time_of_day", 0.32),
				"health": cfg.get_value(sec, "health", 100.0),
				"hunger": cfg.get_value(sec, "hunger", 100.0),
				"thirst": cfg.get_value(sec, "thirst", 100.0),
				"inventory": cfg.get_value(sec, "inventory", {}),
				"has_rod": cfg.get_value(sec, "has_rod", false),
				"has_spear": cfg.get_value(sec, "has_spear", false),
				"purifiers": cfg.get_value(sec, "purifiers", 0),
				"grills": cfg.get_value(sec, "grills", 0),
				"lanterns": cfg.get_value(sec, "lanterns", 0),
				"tiles": cfg.get_value(sec, "tiles", [[0, 0], [1, 0], [0, 1], [1, 1]]),
			}


func has_world_slot(slot):
	return worlds_meta.has(slot)


func create_new_world(slot, w_name, diff):
	current_slot = slot
	world_name = w_name if w_name.strip_edges() != "" else ("Samudra #%d" % slot)
	world_difficulty = diff
	reset()
	save_current_world([[0, 0], [1, 0], [0, 1], [1, 1]])
	world_loaded.emit()


func load_world_slot(slot):
	load_worlds_index()
	if not worlds_meta.has(slot):
		create_new_world(slot, "Samudra #%d" % slot, "survival")
		return
	current_slot = slot
	var d = worlds_meta[slot]
	world_name = str(d.get("name", "Samudra #%d" % slot))
	world_difficulty = str(d.get("difficulty", "survival"))
	day_count = int(d.get("day_count", 1))
	time_of_day = float(d.get("time_of_day", 0.32))
	health = clamp(float(d.get("health", 100.0)), 15.0, 100.0)
	hunger = clamp(float(d.get("hunger", 100.0)), 20.0, 100.0)
	thirst = clamp(float(d.get("thirst", 100.0)), 20.0, 100.0)
	inventory = d.get("inventory", {"wood": 8, "plastic": 6}).duplicate()
	has_rod = bool(d.get("has_rod", false))
	has_spear = bool(d.get("has_spear", false))
	purifiers = int(d.get("purifiers", 0))
	grills = int(d.get("grills", 0))
	lanterns = int(d.get("lanterns", 0))
	saved_tiles = d.get("tiles", [[0, 0], [1, 0], [0, 1], [1, 1]])
	dead = false
	inventory_changed.emit()
	stats_changed.emit()
	world_loaded.emit()


func delete_world_slot(slot):
	load_worlds_index()
	worlds_meta.erase(slot)
	var cfg = ConfigFile.new()
	for s in worlds_meta.keys():
		var sec = "world_%d" % s
		var w = worlds_meta[s]
		for k in w.keys():
			cfg.set_value(sec, k, w[k])
	cfg.save(WORLDS_PATH)


func save_current_world(tile_list = null):
	if tile_list != null:
		saved_tiles = tile_list
	worlds_meta[current_slot] = {
		"name": world_name,
		"difficulty": world_difficulty,
		"day_count": day_count,
		"time_of_day": time_of_day,
		"health": health,
		"hunger": hunger,
		"thirst": thirst,
		"inventory": inventory.duplicate(),
		"has_rod": has_rod,
		"has_spear": has_spear,
		"purifiers": purifiers,
		"grills": grills,
		"lanterns": lanterns,
		"tiles": saved_tiles,
	}
	var cfg = ConfigFile.new()
	for s in worlds_meta.keys():
		var sec = "world_%d" % s
		var w = worlds_meta[s]
		for k in w.keys():
			cfg.set_value(sec, k, w[k])
	cfg.save(WORLDS_PATH)


func load_settings():
	var cfg = ConfigFile.new()
	if cfg.load(SETTINGS_PATH) != OK:
		return
	for k in settings.keys():
		if cfg.has_section_key("settings", k):
			settings[k] = cfg.get_value("settings", k, settings[k])


func save_settings():
	var cfg = ConfigFile.new()
	for k in settings.keys():
		cfg.set_value("settings", k, settings[k])
	cfg.save(SETTINGS_PATH)
	apply_settings()


func apply_gfx_preset(preset):
	settings["gfx_preset"] = preset
	if preset == "low":
		settings["res_scale"] = 0.75
		settings["max_fps"] = 60
		settings["shadows"] = false
		settings["wave_quality"] = 1
		settings["view_dist"] = 0
	elif preset == "medium":
		settings["res_scale"] = 1.0
		settings["max_fps"] = 60
		settings["shadows"] = false
		settings["wave_quality"] = 2
		settings["view_dist"] = 1
	elif preset == "high":
		settings["res_scale"] = 1.0
		settings["max_fps"] = 60
		settings["shadows"] = true
		settings["wave_quality"] = 3
		settings["view_dist"] = 2
	save_settings()


func apply_settings():
	Engine.max_fps = int(settings.get("max_fps", 60))
	var sfx_node = get_node_or_null("/root/Sfx")
	if sfx_node != null and sfx_node.has_method("update_volumes"):
		sfx_node.update_volumes(float(settings.get("sfx_vol", 0.85)), float(settings.get("amb_vol", 0.55)))
	settings_changed.emit()


func reset_custom_hud():
	settings["custom_hud"] = {}
	settings["hud_scale"] = 1.0
	settings["hud_opacity"] = 0.92
	save_settings()


func say(t):
	message.emit(t)


func count(id):
	return inventory.get(id, 0)


func add_item(id, n = 1):
	inventory[id] = count(id) + n
	inventory_changed.emit()


func has_items(cost):
	for k in cost:
		if count(k) < cost[k]:
			return false
	return true


func spend(cost):
	for k in cost:
		inventory[k] = count(k) - cost[k]
		if inventory[k] <= 0:
			inventory.erase(k)
	inventory_changed.emit()


func craft(id):
	if dead:
		return
	var recipe = null
	for r in RECIPES:
		if r["id"] == id:
			recipe = r
	if recipe == null:
		return
	if not has_items(recipe["cost"]):
		say("Bahan belum cukup untuk membuat " + recipe["name"])
		return
	if id == "rod" and has_rod:
		return
	if id == "spear" and has_spear:
		return
	spend(recipe["cost"])
	match id:
		"foundation":
			add_item("foundation", 1)
			say("Pondasi Rakit dibuat! Tekan BANGUN untuk memasang.")
		"rope":
			add_item("rope", 2)
			say("+2 Tali Serat dibuat!")
		"rod":
			has_rod = true
			say("Alat Pancing siap! Tekan tombol PANCING di HUD.")
		"spear":
			has_spear = true
			say("Tombak Besi siap! Gunakan tombol SERANG.")
		"purifier":
			purifiers += 1
			purifier_added.emit()
			say("Penyaring Air dipasang di rakit (air minum otomatis).")
		"grill":
			grills += 1
			grill_added.emit()
			say("Pemanggang dipasang! Otomatis memanggang ikan/daging mentah.")
		"lantern":
			lanterns += 1
			lantern_added.emit()
			say("Lentera Rakit dipasang! Menerangi rakit saat malam.")
	inventory_changed.emit()
	save_current_world()
	play_sfx("build", 1.05, 0.9)


func use_item(id):
	if dead or count(id) <= 0:
		return
	match id:
		"coconut":
			hunger = min(100.0, hunger + 14.0)
			thirst = min(100.0, thirst + 16.0)
		"can":
			hunger = min(100.0, hunger + 32.0)
			thirst = min(100.0, thirst + 8.0)
		"water":
			thirst = min(100.0, thirst + 38.0)
		"fish":
			hunger = min(100.0, hunger + 18.0)
		"cooked_fish":
			hunger = min(100.0, hunger + 42.0)
			health = min(100.0, health + 8.0)
		"meat":
			hunger = min(100.0, hunger + 28.0)
		"cooked_meat":
			hunger = min(100.0, hunger + 55.0)
			health = min(100.0, health + 15.0)
		_:
			return
	inventory[id] = count(id) - 1
	if inventory[id] <= 0:
		inventory.erase(id)
	inventory_changed.emit()
	stats_changed.emit()
	say("Mengonsumsi " + ITEM_NAMES.get(id, id))
	play_sfx("consume", 1.0, 0.85)


func collect(kind):
	if kind == "barrel" or kind == "crate":
		var loot = ["coconut", "can", "water", "wood", "plastic", "scrap", "leaf"]
		var prefix = "Tong Apung: " if kind == "barrel" else "Peti Laut: "
		var n = randi_range(2, 4) if kind == "crate" else randi_range(2, 3)
		for i in range(n):
			var it = loot.pick_random()
			add_item(it, 1)
			prefix += ITEM_NAMES[it]
			if i < n - 1:
				prefix += ", "
		say(prefix)
	else:
		add_item(kind, 1)
		say("+1 " + ITEM_NAMES.get(kind, kind))
	play_sfx("pickup", randf_range(0.96, 1.08), 0.85)


func catch_fish():
	var r = randf()
	if r < 0.72:
		if grills > 0:
			add_item("cooked_fish", 1)
			say("Dapat ikan & langsung dipanggang: +1 Ikan Bakar!")
		else:
			add_item("fish", 1)
			say("Berhasil memancing: +1 Ikan Mentah!")
	elif r < 0.88:
		add_item("plastic", 1)
		say("Kail mengangkat sampah: +1 Plastik")
	else:
		add_item("coconut", 1)
		say("Kail mengangkat Kelapa Segar!")
	play_sfx("pickup", 1.1, 0.9)


func damage(a):
	if dead:
		return
	health -= a
	stats_changed.emit()
	_check_death()


func _check_death():
	if health <= 0.0:
		health = 0.0
		dead = true
		stats_changed.emit()
		player_died.emit()


func _process(delta):
	if dead or menu_open or not in_world:
		return
	time_of_day += delta / 240.0
	if time_of_day >= 1.0:
		time_of_day -= 1.0
		day_count += 1
		save_current_world()
		say("Hari ke-%d dimulai di tengah samudra!" % day_count)

	var drain_mul = 0.65 if world_difficulty == "peaceful" else (1.35 if world_difficulty == "hardcore" else 1.0)
	hunger = max(0.0, hunger - 0.15 * drain_mul * delta)
	thirst = max(0.0, thirst - 0.21 * drain_mul * delta)
	if hunger <= 0.0 or thirst <= 0.0:
		health -= 1.15 * delta
	elif hunger > 35.0 and thirst > 35.0 and health < 100.0:
		health = min(100.0, health + 0.65 * delta)

	if purifiers > 0:
		purifier_timer += delta
		if purifier_timer >= 36.0:
			purifier_timer = 0.0
			var room = 12 - count("water")
			if room > 0:
				add_item("water", min(purifiers, room))
				say("Penyaring Air menghasilkan +Air Minum bersih!")
				play_sfx("pickup", 1.2, 0.6)

	if grills > 0:
		if count("fish") > 0 or count("meat") > 0:
			grill_timer += delta
			if grill_timer >= 14.0:
				grill_timer = 0.0
				if count("fish") > 0:
					spend({"fish": 1})
					add_item("cooked_fish", 1)
					say("Pemanggang selesai memasak: +1 Ikan Bakar!")
					play_sfx("pickup", 1.15, 0.7)
				elif count("meat") > 0:
					spend({"meat": 1})
					add_item("cooked_meat", 1)
					say("Pemanggang selesai memasak: +1 Steak Hiu Bakar!")
					play_sfx("pickup", 1.15, 0.7)
		else:
			grill_timer = 0.0

	autosave_timer += delta
	if autosave_timer >= 20.0:
		autosave_timer = 0.0
		save_current_world()

	stat_timer += delta
	if stat_timer > 0.2:
		stat_timer = 0.0
		stats_changed.emit()
	_check_death()
