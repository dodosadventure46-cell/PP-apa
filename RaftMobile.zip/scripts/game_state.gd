extends Node

const SfxScript = preload("res://scripts/sfx.gd")

signal inventory_changed
signal stats_changed
signal message(text)
signal player_died
signal purifier_added
signal grill_added
signal lantern_added
signal anchor_added
signal sail_added
signal crop_plot_added
signal hammock_added
signal cooking_pot_added
signal scarecrow_added
signal research_table_added
signal chest_added
signal settings_changed
signal world_loaded

const SETTINGS_PATH = "user://raft_settings.cfg"
const WORLDS_PATH = "user://raft_worlds.cfg"
const HOTBAR_SIZE = 8
const BAG_SIZE = 20

const ITEM_NAMES = {
	"hook": "Grappling Hook",
	"spear": "Tombak Besi",
	"bow": "Busur Panah",
	"arrow": "Anak Panah",
	"paddle": "Dayung Kayu",
	"hammer": "Palu Perbaikan",
	"rod": "Alat Pancing",
	"wood": "Kayu Apung",
	"plastic": "Plastik Laut",
	"scrap": "Besi Tua",
	"leaf": "Daun Palem",
	"rope": "Tali Serat",
	"seaweed": "Rumput Laut",
	"clay": "Tanah Liat & Pasir",
	"coconut": "Kelapa Segar",
	"can": "Makanan Kaleng",
	"water": "Air Minum",
	"fish": "Ikan Mentah",
	"cooked_fish": "Ikan Bakar",
	"meat": "Daging Hiu",
	"cooked_meat": "Steak Hiu Bakar",
	"fish_stew": "Sup Ikan Kelapa",
	"shark_bait": "Umpan Hiu",
	"foundation": "Pondasi Rakit",
	"wall": "Tembok Kayu",
	"window_wall": "Tembok Jendela",
	"fence": "Pagar Pelindung",
	"roof": "Atap & Tiang Tingkat 2",
	"stairs": "Tangga Kayu",
	"net": "Jaring Penangkap Sampah",
	"armor_tile": "Lapis Baja Pondasi",
	"decor": "Meja & Kursi Rakit",
	"sail": "Layar Kapal Kemudi",
	"anchor": "Jangkar Rakit",
	"crop_plot": "Petak Tanaman Kebun",
	"hammock": "Tempat Tidur Hammock",
	"cooking_pot": "Panci Masak Sup",
	"scarecrow": "Orang-Orangan Sawah",
	"research_table": "Meja Riset Rakit",
	"chest": "Peti Penyimpanan",
	"leaf_hat": "Topi Daun Palem",
	"wood_vest": "Rompi Papan Kayu",
	"rope_legs": "Pelindung Kaki Serat",
	"scrap_boots": "Sepatu Besi Laut",
}

const USABLE = ["water", "coconut", "cooked_fish", "cooked_meat", "fish_stew", "can", "fish", "meat"]
const NON_STACKABLE = ["hook", "spear", "bow", "paddle", "hammer", "rod", "leaf_hat", "wood_vest", "rope_legs", "scrap_boots"]
const BUILDABLE_ITEMS = ["foundation", "wall", "window_wall", "fence", "roof", "stairs", "net", "armor_tile", "decor"]

const ARMOR_DEFS = {
	"leaf_hat": {"name": "Topi Daun Palem", "slot": "head", "def": 8},
	"wood_vest": {"name": "Rompi Papan Kayu", "slot": "chest", "def": 18},
	"rope_legs": {"name": "Pelindung Kaki Serat", "slot": "legs", "def": 12},
	"scrap_boots": {"name": "Sepatu Besi Laut", "slot": "feet", "def": 10},
}

const RECIPES = [
	# Alat, Navigasi & Senjata
	{"id": "rope", "name": "Tali Serat (x2)", "cost": {"leaf": 2}},
	{"id": "paddle", "name": "Dayung Kayu (Kayuh Rakit Manual)", "cost": {"wood": 2, "plastic": 1}},
	{"id": "sail", "name": "Layar Kapal 360° (Berlayar ke Pulau)", "cost": {"wood": 4, "leaf": 4, "rope": 2}},
	{"id": "anchor", "name": "Jangkar Rakit (Stop di Pulau)", "cost": {"scrap": 2, "rope": 2, "wood": 2}},
	{"id": "hammer", "name": "Palu Perbaikan Pondasi Rakit", "cost": {"wood": 2, "scrap": 1, "rope": 1}},
	{"id": "spear", "name": "Tombak Besi (Senjata Hiu & Tebang)", "cost": {"wood": 3, "scrap": 2}},
	{"id": "bow", "name": "Busur Panah Jarak Jauh (+5 Panah)", "cost": {"wood": 3, "rope": 2, "leaf": 2}},
	{"id": "arrow", "name": "Anak Panah Besi (x6)", "cost": {"wood": 1, "scrap": 1}},
	{"id": "shark_bait", "name": "Umpan Hiu (Alihkan Hiu 40 Detik)", "cost": {"fish": 1, "rope": 1}},
	{"id": "rod", "name": "Alat Pancing Laut", "cost": {"wood": 2, "plastic": 2, "leaf": 1}},
	# Konstruksi Rakit (Tembok dll)
	{"id": "foundation", "name": "Pondasi Rakit (+Perluas Lantai)", "cost": {"wood": 4, "plastic": 2}},
	{"id": "wall", "name": "Tembok Kayu Rakit (x2)", "cost": {"wood": 3, "rope": 1}},
	{"id": "window_wall", "name": "Tembok Jendela Intai (x2)", "cost": {"wood": 3, "plastic": 1}},
	{"id": "fence", "name": "Pagar Pelindung Pinggir (x2)", "cost": {"wood": 2, "rope": 1}},
	{"id": "roof", "name": "Tiang & Atap Tingkat 2 (x2)", "cost": {"wood": 4, "leaf": 2}},
	{"id": "stairs", "name": "Tangga Naik Tingkat 2", "cost": {"wood": 4, "rope": 1}},
	{"id": "net", "name": "Jaring Penangkap Sampah Otomatis", "cost": {"wood": 2, "rope": 2, "plastic": 2}},
	{"id": "armor_tile", "name": "Lapis Baja Pondasi (Tahan Hiu 3x)", "cost": {"scrap": 2}},
	{"id": "decor", "name": "Meja & Kursi Dekorasi Rakit", "cost": {"wood": 3, "leaf": 1}},
	# Fasilitas Rakit & Pertanian
	{"id": "purifier", "name": "Bangunan: Penyaring Air Laut", "cost": {"wood": 4, "plastic": 3, "scrap": 1}},
	{"id": "grill", "name": "Bangunan: Pemanggang Ikan", "cost": {"wood": 3, "scrap": 2, "leaf": 2}},
	{"id": "cooking_pot", "name": "Bangunan: Panci Masak Sup", "cost": {"scrap": 3, "wood": 2, "clay": 1}},
	{"id": "fish_stew", "name": "Masak: Sup Ikan Kelapa Spesial", "cost": {"fish": 1, "coconut": 1, "water": 1}},
	{"id": "crop_plot", "name": "Bangunan: Petak Tanaman Kebun", "cost": {"wood": 4, "leaf": 3, "rope": 1}},
	{"id": "scarecrow", "name": "Bangunan: Orang-Orangan Sawah", "cost": {"wood": 2, "leaf": 4, "rope": 1}},
	{"id": "hammock", "name": "Bangunan: Hammock (Tidur Pagi)", "cost": {"wood": 3, "leaf": 4, "rope": 2}},
	{"id": "chest", "name": "Bangunan: Peti Penyimpanan Rakit", "cost": {"wood": 4, "scrap": 1, "rope": 1}},
	{"id": "research_table", "name": "Bangunan: Meja Riset Rakit", "cost": {"wood": 4, "scrap": 2, "plastic": 2}},
	{"id": "lantern", "name": "Bangunan: Lentera Rakit Malam", "cost": {"wood": 2, "scrap": 1, "plastic": 1}},
	# Armor Pelindung
	{"id": "leaf_hat", "name": "Armor: Topi Daun (+8% DEF)", "cost": {"leaf": 4, "rope": 1}},
	{"id": "wood_vest", "name": "Armor: Rompi Kayu (+18% DEF)", "cost": {"wood": 5, "rope": 2}},
	{"id": "rope_legs", "name": "Armor: Pelindung Kaki (+12% DEF)", "cost": {"rope": 2, "plastic": 3}},
	{"id": "scrap_boots", "name": "Armor: Sepatu Besi (+10% DEF)", "cost": {"scrap": 2, "plastic": 2}},
]

var sfx_ref = null
var inventory = {}
var hotbar = []
var bag_slots = []
var armor_slots = {"head": "", "chest": "", "legs": "", "feet": ""}
var selected_hotbar = 0

var health = 100.0
var hunger = 100.0
var thirst = 100.0
var oxygen = 100.0
var dead = false
var menu_open = true
var in_world = false
var current_slot = 1
var world_name = "Samudra Biru #1"
var world_difficulty = "survival"
var saved_tiles = [[0, 0], [1, 0], [0, 1], [1, 1]]
var saved_structures = []
var paint_theme = 0

var has_rod = false
var has_spear = false
var has_bow = false
var has_paddle = false
var has_hammer = false
var has_anchor = false
var anchor_down = false
var has_sail = false
var sail_open = false
var sail_angle = 0.0
var paddle_boost_t = 0.0

var purifiers = 0
var grills = 0
var lanterns = 0
var crop_plots = 0
var hammocks = 0
var cooking_pots = 0
var scarecrows = 0
var research_tables = 0
var chests = 0
var research_points = 0

var purifier_timer = 0.0
var grill_timer = 0.0
var crop_timer = 0.0
var stat_timer = 0.0
var autosave_timer = 0.0
var weather_timer = 48.0
var weather_state = "cerah"
var wind_angle = 0.0
var bait_timer = 0.0
var bait_pos = Vector3.ZERO
var day_count = 1
var time_of_day = 0.32

var build_selected_type = "foundation"
var build_rot = 0

var worlds_meta = {}

var settings = {
	"brightness": 0.75,
	"wave_strength": 1.0,
	"gfx_preset": "medium",
	"res_scale": 1.0,
	"max_fps": 60,
	"shadows": false,
	"wave_quality": 2,
	"view_dist": 1,
	"fov": 75.0,
	"show_fps": true,
	"sfx_vol": 0.90,
	"amb_vol": 0.65,
	"sens": 1.0,
	"invert_y": false,
	"hook_charge_mode": true,
	"auto_reel": true,
	"hud_scale": 1.0,
	"hud_opacity": 0.92,
	"custom_hud": {},
}


func _ready():
	_ensure_sfx_node()
	load_settings()
	load_worlds_index()
	reset()
	apply_settings()


func _ensure_sfx_node():
	sfx_ref = get_node_or_null("/root/Sfx")
	if sfx_ref == null:
		sfx_ref = SfxScript.new()
		sfx_ref.name = "SfxFallback"
		add_child(sfx_ref)


func play_sfx(id, pitch = 1.0, vol_mul = 1.0):
	if sfx_ref == null or not is_instance_valid(sfx_ref):
		_ensure_sfx_node()
	if sfx_ref != null and sfx_ref.has_method("play"):
		sfx_ref.play(id, pitch, vol_mul)


func play_reel_tick():
	if sfx_ref == null or not is_instance_valid(sfx_ref):
		_ensure_sfx_node()
	if sfx_ref != null and sfx_ref.has_method("play_reel_tick"):
		sfx_ref.play_reel_tick()


func play_wake_tick():
	if sfx_ref == null or not is_instance_valid(sfx_ref):
		_ensure_sfx_node()
	if sfx_ref != null and sfx_ref.has_method("play_wake_tick"):
		sfx_ref.play_wake_tick()


func _init_empty_slots():
	hotbar.clear()
	for i in range(HOTBAR_SIZE):
		hotbar.append({"id": "", "count": 0})
	bag_slots.clear()
	for i in range(BAG_SIZE):
		bag_slots.append({"id": "", "count": 0})
	armor_slots = {"head": "", "chest": "", "legs": "", "feet": ""}
	selected_hotbar = 0


func reset():
	_init_empty_slots()
	hotbar[0] = {"id": "hook", "count": 1}
	health = 100.0
	hunger = 100.0
	thirst = 100.0
	oxygen = 100.0
	dead = false
	has_rod = false
	has_spear = false
	has_bow = false
	has_paddle = false
	has_hammer = false
	has_anchor = false
	anchor_down = false
	has_sail = false
	sail_open = false
	sail_angle = 0.0
	paddle_boost_t = 0.0
	purifiers = 0
	grills = 0
	lanterns = 0
	crop_plots = 0
	hammocks = 0
	cooking_pots = 0
	scarecrows = 0
	research_tables = 0
	chests = 0
	research_points = 0
	purifier_timer = 0.0
	grill_timer = 0.0
	crop_timer = 0.0
	weather_state = "cerah"
	weather_timer = 50.0
	bait_timer = 0.0
	day_count = 1
	time_of_day = 0.32
	paint_theme = 0
	saved_tiles = [[0, 0], [1, 0], [0, 1], [1, 1]]
	saved_structures = []
	_rebuild_totals()
	inventory_changed.emit()
	stats_changed.emit()


func _rebuild_totals():
	inventory.clear()
	for s in hotbar:
		var id = str(s.get("id", ""))
		var c = int(s.get("count", 0))
		if id != "" and c > 0:
			inventory[id] = inventory.get(id, 0) + c
	for s in bag_slots:
		var id = str(s.get("id", ""))
		var c = int(s.get("count", 0))
		if id != "" and c > 0:
			inventory[id] = inventory.get(id, 0) + c
	has_spear = count("spear") > 0
	has_rod = count("rod") > 0
	has_bow = count("bow") > 0
	has_paddle = count("paddle") > 0
	has_hammer = count("hammer") > 0


func get_selected_item_id():
	if selected_hotbar >= 0 and selected_hotbar < hotbar.size():
		var s = hotbar[selected_hotbar]
		if int(s.get("count", 0)) > 0:
			return str(s.get("id", ""))
	return ""


func get_raft_velocity_vec():
	if anchor_down:
		return Vector2.ZERO
	var v = Vector2.ZERO
	if has_sail and sail_open:
		v += Vector2(cos(sail_angle), sin(sail_angle)) * 1.45
	if paddle_boost_t > 0.0:
		v += Vector2(cos(sail_angle), sin(sail_angle)) * 1.65
	return v


func is_raft_moving():
	if anchor_down:
		return false
	return (has_sail and sail_open) or (paddle_boost_t > 0.0)


func toggle_sail():
	if not has_sail:
		say("Buat Layar Kapal dulu di menu TAS untuk berlayar ke Pulau!")
		return
	sail_open = not sail_open
	if sail_open:
		if anchor_down:
			anchor_down = false
		say("LAYAR DIBUKA: Rakit berlayar mengikuti arah kemudi layar!")
		play_sfx("hook_throw", 0.78, 0.85)
	else:
		say("LAYAR DIGULUNG: Rakit berhenti berlayar.")
		play_sfx("reel", 0.9, 0.8)
	stats_changed.emit()


func rotate_sail(delta_deg):
	if not has_sail:
		return
	sail_angle = wrapf(sail_angle + deg_to_rad(float(delta_deg)), 0.0, TAU)
	var deg = int(round(rad_to_deg(sail_angle))) % 360
	say("Arah Kemudi Layar: %d° (%s)" % [deg, get_compass_dir_name(sail_angle)])
	play_sfx("ui", 1.02, 0.75)
	stats_changed.emit()


func get_compass_dir_name(ang_rad):
	var deg = int(round(rad_to_deg(wrapf(ang_rad, 0.0, TAU)))) % 360
	if deg >= 315 or deg < 45:
		return "UTARA"
	elif deg >= 45 and deg < 135:
		return "TIMUR"
	elif deg >= 135 and deg < 225:
		return "SELATAN"
	return "BARAT"


func toggle_anchor():
	if not has_anchor:
		say("Buat Jangkar Rakit dulu di menu TAS untuk menghentikan rakit!")
		return
	anchor_down = not anchor_down
	if anchor_down:
		sail_open = false
		say("JANGKAR DITURUNKAN: Rakit berhenti! Kamu bisa menjelajahi Pulau.")
		play_sfx("splash", 0.85, 0.95)
	else:
		say("JANGKAR DIANGKAT: Rakit siap berlayar kembali!")
		play_sfx("reel", 1.0, 0.9)
	stats_changed.emit()


func sleep_until_morning():
	if hammocks <= 0:
		say("Buat Tempat Tidur Hammock dulu di TAS untuk tidur!")
		return
	if time_of_day >= 0.25 and time_of_day < 0.70:
		say("Hanya bisa tidur saat Senja atau Malam hari!")
		return
	time_of_day = 0.28
	day_count += 1
	health = min(100.0, health + 35.0)
	play_sfx("sleep", 1.0, 0.95)
	save_current_world()
	stats_changed.emit()
	say("Kamu tidur nyenyak di Hammock... Hari ke-%d tiba (+35%% Nyawa)!" % day_count)


func do_research():
	if research_tables <= 0:
		say("Buat Meja Riset Rakit dulu di TAS!")
		return
	if count("wood") >= 1 and count("plastic") >= 1:
		spend({"wood": 1, "plastic": 1})
		research_points += 1
		add_item("arrow", 3)
		add_item("rope", 1)
		play_sfx("repair", 1.15, 0.9)
		say("Riset # %d Selesai! Bonus temuan: +3 Anak Panah & +1 Tali Serat!" % research_points)
	else:
		say("Butuh 1 Kayu Apung & 1 Plastik untuk melakukan Riset!")


func cycle_paint_theme():
	paint_theme = (paint_theme + 1) % 5
	var names = ["Kayu Alami", "Merah Kapten", "Biru Samudra", "Hijau Tropis", "Putih Gading"]
	say("Warna Cat Rakit diubah ke: " + names[paint_theme])
	play_sfx("repair", 1.08, 0.85)
	settings_changed.emit()


func get_armor_defense():
	var total = 0
	for k in armor_slots.keys():
		var aid = str(armor_slots[k])
		if ARMOR_DEFS.has(aid):
			total += int(ARMOR_DEFS[aid]["def"])
	return total


func is_armor_item(id):
	return ARMOR_DEFS.has(id)


func equip_armor_from_slot(slot_type, idx):
	var arr = hotbar if slot_type == "hotbar" else bag_slots
	if idx < 0 or idx >= arr.size():
		return false
	var id = str(arr[idx].get("id", ""))
	if not ARMOR_DEFS.has(id):
		return false
	var target_part = ARMOR_DEFS[id]["slot"]
	var prev_armor = str(armor_slots.get(target_part, ""))
	armor_slots[target_part] = id
	if prev_armor != "":
		arr[idx] = {"id": prev_armor, "count": 1}
	else:
		arr[idx] = {"id": "", "count": 0}
	_rebuild_totals()
	inventory_changed.emit()
	stats_changed.emit()
	say("Memakai " + ITEM_NAMES.get(id, id) + " (Pertahanan +" + str(get_armor_defense()) + "%)")
	play_sfx("build", 1.12, 0.85)
	return true


func unequip_armor(part):
	var cur = str(armor_slots.get(part, ""))
	if cur == "":
		return false
	if add_item(cur, 1):
		armor_slots[part] = ""
		_rebuild_totals()
		inventory_changed.emit()
		stats_changed.emit()
		say("Melepas " + ITEM_NAMES.get(cur, cur))
		play_sfx("ui", 0.95, 0.8)
		return true
	say("Tas penuh! Kosongkan 1 slot untuk melepas armor.")
	return false


func swap_or_move_slots(src_type, src_idx, dst_type, dst_idx):
	if src_type == dst_type and src_idx == dst_idx:
		return
	var src_arr = hotbar if src_type == "hotbar" else bag_slots
	var dst_arr = hotbar if dst_type == "hotbar" else bag_slots
	if src_idx < 0 or src_idx >= src_arr.size() or dst_idx < 0 or dst_idx >= dst_arr.size():
		return
	var a = src_arr[src_idx].duplicate()
	var b = dst_arr[dst_idx].duplicate()
	var a_id = str(a.get("id", ""))
	var b_id = str(b.get("id", ""))
	if a_id == "":
		return
	if a_id == b_id and not NON_STACKABLE.has(a_id):
		var max_stack = 64
		var total = int(a.get("count", 0)) + int(b.get("count", 0))
		if total <= max_stack:
			dst_arr[dst_idx] = {"id": a_id, "count": total}
			src_arr[src_idx] = {"id": "", "count": 0}
		else:
			dst_arr[dst_idx] = {"id": a_id, "count": max_stack}
			src_arr[src_idx] = {"id": a_id, "count": total - max_stack}
	else:
		dst_arr[dst_idx] = a
		src_arr[src_idx] = b
	_rebuild_totals()
	inventory_changed.emit()
	play_sfx("ui", 1.08, 0.75)


func drop_one_from_slot(slot_type, idx):
	var arr = hotbar if slot_type == "hotbar" else bag_slots
	if idx < 0 or idx >= arr.size():
		return
	var id = str(arr[idx].get("id", ""))
	var c = int(arr[idx].get("count", 0))
	if id == "" or c <= 0:
		return
	if id == "hook" and count("hook") <= 1:
		say("Grappling Hook utama tidak bisa dibuang!")
		return
	c -= 1
	if c <= 0:
		arr[idx] = {"id": "", "count": 0}
	else:
		arr[idx]["count"] = c
	_rebuild_totals()
	inventory_changed.emit()
	say("Membuang 1 " + ITEM_NAMES.get(id, id))
	play_sfx("ui", 0.85, 0.75)


func load_worlds_index():
	worlds_meta = {}
	var cfg = ConfigFile.new()
	if cfg.load(WORLDS_PATH) != OK:
		return
	for slot in [1, 2, 3, 4]:
		var sec = "world_%d" % slot
		if cfg.has_section(sec):
			worlds_meta[slot] = {
				"name": cfg.get_value(sec, "name", "Dunia #%d" % slot),
				"difficulty": cfg.get_value(sec, "difficulty", "survival"),
				"day_count": cfg.get_value(sec, "day_count", 1),
				"time_of_day": cfg.get_value(sec, "time_of_day", 0.32),
				"health": cfg.get_value(sec, "health", 100.0),
				"hunger": cfg.get_value(sec, "hunger", 100.0),
				"thirst": cfg.get_value(sec, "thirst", 100.0),
				"hotbar": cfg.get_value(sec, "hotbar", []),
				"bag_slots": cfg.get_value(sec, "bag_slots", []),
				"armor_slots": cfg.get_value(sec, "armor_slots", {"head": "", "chest": "", "legs": "", "feet": ""}),
				"has_anchor": cfg.get_value(sec, "has_anchor", false),
				"has_sail": cfg.get_value(sec, "has_sail", false),
				"sail_angle": cfg.get_value(sec, "sail_angle", 0.0),
				"purifiers": cfg.get_value(sec, "purifiers", 0),
				"grills": cfg.get_value(sec, "grills", 0),
				"lanterns": cfg.get_value(sec, "lanterns", 0),
				"crop_plots": cfg.get_value(sec, "crop_plots", 0),
				"hammocks": cfg.get_value(sec, "hammocks", 0),
				"cooking_pots": cfg.get_value(sec, "cooking_pots", 0),
				"scarecrows": cfg.get_value(sec, "scarecrows", 0),
				"research_tables": cfg.get_value(sec, "research_tables", 0),
				"chests": cfg.get_value(sec, "chests", 0),
				"paint_theme": cfg.get_value(sec, "paint_theme", 0),
				"tiles": cfg.get_value(sec, "tiles", [[0, 0], [1, 0], [0, 1], [1, 1]]),
				"structures": cfg.get_value(sec, "structures", []),
			}


func has_world_slot(slot):
	return worlds_meta.has(slot)


func create_new_world(slot, w_name, diff):
	current_slot = slot
	world_name = w_name if w_name.strip_edges() != "" else ("Samudra #%d" % slot)
	world_difficulty = diff
	reset()
	save_current_world([[0, 0], [1, 0], [0, 1], [1, 1]], [])
	world_loaded.emit()


func load_world_slot(slot):
	load_worlds_index()
	if not worlds_meta.has(slot):
		create_new_world(slot, "Samudra #%d" % slot, "survival")
		return
	current_slot = slot
	var d = worlds_meta[slot]
	world_name = str(d.get("name", "Samudra #%d" % slot))
	world_difficulty = str(d.get("difficulty", "survival"))
	day_count = int(d.get("day_count", 1))
	time_of_day = float(d.get("time_of_day", 0.32))
	health = clamp(float(d.get("health", 100.0)), 15.0, 100.0)
	hunger = clamp(float(d.get("hunger", 100.0)), 20.0, 100.0)
	thirst = clamp(float(d.get("thirst", 100.0)), 20.0, 100.0)
	oxygen = 100.0

	_init_empty_slots()
	var saved_hb = d.get("hotbar", [])
	if saved_hb is Array and saved_hb.size() == HOTBAR_SIZE:
		for i in range(HOTBAR_SIZE):
			if saved_hb[i] is Dictionary:
				hotbar[i] = {
					"id": str(saved_hb[i].get("id", "")),
					"count": int(saved_hb[i].get("count", 0)),
				}
	var saved_bg = d.get("bag_slots", [])
	if saved_bg is Array and saved_bg.size() == BAG_SIZE:
		for i in range(BAG_SIZE):
			if saved_bg[i] is Dictionary:
				bag_slots[i] = {
					"id": str(saved_bg[i].get("id", "")),
					"count": int(saved_bg[i].get("count", 0)),
				}
	var saved_arm = d.get("armor_slots", {})
	if saved_arm is Dictionary:
		for k in ["head", "chest", "legs", "feet"]:
			armor_slots[k] = str(saved_arm.get(k, ""))

	_rebuild_totals()
	if count("hook") <= 0:
		add_item("hook", 1)

	has_anchor = bool(d.get("has_anchor", false))
	anchor_down = false
	has_sail = bool(d.get("has_sail", false))
	sail_open = false
	sail_angle = float(d.get("sail_angle", 0.0))
	purifiers = int(d.get("purifiers", 0))
	grills = int(d.get("grills", 0))
	lanterns = int(d.get("lanterns", 0))
	crop_plots = int(d.get("crop_plots", 0))
	hammocks = int(d.get("hammocks", 0))
	cooking_pots = int(d.get("cooking_pots", 0))
	scarecrows = int(d.get("scarecrows", 0))
	research_tables = int(d.get("research_tables", 0))
	chests = int(d.get("chests", 0))
	paint_theme = int(d.get("paint_theme", 0))
	saved_tiles = d.get("tiles", [[0, 0], [1, 0], [0, 1], [1, 1]])
	saved_structures = d.get("structures", [])
	dead = false
	inventory_changed.emit()
	stats_changed.emit()
	world_loaded.emit()


func delete_world_slot(slot):
	load_worlds_index()
	worlds_meta.erase(slot)
	var cfg = ConfigFile.new()
	for s in worlds_meta.keys():
		var sec = "world_%d" % s
		var w = worlds_meta[s]
		for k in w.keys():
			cfg.set_value(sec, k, w[k])
	cfg.save(WORLDS_PATH)


func save_current_world(tile_list = null, struct_list = null):
	if tile_list != null:
		saved_tiles = tile_list
	if struct_list != null:
		saved_structures = struct_list
	var hb_copy = []
	for s in hotbar:
		hb_copy.append(s.duplicate())
	var bg_copy = []
	for s in bag_slots:
		bg_copy.append(s.duplicate())
	worlds_meta[current_slot] = {
		"name": world_name,
		"difficulty": world_difficulty,
		"day_count": day_count,
		"time_of_day": time_of_day,
		"health": health,
		"hunger": hunger,
		"thirst": thirst,
		"hotbar": hb_copy,
		"bag_slots": bg_copy,
		"armor_slots": armor_slots.duplicate(),
		"has_anchor": has_anchor,
		"has_sail": has_sail,
		"sail_angle": sail_angle,
		"purifiers": purifiers,
		"grills": grills,
		"lanterns": lanterns,
		"crop_plots": crop_plots,
		"hammocks": hammocks,
		"cooking_pots": cooking_pots,
		"scarecrows": scarecrows,
		"research_tables": research_tables,
		"chests": chests,
		"paint_theme": paint_theme,
		"tiles": saved_tiles,
		"structures": saved_structures,
	}
	var cfg = ConfigFile.new()
	for s in worlds_meta.keys():
		var sec = "world_%d" % s
		var w = worlds_meta[s]
		for k in w.keys():
			cfg.set_value(sec, k, w[k])
	cfg.save(WORLDS_PATH)


func load_settings():
	var cfg = ConfigFile.new()
	if cfg.load(SETTINGS_PATH) != OK:
		return
	for k in settings.keys():
		if cfg.has_section_key("settings", k):
			settings[k] = cfg.get_value("settings", k, settings[k])


func save_settings():
	var cfg = ConfigFile.new()
	for k in settings.keys():
		cfg.set_value("settings", k, settings[k])
	cfg.save(SETTINGS_PATH)
	apply_settings()


func apply_gfx_preset(preset):
	settings["gfx_preset"] = preset
	if preset == "low":
		settings["res_scale"] = 0.75
		settings["max_fps"] = 60
		settings["shadows"] = false
		settings["wave_quality"] = 1
		settings["view_dist"] = 0
	elif preset == "medium":
		settings["res_scale"] = 1.0
		settings["max_fps"] = 60
		settings["shadows"] = false
		settings["wave_quality"] = 2
		settings["view_dist"] = 1
	elif preset == "high":
		settings["res_scale"] = 1.0
		settings["max_fps"] = 60
		settings["shadows"] = true
		settings["wave_quality"] = 3
		settings["view_dist"] = 2
	save_settings()


func apply_settings():
	Engine.max_fps = int(settings.get("max_fps", 60))
	_ensure_sfx_node()
	if sfx_ref != null and sfx_ref.has_method("update_volumes"):
		sfx_ref.update_volumes(float(settings.get("sfx_vol", 0.90)), float(settings.get("amb_vol", 0.65)))
	settings_changed.emit()


func reset_custom_hud():
	settings["custom_hud"] = {}
	settings["hud_scale"] = 1.0
	settings["hud_opacity"] = 0.92
	save_settings()


func say(t):
	message.emit(t)


func count(id):
	return int(inventory.get(id, 0))


func add_item(id, n = 1):
	if n <= 0:
		return false
	var rem = int(n)
	var stackable = not NON_STACKABLE.has(id)
	var max_stack = 64 if stackable else 1

	if stackable:
		for i in range(HOTBAR_SIZE):
			if hotbar[i]["id"] == id and hotbar[i]["count"] < max_stack:
				var add = min(rem, max_stack - int(hotbar[i]["count"]))
				hotbar[i]["count"] += add
				rem -= add
				if rem <= 0:
					_rebuild_totals()
					inventory_changed.emit()
					return true
		for i in range(BAG_SIZE):
			if bag_slots[i]["id"] == id and bag_slots[i]["count"] < max_stack:
				var add = min(rem, max_stack - int(bag_slots[i]["count"]))
				bag_slots[i]["count"] += add
				rem -= add
				if rem <= 0:
					_rebuild_totals()
					inventory_changed.emit()
					return true

	for i in range(HOTBAR_SIZE):
		if hotbar[i]["id"] == "" or int(hotbar[i]["count"]) <= 0:
			var put = min(rem, max_stack)
			hotbar[i] = {"id": id, "count": put}
			rem -= put
			if rem <= 0:
				_rebuild_totals()
				inventory_changed.emit()
				return true

	for i in range(BAG_SIZE):
		if bag_slots[i]["id"] == "" or int(bag_slots[i]["count"]) <= 0:
			var put = min(rem, max_stack)
			bag_slots[i] = {"id": id, "count": put}
			rem -= put
			if rem <= 0:
				_rebuild_totals()
				inventory_changed.emit()
				return true

	_rebuild_totals()
	inventory_changed.emit()
	if rem > 0:
		say("Tas penuh! Sebagian barang tidak muat.")
	return rem < n


func has_items(cost):
	for k in cost:
		if count(k) < cost[k]:
			return false
	return true


func spend(cost):
	for k in cost:
		var need = int(cost[k])
		for i in range(BAG_SIZE - 1, -1, -1):
			if need <= 0:
				break
			if bag_slots[i]["id"] == k:
				var take = min(need, int(bag_slots[i]["count"]))
				bag_slots[i]["count"] -= take
				need -= take
				if bag_slots[i]["count"] <= 0:
					bag_slots[i] = {"id": "", "count": 0}
		for i in range(HOTBAR_SIZE - 1, -1, -1):
			if need <= 0:
				break
			if hotbar[i]["id"] == k:
				var take = min(need, int(hotbar[i]["count"]))
				hotbar[i]["count"] -= take
				need -= take
				if hotbar[i]["count"] <= 0:
					hotbar[i] = {"id": "", "count": 0}
	_rebuild_totals()
	inventory_changed.emit()


func craft(id):
	if dead:
		return
	var recipe = null
	for r in RECIPES:
		if r["id"] == id:
			recipe = r
	if recipe == null:
		return
	if id == "fish_stew" and cooking_pots <= 0:
		say("Buat Panci Masak Sup dulu di rakit untuk memasak Sup Ikan Kelapa!")
		return
	if not has_items(recipe["cost"]):
		say("Bahan belum cukup untuk membuat " + recipe["name"])
		return
	if id == "rod" and has_rod:
		say("Kamu sudah punya Alat Pancing di Tas/Hotbar!")
		return
	if id == "spear" and has_spear:
		say("Kamu sudah punya Tombak Besi di Tas/Hotbar!")
		return
	if id == "bow" and has_bow:
		say("Kamu sudah punya Busur Panah di Tas/Hotbar!")
		return
	if id == "paddle" and has_paddle:
		say("Kamu sudah punya Dayung Kayu di Tas/Hotbar!")
		return
	if id == "hammer" and has_hammer:
		say("Kamu sudah punya Palu Perbaikan di Tas/Hotbar!")
		return
	if id == "anchor" and has_anchor:
		say("Jangkar Rakit sudah terpasang di rakit!")
		return
	if id == "sail" and has_sail:
		say("Layar Kapal sudah terpasang di rakit!")
		return

	spend(recipe["cost"])
	match id:
		"foundation", "net", "stairs", "armor_tile", "decor":
			add_item(id, 1)
			build_selected_type = id
			say(ITEM_NAMES.get(id, id) + " dibuat! Tekan BANGUN / PASANG untuk memasang.")
		"wall", "window_wall", "fence", "roof":
			add_item(id, 2)
			build_selected_type = id
			say("+2 " + ITEM_NAMES.get(id, id) + " dibuat! Tekan BANGUN untuk memasang.")
		"rope":
			add_item("rope", 2)
			say("+2 Tali Serat berhasil dibuat!")
		"arrow":
			add_item("arrow", 6)
			say("+6 Anak Panah Besi dibuat!")
		"shark_bait":
			add_item("shark_bait", 1)
			say("Umpan Hiu dibuat! Pegang di Hotbar untuk melempar ke laut.")
		"fish_stew":
			add_item("fish_stew", 1)
			say("Sup Ikan Kelapa matang! Mengenyangkan & memulihkan Nyawa.")
		"paddle":
			add_item("paddle", 1)
			say("Dayung Kayu dibuat! Pilih di Hotbar untuk mengayuh rakit.")
		"hammer":
			add_item("hammer", 1)
			say("Palu Perbaikan dibuat! Pilih di Hotbar untuk memperbaiki pondasi rusak.")
		"bow":
			add_item("bow", 1)
			add_item("arrow", 5)
			say("Busur Panah + 5 Anak Panah dibuat! Pilih di Hotbar untuk memanah.")
		"sail":
			has_sail = true
			sail_added.emit()
			say("Layar Kapal 360° dipasang! Gunakan kemudi layar di atas HUD untuk berlayar ke Pulau.")
		"anchor":
			has_anchor = true
			anchor_added.emit()
			say("Jangkar Rakit terpasang! Gunakan tombol JANGKAR saat dekat Pulau.")
		"rod":
			add_item("rod", 1)
			say("Alat Pancing dibuat! Pilih di Hotbar untuk memancing.")
		"spear":
			add_item("spear", 1)
			say("Tombak Besi dibuat! Pilih di Hotbar untuk menyerang.")
		"leaf_hat", "wood_vest", "rope_legs", "scrap_boots":
			var part = ARMOR_DEFS[id]["slot"]
			if str(armor_slots.get(part, "")) == "":
				armor_slots[part] = id
				say(ITEM_NAMES.get(id, id) + " dibuat & langsung dipakai! (DEF +" + str(get_armor_defense()) + "%)")
			else:
				add_item(id, 1)
				say(ITEM_NAMES.get(id, id) + " dibuat dan masuk ke Tas!")
		"purifier":
			purifiers += 1
			purifier_added.emit()
			say("Penyaring Air dipasang di atas rakit!")
		"grill":
			grills += 1
			grill_added.emit()
			say("Pemanggang dipasang di atas rakit!")
		"lantern":
			lanterns += 1
			lantern_added.emit()
			say("Lentera Rakit dipasang!")
		"crop_plot":
			crop_plots += 1
			crop_plot_added.emit()
			say("Petak Tanaman dipasang! Otomatis menumbuhkan Kelapa, Daun & Kayu.")
		"hammock":
			hammocks += 1
			hammock_added.emit()
			say("Hammock dipasang! Tekan TIDUR saat malam untuk lompat ke pagi.")
		"cooking_pot":
			cooking_pots += 1
			cooking_pot_added.emit()
			say("Panci Masak dipasang! Kini kamu bisa memasak Sup Ikan Kelapa di TAS.")
		"scarecrow":
			scarecrows += 1
			scarecrow_added.emit()
			say("Orang-Orangan Sawah dipasang! Burung Camar tidak berani mencuri hasil kebun.")
		"research_table":
			research_tables += 1
			research_table_added.emit()
			say("Meja Riset dipasang! Gunakan tombol RISET di menu TAS.")
		"chest":
			chests += 1
			chest_added.emit()
			say("Peti Penyimpanan dipasang di atas rakit!")
	_rebuild_totals()
	inventory_changed.emit()
	stats_changed.emit()
	save_current_world()
	play_sfx("build", 1.05, 0.9)


func use_item(id):
	if dead or count(id) <= 0:
		return
	if is_armor_item(id):
		for i in range(HOTBAR_SIZE):
			if hotbar[i]["id"] == id:
				equip_armor_from_slot("hotbar", i)
				return
		for i in range(BAG_SIZE):
			if bag_slots[i]["id"] == id:
				equip_armor_from_slot("bag", i)
				return
		return
	match id:
		"coconut":
			hunger = min(100.0, hunger + 16.0)
			thirst = min(100.0, thirst + 18.0)
		"can":
			hunger = min(100.0, hunger + 34.0)
			thirst = min(100.0, thirst + 10.0)
		"water":
			thirst = min(100.0, thirst + 40.0)
		"fish":
			hunger = min(100.0, hunger + 18.0)
		"cooked_fish":
			hunger = min(100.0, hunger + 44.0)
			health = min(100.0, health + 10.0)
		"meat":
			hunger = min(100.0, hunger + 28.0)
		"cooked_meat":
			hunger = min(100.0, hunger + 58.0)
			health = min(100.0, health + 18.0)
		"fish_stew":
			hunger = min(100.0, hunger + 78.0)
			thirst = min(100.0, thirst + 45.0)
			health = min(100.0, health + 28.0)
		_:
			return
	spend({id: 1})
	stats_changed.emit()
	say("Mengonsumsi " + ITEM_NAMES.get(id, id))
	play_sfx("consume", 1.0, 0.88)


func collect(kind):
	if kind == "barrel" or kind == "crate":
		var loot = ["coconut", "can", "water", "wood", "plastic", "scrap", "leaf", "rope"]
		var prefix = "Tong Apung: " if kind == "barrel" else "Peti Laut: "
		var n = randi_range(2, 4) if kind == "crate" else randi_range(2, 3)
		for i in range(n):
			var it = loot.pick_random()
			add_item(it, 1)
			prefix += ITEM_NAMES[it]
			if i < n - 1:
				prefix += ", "
		say(prefix)
	else:
		add_item(kind, 1)
		say("+1 " + ITEM_NAMES.get(kind, kind))
	play_sfx("pickup", randf_range(0.96, 1.08), 0.90)


func catch_fish():
	var r = randf()
	if r < 0.72:
		if grills > 0:
			add_item("cooked_fish", 1)
			say("Dapat ikan & langsung dipanggang: +1 Ikan Bakar!")
		else:
			add_item("fish", 1)
			say("Berhasil memancing: +1 Ikan Mentah!")
	elif r < 0.88:
		add_item("plastic", 1)
		say("Kail mengangkat sampah: +1 Plastik Laut")
	else:
		add_item("coconut", 1)
		say("Kail mengangkat Kelapa Segar!")
	play_sfx("pickup", 1.1, 0.9)


func damage(a):
	if dead:
		return
	var def_pct = clamp(float(get_armor_defense()) / 100.0, 0.0, 0.65)
	var final_dmg = float(a) * (1.0 - def_pct)
	health -= final_dmg
	stats_changed.emit()
	_check_death()


func _check_death():
	if health <= 0.0:
		health = 0.0
		dead = true
		stats_changed.emit()
		player_died.emit()


func _process(delta):
	if dead or menu_open or not in_world:
		if sfx_ref != null and sfx_ref.has_method("set_rain_intensity"):
			sfx_ref.set_rain_intensity(0.0)
		return

	if paddle_boost_t > 0.0:
		paddle_boost_t = max(0.0, paddle_boost_t - delta)
	if bait_timer > 0.0:
		bait_timer = max(0.0, bait_timer - delta)

	# F1 & F2: Dynamic Weather Cycle & Wind Streamer
	wind_angle = wrapf(wind_angle + sin(Time.get_ticks_msec() * 0.0002) * 0.04 * delta, 0.0, TAU)
	weather_timer -= delta
	if weather_timer <= 0.0:
		weather_timer = randf_range(50.0, 85.0)
		var w_pool = ["cerah", "cerah", "berawan", "hujan", "badai"]
		var next_w = w_pool.pick_random()
		if next_w != weather_state:
			weather_state = next_w
			match weather_state:
				"cerah":
					say("Cuaca kembali Cerah! Lautan tenang.")
				"berawan":
					say("Langit mulai Berawan sejuk.")
				"hujan":
					say("Hujan turun! Penyaring Air & Kebun Rakit terisi air hujan 2x lebih cepat.")
				"badai":
					say("Badai Laut tiba! Gelombang ombak sedikit meningkat.")
	if sfx_ref != null and sfx_ref.has_method("set_rain_intensity"):
		var r_int = 0.85 if weather_state == "badai" else (0.55 if weather_state == "hujan" else 0.0)
		sfx_ref.set_rain_intensity(r_int)

	time_of_day += delta / 240.0
	if time_of_day >= 1.0:
		time_of_day -= 1.0
		day_count += 1
		save_current_world()
		say("Hari ke-%d dimulai di tengah samudra!" % day_count)

	var drain_mul = 0.65 if world_difficulty == "peaceful" else (1.35 if world_difficulty == "hardcore" else 1.0)
	hunger = max(0.0, hunger - 0.14 * drain_mul * delta)
	thirst = max(0.0, thirst - 0.19 * drain_mul * delta)
	if hunger <= 0.0 or thirst <= 0.0:
		health -= 1.10 * delta
	elif hunger > 35.0 and thirst > 35.0 and health < 100.0:
		health = min(100.0, health + 0.65 * delta)

	# F2: Rainwater fills Purifiers 2.2x faster!
	var rain_mul = 2.2 if (weather_state in ["hujan", "badai"]) else 1.0
	if purifiers > 0:
		purifier_timer += delta * rain_mul
		if purifier_timer >= 34.0:
			purifier_timer = 0.0
			var room = 12 - count("water")
			if room > 0:
				add_item("water", min(purifiers, room))
				say("Penyaring Air menghasilkan +Air Minum bersih!")
				play_sfx("pickup", 1.2, 0.6)

	# F5: Crop Plots grow Coconut, Palm Leaf & Wood automatically!
	if crop_plots > 0:
		crop_timer += delta * rain_mul
		if crop_timer >= 36.0:
			crop_timer = 0.0
			add_item("coconut", crop_plots)
			add_item("leaf", crop_plots)
			add_item("wood", 1)
			say("Kebun Rakit Panen: +%d Kelapa, +%d Daun, +1 Kayu!" % [crop_plots, crop_plots])
			play_sfx("pickup", 1.18, 0.75)

	if grills > 0:
		if count("fish") > 0 or count("meat") > 0:
			grill_timer += delta
			if grill_timer >= 14.0:
				grill_timer = 0.0
				if count("fish") > 0:
					spend({"fish": 1})
					add_item("cooked_fish", 1)
					say("Pemanggang selesai memasak: +1 Ikan Bakar!")
					play_sfx("pickup", 1.15, 0.7)
				elif count("meat") > 0:
					spend({"meat": 1})
					add_item("cooked_meat", 1)
					say("Pemanggang selesai memasak: +1 Steak Hiu Bakar!")
					play_sfx("pickup", 1.15, 0.7)
		else:
			grill_timer = 0.0

	autosave_timer += delta
	if autosave_timer >= 20.0:
		autosave_timer = 0.0
		save_current_world()

	stat_timer += delta
	if stat_timer > 0.2:
		stat_timer = 0.0
		stats_changed.emit()
	_check_death()
