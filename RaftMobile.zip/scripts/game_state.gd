extends Node

signal inventory_changed
signal stats_changed
signal message(text)
signal player_died
signal purifier_added
signal grill_added
signal lantern_added
signal settings_changed

const SETTINGS_PATH = "user://raft_settings.cfg"
const MIX_RATE = 11025

const ITEM_NAMES = {
	"wood": "Kayu Apung",
	"plastic": "Plastik",
	"scrap": "Besi Tua",
	"leaf": "Daun Palem",
	"rope": "Tali Serat",
	"coconut": "Kelapa Segar",
	"can": "Makanan Kaleng",
	"water": "Air Minum",
	"fish": "Ikan Mentah",
	"cooked_fish": "Ikan Bakar",
	"meat": "Daging Hiu",
	"cooked_meat": "Steak Hiu Bakar",
	"foundation": "Pondasi Rakit",
}

const USABLE = ["water", "coconut", "cooked_fish", "cooked_meat", "can", "fish", "meat"]

const RECIPES = [
	{"id": "foundation", "name": "Pondasi Rakit (+Perluas)", "cost": {"wood": 4, "plastic": 2}},
	{"id": "rope", "name": "Tali Serat (x2)", "cost": {"leaf": 2}},
	{"id": "spear", "name": "Tombak Besi (Senjata Hiu)", "cost": {"wood": 3, "scrap": 2}},
	{"id": "rod", "name": "Alat Pancing Laut", "cost": {"wood": 2, "plastic": 2, "leaf": 1}},
	{"id": "purifier", "name": "Penyaring Air Laut Otomatis", "cost": {"wood": 5, "plastic": 4, "scrap": 2}},
	{"id": "grill", "name": "Pemanggang Ikan & Daging", "cost": {"wood": 4, "scrap": 2, "leaf": 2}},
	{"id": "lantern", "name": "Lentera Rakit (Penerang Malam)", "cost": {"wood": 2, "scrap": 2, "plastic": 1}},
]

var inventory = {}
var health = 100.0
var hunger = 100.0
var thirst = 100.0
var dead = false
var menu_open = false
var has_rod = false
var has_spear = false
var purifiers = 0
var grills = 0
var lanterns = 0
var purifier_timer = 0.0
var grill_timer = 0.0
var stat_timer = 0.0
var day_count = 1
var time_of_day = 0.32

var sfx_sounds = {}
var sfx_players = []
var amb_player = null
var reel_cd = 0.0

var settings = {
	"gfx_preset": "medium",
	"res_scale": 1.0,
	"max_fps": 60,
	"shadows": false,
	"wave_quality": 2,
	"view_dist": 1,
	"fov": 75.0,
	"show_fps": true,
	"sfx_vol": 0.85,
	"amb_vol": 0.55,
	"sens": 1.0,
	"invert_y": false,
	"hook_charge_mode": true,
	"auto_reel": true,
	"hud_scale": 1.0,
	"hud_opacity": 0.92,
	"custom_hud": {},
}


func _ready():
	process_mode = Node.PROCESS_MODE_ALWAYS
	_init_audio_system()
	load_settings()
	reset()
	apply_settings()


func _lin_db(v):
	if v <= 0.001:
		return -80.0
	return clamp(linear_to_db(v), -60.0, 6.0)


func _init_audio_system():
	for i in range(6):
		var p = AudioStreamPlayer.new()
		add_child(p)
		sfx_players.append(p)
	_build_all_sounds()
	amb_player = AudioStreamPlayer.new()
	if sfx_sounds.has("ocean_loop"):
		amb_player.stream = sfx_sounds["ocean_loop"]
	amb_player.volume_db = _lin_db(float(settings["amb_vol"]) * 0.30)
	add_child(amb_player)
	amb_player.play()


func play_sfx(id, pitch = 1.0, vol_mul = 1.0):
	var sv = float(settings.get("sfx_vol", 0.85))
	if sv <= 0.01 or sfx_players.is_empty() or not sfx_sounds.has(id):
		return
	var chosen = sfx_players[0]
	for p in sfx_players:
		if not p.playing:
			chosen = p
			break
	chosen.stream = sfx_sounds[id]
	chosen.pitch_scale = max(0.25, pitch + randf_range(-0.04, 0.04))
	chosen.volume_db = _lin_db(sv * vol_mul)
	chosen.play()


func play_reel_tick():
	if reel_cd > 0.0:
		return
	reel_cd = 0.09
	play_sfx("reel", randf_range(0.95, 1.12), 0.65)


func _make_wav(samples, loop = false):
	var n = samples.size()
	var bytes = PackedByteArray()
	bytes.resize(n * 2)
	for i in range(n):
		var s = int(clamp(samples[i], -1.0, 1.0) * 32767.0)
		if s < 0:
			s += 65536
		bytes[i * 2] = s & 0xFF
		bytes[i * 2 + 1] = (s >> 8) & 0xFF
	var wav = AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BIT
	wav.mix_rate = MIX_RATE
	wav.stereo = false
	wav.data = bytes
	if loop:
		wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
		wav.loop_begin = 0
		wav.loop_end = n
	return wav


func _build_all_sounds():
	# 1. Hook Throw
	var s_throw = PackedFloat32Array()
	var n_throw = int(MIX_RATE * 0.24)
	s_throw.resize(n_throw)
	var ph = 0.0
	for i in range(n_throw):
		var t = float(i) / float(MIX_RATE)
		var env = sin(clamp(t / 0.24, 0.0, 1.0) * PI)
		var freq = lerp(220.0, 580.0, t / 0.24)
		ph += TAU * freq / float(MIX_RATE)
		var noise = randf_range(-1.0, 1.0) * 0.5
		s_throw[i] = (sin(ph) * 0.4 + noise) * env * 0.65
	sfx_sounds["hook_throw"] = _make_wav(s_throw)

	# 2. Water Splash
	var s_splash = PackedFloat32Array()
	var n_splash = int(MIX_RATE * 0.35)
	s_splash.resize(n_splash)
	var lp = 0.0
	for i in range(n_splash):
		var t = float(i) / float(MIX_RATE)
		var env = exp(-t * 8.0)
		var raw = randf_range(-1.0, 1.0)
		lp = lp + 0.3 * (raw - lp)
		var bubble = sin(TAU * (260.0 + 160.0 * sin(t * 42.0)) * t) * 0.3
		s_splash[i] = (lp * 0.8 + bubble) * env * 0.75
	sfx_sounds["splash"] = _make_wav(s_splash)

	# 3. Hook Snag
	var s_snag = PackedFloat32Array()
	var n_snag = int(MIX_RATE * 0.16)
	s_snag.resize(n_snag)
	for i in range(n_snag):
		var t = float(i) / float(MIX_RATE)
		var env = exp(-t * 18.0)
		s_snag[i] = (sin(TAU * 520.0 * t) * 0.5 + sin(TAU * 860.0 * t) * 0.4) * env * 0.7
	sfx_sounds["snag"] = _make_wav(s_snag)

	# 4. Reel Tick
	var s_reel = PackedFloat32Array()
	var n_reel = int(MIX_RATE * 0.04)
	s_reel.resize(n_reel)
	for i in range(n_reel):
		var t = float(i) / float(MIX_RATE)
		s_reel[i] = (sin(TAU * 380.0 * t) * 0.6 + randf_range(-0.4, 0.4)) * exp(-t * 55.0) * 0.55
	sfx_sounds["reel"] = _make_wav(s_reel)

	# 5. Item Pickup
	var s_pick = PackedFloat32Array()
	var n_pick = int(MIX_RATE * 0.20)
	s_pick.resize(n_pick)
	for i in range(n_pick):
		var t = float(i) / float(MIX_RATE)
		var f = 523.25 if t < 0.07 else (659.25 if t < 0.13 else 783.99)
		s_pick[i] = sin(TAU * f * t) * exp(-t * 9.5) * 0.65
	sfx_sounds["pickup"] = _make_wav(s_pick)

	# 6. Spear Thrust
	var s_spear = PackedFloat32Array()
	var n_spear = int(MIX_RATE * 0.16)
	s_spear.resize(n_spear)
	for i in range(n_spear):
		var t = float(i) / float(MIX_RATE)
		var env = sin(clamp(t / 0.16, 0.0, 1.0) * PI)
		var f = lerp(400.0, 150.0, t / 0.16)
		s_spear[i] = (sin(TAU * f * t) * 0.5 + randf_range(-0.5, 0.5) * 0.5) * env * 0.65
	sfx_sounds["spear"] = _make_wav(s_spear)

	# 7. Hit Shark
	var s_hit = PackedFloat32Array()
	var n_hit = int(MIX_RATE * 0.22)
	s_hit.resize(n_hit)
	for i in range(n_hit):
		var t = float(i) / float(MIX_RATE)
		var f = lerp(175.0, 62.0, t / 0.22)
		s_hit[i] = (sin(TAU * f * t) * 0.7 + randf_range(-0.4, 0.4) * 0.3) * exp(-t * 14.0) * 0.8
	sfx_sounds["hit"] = _make_wav(s_hit)

	# 8. Shark Bite
	var s_bite = PackedFloat32Array()
	var n_bite = int(MIX_RATE * 0.32)
	s_bite.resize(n_bite)
	for i in range(n_bite):
		var t = float(i) / float(MIX_RATE)
		var bass = sin(TAU * lerp(135.0, 50.0, t / 0.32) * t) * 0.75
		s_bite[i] = (randf_range(-0.6, 0.6) + bass) * exp(-t * 7.0) * 0.8
	sfx_sounds["bite"] = _make_wav(s_bite)

	# 9. Build / Hammer Wood
	var s_build = PackedFloat32Array()
	var n_build = int(MIX_RATE * 0.24)
	s_build.resize(n_build)
	for i in range(n_build):
		var t = float(i) / float(MIX_RATE)
		var t2 = t if t < 0.12 else (t - 0.12)
		var f = 240.0 if t < 0.12 else 310.0
		s_build[i] = (sin(TAU * f * t2) * 0.7 + randf_range(-0.3, 0.3) * 0.3) * exp(-t2 * 24.0) * 0.75
	sfx_sounds["build"] = _make_wav(s_build)

	# 10. Consume (Eat / Drink)
	var s_eat = PackedFloat32Array()
	var n_eat = int(MIX_RATE * 0.22)
	s_eat.resize(n_eat)
	for i in range(n_eat):
		var t = float(i) / float(MIX_RATE)
		var env = sin(clamp(t / 0.22, 0.0, 1.0) * PI)
		var f = 310.0 + 130.0 * sin(t * 35.0)
		s_eat[i] = sin(TAU * f * t) * env * 0.6
	sfx_sounds["consume"] = _make_wav(s_eat)

	# 11. UI Tap
	var s_ui = PackedFloat32Array()
	var n_ui = int(MIX_RATE * 0.035)
	s_ui.resize(n_ui)
	for i in range(n_ui):
		var t = float(i) / float(MIX_RATE)
		s_ui[i] = sin(TAU * 680.0 * t) * exp(-t * 65.0) * 0.5
	sfx_sounds["ui"] = _make_wav(s_ui)

	# 12. Ocean Waves Loop (2.5s gentle surf)
	var s_ocean = PackedFloat32Array()
	var n_ocean = int(MIX_RATE * 2.5)
	s_ocean.resize(n_ocean)
	var brown = 0.0
	for i in range(n_ocean):
		var t = float(i) / float(MIX_RATE)
		brown = clamp((brown + randf_range(-1.0, 1.0) * 0.05) * 0.98, -1.0, 1.0)
		var swell = 0.55 + 0.45 * sin(TAU * t / 2.5)
		s_ocean[i] = brown * swell * 0.4
	sfx_sounds["ocean_loop"] = _make_wav(s_ocean, true)


func reset():
	inventory = {
		"wood": 8,
		"plastic": 6,
		"scrap": 2,
		"leaf": 4,
		"water": 2,
		"coconut": 1,
		"can": 1,
	}
	health = 100.0
	hunger = 100.0
	thirst = 100.0
	dead = false
	menu_open = false
	has_rod = false
	has_spear = false
	purifiers = 0
	grills = 0
	lanterns = 0
	purifier_timer = 0.0
	grill_timer = 0.0
	day_count = 1
	time_of_day = 0.32
	inventory_changed.emit()
	stats_changed.emit()


func load_settings():
	var cfg = ConfigFile.new()
	if cfg.load(SETTINGS_PATH) != OK:
		return
	for k in settings.keys():
		if cfg.has_section_key("settings", k):
			settings[k] = cfg.get_value("settings", k, settings[k])


func save_settings():
	var cfg = ConfigFile.new()
	for k in settings.keys():
		cfg.set_value("settings", k, settings[k])
	cfg.save(SETTINGS_PATH)
	apply_settings()


func apply_gfx_preset(preset):
	settings["gfx_preset"] = preset
	if preset == "low":
		settings["res_scale"] = 0.75
		settings["max_fps"] = 60
		settings["shadows"] = false
		settings["wave_quality"] = 1
		settings["view_dist"] = 0
	elif preset == "medium":
		settings["res_scale"] = 1.0
		settings["max_fps"] = 60
		settings["shadows"] = false
		settings["wave_quality"] = 2
		settings["view_dist"] = 1
	elif preset == "high":
		settings["res_scale"] = 1.0
		settings["max_fps"] = 60
		settings["shadows"] = true
		settings["wave_quality"] = 3
		settings["view_dist"] = 2
	save_settings()


func apply_settings():
	Engine.max_fps = int(settings.get("max_fps", 60))
	if amb_player != null:
		var av = clamp(float(settings.get("amb_vol", 0.55)), 0.0, 1.0)
		if av <= 0.01:
			amb_player.volume_db = -80.0
		else:
			amb_player.volume_db = _lin_db(av * 0.30)
			if not amb_player.playing:
				amb_player.play()
	settings_changed.emit()


func reset_custom_hud():
	settings["custom_hud"] = {}
	settings["hud_scale"] = 1.0
	settings["hud_opacity"] = 0.92
	save_settings()


func say(t):
	message.emit(t)


func count(id):
	return inventory.get(id, 0)


func add_item(id, n = 1):
	inventory[id] = count(id) + n
	inventory_changed.emit()


func has_items(cost):
	for k in cost:
		if count(k) < cost[k]:
			return false
	return true


func spend(cost):
	for k in cost:
		inventory[k] = count(k) - cost[k]
		if inventory[k] <= 0:
			inventory.erase(k)
	inventory_changed.emit()


func craft(id):
	if dead:
		return
	var recipe = null
	for r in RECIPES:
		if r["id"] == id:
			recipe = r
	if recipe == null:
		return
	if not has_items(recipe["cost"]):
		say("Bahan belum cukup untuk membuat " + recipe["name"])
		return
	if id == "rod" and has_rod:
		return
	if id == "spear" and has_spear:
		return
	spend(recipe["cost"])
	match id:
		"foundation":
			add_item("foundation", 1)
			say("Pondasi Rakit dibuat! Tekan BANGUN untuk memasang.")
		"rope":
			add_item("rope", 2)
			say("+2 Tali Serat dibuat!")
		"rod":
			has_rod = true
			say("Alat Pancing siap! Tekan tombol PANCING di HUD.")
		"spear":
			has_spear = true
			say("Tombak Besi siap! Gunakan tombol SERANG.")
		"purifier":
			purifiers += 1
			purifier_added.emit()
			say("Penyaring Air dipasang di rakit (air minum otomatis).")
		"grill":
			grills += 1
			grill_added.emit()
			say("Pemanggang dipasang! Otomatis memanggang ikan/daging mentah.")
		"lantern":
			lanterns += 1
			lantern_added.emit()
			say("Lentera Rakit dipasang! Menerangi rakit saat malam.")
	inventory_changed.emit()
	play_sfx("build", 1.05, 0.9)


func use_item(id):
	if dead or count(id) <= 0:
		return
	match id:
		"coconut":
			hunger = min(100.0, hunger + 14.0)
			thirst = min(100.0, thirst + 16.0)
		"can":
			hunger = min(100.0, hunger + 32.0)
			thirst = min(100.0, thirst + 8.0)
		"water":
			thirst = min(100.0, thirst + 38.0)
		"fish":
			hunger = min(100.0, hunger + 18.0)
		"cooked_fish":
			hunger = min(100.0, hunger + 42.0)
			health = min(100.0, health + 8.0)
		"meat":
			hunger = min(100.0, hunger + 28.0)
		"cooked_meat":
			hunger = min(100.0, hunger + 55.0)
			health = min(100.0, health + 15.0)
		_:
			return
	inventory[id] = count(id) - 1
	if inventory[id] <= 0:
		inventory.erase(id)
	inventory_changed.emit()
	stats_changed.emit()
	say("Mengonsumsi " + ITEM_NAMES.get(id, id))
	play_sfx("consume", 1.0, 0.85)


func collect(kind):
	if kind == "barrel" or kind == "crate":
		var loot = ["coconut", "can", "water", "wood", "plastic", "scrap", "leaf"]
		var prefix = "Tong Apung: " if kind == "barrel" else "Peti Laut: "
		var n = randi_range(2, 4) if kind == "crate" else randi_range(2, 3)
		for i in range(n):
			var it = loot.pick_random()
			add_item(it, 1)
			prefix += ITEM_NAMES[it]
			if i < n - 1:
				prefix += ", "
		say(prefix)
	else:
		add_item(kind, 1)
		say("+1 " + ITEM_NAMES.get(kind, kind))
	play_sfx("pickup", randf_range(0.96, 1.08), 0.85)


func catch_fish():
	var r = randf()
	if r < 0.72:
		if grills > 0:
			add_item("cooked_fish", 1)
			say("Dapat ikan & langsung dipanggang: +1 Ikan Bakar!")
		else:
			add_item("fish", 1)
			say("Berhasil memancing: +1 Ikan Mentah!")
	elif r < 0.88:
		add_item("plastic", 1)
		say("Kail mengangkat sampah: +1 Plastik")
	else:
		add_item("coconut", 1)
		say("Kail mengangkat Kelapa Segar!")
	play_sfx("pickup", 1.1, 0.9)


func damage(a):
	if dead:
		return
	health -= a
	stats_changed.emit()
	_check_death()


func _check_death():
	if health <= 0.0:
		health = 0.0
		dead = true
		stats_changed.emit()
		player_died.emit()


func _process(delta):
	if reel_cd > 0.0:
		reel_cd = max(0.0, reel_cd - delta)
	if dead or menu_open:
		return
	time_of_day += delta / 240.0
	if time_of_day >= 1.0:
		time_of_day -= 1.0
		day_count += 1
		say("Hari ke-%d dimulai di tengah samudra!" % day_count)

	hunger = max(0.0, hunger - 0.15 * delta)
	thirst = max(0.0, thirst - 0.21 * delta)
	if hunger <= 0.0 or thirst <= 0.0:
		health -= 1.15 * delta
	elif hunger > 35.0 and thirst > 35.0 and health < 100.0:
		health = min(100.0, health + 0.65 * delta)

	if purifiers > 0:
		purifier_timer += delta
		if purifier_timer >= 36.0:
			purifier_timer = 0.0
			var room = 12 - count("water")
			if room > 0:
				add_item("water", min(purifiers, room))
				say("Penyaring Air menghasilkan +Air Minum bersih!")
				play_sfx("pickup", 1.2, 0.6)

	if grills > 0:
		if count("fish") > 0 or count("meat") > 0:
			grill_timer += delta
			if grill_timer >= 14.0:
				grill_timer = 0.0
				if count("fish") > 0:
					spend({"fish": 1})
					add_item("cooked_fish", 1)
					say("Pemanggang selesai memasak: +1 Ikan Bakar!")
					play_sfx("pickup", 1.15, 0.7)
				elif count("meat") > 0:
					spend({"meat": 1})
					add_item("cooked_meat", 1)
					say("Pemanggang selesai memasak: +1 Steak Hiu Bakar!")
					play_sfx("pickup", 1.15, 0.7)
		else:
			grill_timer = 0.0

	stat_timer += delta
	if stat_timer > 0.2:
		stat_timer = 0.0
		stats_changed.emit()
	_check_death()
