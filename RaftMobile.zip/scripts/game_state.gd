extends Node

signal inventory_changed
signal stats_changed
signal message(text)
signal player_died
signal purifier_added

const ITEM_NAMES = {
	"wood": "Kayu",
	"plastic": "Plastik",
	"scrap": "Besi Tua",
	"leaf": "Daun Palem",
	"coconut": "Kelapa",
	"can": "Makanan Kaleng",
	"water": "Air Minum",
	"fish": "Ikan Mentah",
	"meat": "Daging Hiu",
	"foundation": "Pondasi Rakit",
}

const USABLE = ["coconut", "can", "water", "fish", "meat"]

const RECIPES = [
	{"id": "foundation", "name": "Pondasi Rakit", "cost": {"wood": 4, "plastic": 2}},
	{"id": "rod", "name": "Pancing", "cost": {"wood": 2, "plastic": 2, "leaf": 1}},
	{"id": "spear", "name": "Tombak", "cost": {"wood": 3, "scrap": 2}},
	{"id": "purifier", "name": "Penyaring Air", "cost": {"wood": 6, "plastic": 4, "scrap": 3}},
]

var inventory = {}
var health = 100.0
var hunger = 100.0
var thirst = 100.0
var dead = false
var menu_open = false
var has_rod = false
var has_spear = false
var purifiers = 0
var purifier_timer = 0.0
var stat_timer = 0.0


func _ready():
	reset()


func reset():
	inventory = {"wood": 8, "plastic": 6, "scrap": 2, "leaf": 2, "water": 1, "can": 1}
	health = 100.0
	hunger = 100.0
	thirst = 100.0
	dead = false
	menu_open = false
	has_rod = false
	has_spear = false
	purifiers = 0
	purifier_timer = 0.0
	inventory_changed.emit()
	stats_changed.emit()


func say(t):
	message.emit(t)


func count(id):
	return inventory.get(id, 0)


func add_item(id, n = 1):
	inventory[id] = count(id) + n
	inventory_changed.emit()


func has_items(cost):
	for k in cost:
		if count(k) < cost[k]:
			return false
	return true


func spend(cost):
	for k in cost:
		inventory[k] = count(k) - cost[k]
		if inventory[k] <= 0:
			inventory.erase(k)
	inventory_changed.emit()


func craft(id):
	if dead:
		return
	var recipe = null
	for r in RECIPES:
		if r["id"] == id:
			recipe = r
	if recipe == null:
		return
	if not has_items(recipe["cost"]):
		say("Bahan tidak cukup")
		return
	if id == "rod" and has_rod:
		return
	if id == "spear" and has_spear:
		return
	spend(recipe["cost"])
	match id:
		"foundation":
			add_item("foundation", 1)
			say("Pondasi dibuat. Tekan BANGUN untuk memasang")
		"rod":
			has_rod = true
			say("Pancing siap! Tekan tombol PANCING")
		"spear":
			has_spear = true
			say("Tombak siap! Gunakan tombol SERANG")
		"purifier":
			purifiers += 1
			purifier_added.emit()
			say("Penyaring air dipasang: air minum otomatis")
	inventory_changed.emit()


func use_item(id):
	if dead or count(id) <= 0:
		return
	match id:
		"coconut":
			hunger = min(100.0, hunger + 12.0)
			thirst = min(100.0, thirst + 12.0)
		"can":
			hunger = min(100.0, hunger + 30.0)
		"water":
			thirst = min(100.0, thirst + 35.0)
		"fish":
			hunger = min(100.0, hunger + 22.0)
		"meat":
			hunger = min(100.0, hunger + 35.0)
		_:
			return
	inventory[id] = count(id) - 1
	if inventory[id] <= 0:
		inventory.erase(id)
	inventory_changed.emit()
	stats_changed.emit()


func collect(kind):
	if kind == "barrel":
		var loot = ["coconut", "can", "water", "wood", "plastic", "scrap"]
		var text = "Tong: "
		var n = randi_range(2, 3)
		for i in range(n):
			var it = loot.pick_random()
			add_item(it, 1)
			text += ITEM_NAMES[it]
			if i < n - 1:
				text += ", "
		say(text)
	else:
		add_item(kind, 1)
		say("+1 " + ITEM_NAMES.get(kind, kind))


func catch_fish():
	var r = randf()
	if r < 0.7:
		add_item("fish", 1)
		say("Dapat ikan!")
	elif r < 0.85:
		add_item("plastic", 1)
		say("Menarik sampah: +1 Plastik")
	else:
		add_item("leaf", 1)
		say("Menarik daun: +1 Daun Palem")


func damage(a):
	if dead:
		return
	health -= a
	stats_changed.emit()
	_check_death()


func _check_death():
	if health <= 0.0:
		health = 0.0
		dead = true
		stats_changed.emit()
		player_died.emit()


func _process(delta):
	if dead or menu_open:
		return
	hunger = max(0.0, hunger - 0.16 * delta)
	thirst = max(0.0, thirst - 0.22 * delta)
	if hunger <= 0.0 or thirst <= 0.0:
		health -= 1.2 * delta
	elif hunger > 35.0 and thirst > 35.0 and health < 100.0:
		health = min(100.0, health + 0.6 * delta)
	if purifiers > 0:
		purifier_timer += delta
		if purifier_timer >= 40.0:
			purifier_timer = 0.0
			var room = 10 - count("water")
			if room > 0:
				add_item("water", min(purifiers, room))
				say("Penyaring air menghasilkan air minum")
	stat_timer += delta
	if stat_timer > 0.2:
		stat_timer = 0.0
		stats_changed.emit()
	_check_death()
