extends Node

signal inventory_changed
signal stats_changed
signal message(text)
signal player_died
signal purifier_added
signal grill_added
signal lantern_added
signal settings_changed
signal world_loaded

const SETTINGS_PATH = "user://raft_settings.cfg"
const WORLDS_PATH = "user://raft_worlds.cfg"
const HOTBAR_SIZE = 8
const BAG_SIZE = 20

const ITEM_NAMES = {
	"hook": "Grappling Hook",
	"spear": "Tombak Besi",
	"rod": "Alat Pancing",
	"wood": "Kayu Apung",
	"plastic": "Plastik Laut",
	"scrap": "Besi Tua",
	"leaf": "Daun Palem",
	"rope": "Tali Serat",
	"coconut": "Kelapa Segar",
	"can": "Makanan Kaleng",
	"water": "Air Minum",
	"fish": "Ikan Mentah",
	"cooked_fish": "Ikan Bakar",
	"meat": "Daging Hiu",
	"cooked_meat": "Steak Hiu Bakar",
	"foundation": "Pondasi Rakit",
	"leaf_hat": "Topi Daun Palem",
	"wood_vest": "Rompi Papan Kayu",
	"rope_legs": "Pelindung Kaki Serat",
	"scrap_boots": "Sepatu Besi Laut",
}

const USABLE = ["water", "coconut", "cooked_fish", "cooked_meat", "can", "fish", "meat"]
const NON_STACKABLE = ["hook", "spear", "rod", "leaf_hat", "wood_vest", "rope_legs", "scrap_boots"]

const ARMOR_DEFS = {
	"leaf_hat": {"name": "Topi Daun Palem", "slot": "head", "def": 8},
	"wood_vest": {"name": "Rompi Papan Kayu", "slot": "chest", "def": 18},
	"rope_legs": {"name": "Pelindung Kaki Serat", "slot": "legs", "def": 12},
	"scrap_boots": {"name": "Sepatu Besi Laut", "slot": "feet", "def": 10},
}

const RECIPES = [
	{"id": "foundation", "name": "Pondasi Rakit (+Perluas)", "cost": {"wood": 4, "plastic": 2}},
	{"id": "rope", "name": "Tali Serat (x2)", "cost": {"leaf": 2}},
	{"id": "spear", "name": "Tombak Besi (Senjata Hiu)", "cost": {"wood": 3, "scrap": 2}},
	{"id": "rod", "name": "Alat Pancing Laut", "cost": {"wood": 2, "plastic": 2, "leaf": 1}},
	{"id": "leaf_hat", "name": "Armor: Topi Daun (+8% DEF)", "cost": {"leaf": 4, "rope": 1}},
	{"id": "wood_vest", "name": "Armor: Rompi Kayu (+18% DEF)", "cost": {"wood": 5, "rope": 2}},
	{"id": "rope_legs", "name": "Armor: Pelindung Kaki (+12% DEF)", "cost": {"rope": 2, "plastic": 3}},
	{"id": "scrap_boots", "name": "Armor: Sepatu Besi (+10% DEF)", "cost": {"scrap": 2, "plastic": 2}},
	{"id": "purifier", "name": "Bangunan: Penyaring Air Laut", "cost": {"wood": 5, "plastic": 4, "scrap": 2}},
	{"id": "grill", "name": "Bangunan: Pemanggang Ikan", "cost": {"wood": 4, "scrap": 2, "leaf": 2}},
	{"id": "lantern", "name": "Bangunan: Lentera Rakit", "cost": {"wood": 2, "scrap": 2, "plastic": 1}},
]

var inventory = {}
var hotbar = []
var bag_slots = []
var armor_slots = {"head": "", "chest": "", "legs": "", "feet": ""}
var selected_hotbar = 0

var health = 100.0
var hunger = 100.0
var thirst = 100.0
var dead = false
var menu_open = true
var in_world = false
var current_slot = 1
var world_name = "Samudra Biru #1"
var world_difficulty = "survival"
var saved_tiles = [[0, 0], [1, 0], [0, 1], [1, 1]]

var has_rod = false
var has_spear = false
var purifiers = 0
var grills = 0
var lanterns = 0
var purifier_timer = 0.0
var grill_timer = 0.0
var stat_timer = 0.0
var autosave_timer = 0.0
var day_count = 1
var time_of_day = 0.32

var worlds_meta = {}

var settings = {
	"brightness": 0.75,
	"wave_strength": 1.25,
	"gfx_preset": "medium",
	"res_scale": 1.0,
	"max_fps": 60,
	"shadows": false,
	"wave_quality": 2,
	"view_dist": 1,
	"fov": 75.0,
	"show_fps": true,
	"sfx_vol": 0.85,
	"amb_vol": 0.55,
	"sens": 1.0,
	"invert_y": false,
	"hook_charge_mode": true,
	"auto_reel": true,
	"hud_scale": 1.0,
	"hud_opacity": 0.92,
	"custom_hud": {},
}


func _ready():
	load_settings()
	load_worlds_index()
	reset()
	apply_settings()


func play_sfx(id, pitch = 1.0, vol_mul = 1.0):
	var sfx_node = get_node_or_null("/root/Sfx")
	if sfx_node != null and sfx_node.has_method("play"):
		sfx_node.play(id, pitch, vol_mul)


func play_reel_tick():
	var sfx_node = get_node_or_null("/root/Sfx")
	if sfx_node != null and sfx_node.has_method("play_reel_tick"):
		sfx_node.play_reel_tick()


func _init_empty_slots():
	hotbar.clear()
	for i in range(HOTBAR_SIZE):
		hotbar.append({"id": "", "count": 0})
	bag_slots.clear()
	for i in range(BAG_SIZE):
		bag_slots.append({"id": "", "count": 0})
	armor_slots = {"head": "", "chest": "", "legs": "", "feet": ""}
	selected_hotbar = 0


func reset():
	_init_empty_slots()
	# Only Slot 1 in Hotbar has the Grappling Hook at start; all other Hotbar & Bag slots are completely empty like Minecraft!
	hotbar[0] = {"id": "hook", "count": 1}
	health = 100.0
	hunger = 100.0
	thirst = 100.0
	dead = false
	has_rod = false
	has_spear = false
	purifiers = 0
	grills = 0
	lanterns = 0
	purifier_timer = 0.0
	grill_timer = 0.0
	day_count = 1
	time_of_day = 0.32
	saved_tiles = [[0, 0], [1, 0], [0, 1], [1, 1]]
	_rebuild_totals()
	inventory_changed.emit()
	stats_changed.emit()


func _rebuild_totals():
	inventory.clear()
	for s in hotbar:
		var id = str(s.get("id", ""))
		var c = int(s.get("count", 0))
		if id != "" and c > 0:
			inventory[id] = inventory.get(id, 0) + c
	for s in bag_slots:
		var id = str(s.get("id", ""))
		var c = int(s.get("count", 0))
		if id != "" and c > 0:
			inventory[id] = inventory.get(id, 0) + c
	has_spear = count("spear") > 0
	has_rod = count("rod") > 0


func get_selected_item_id():
	if selected_hotbar >= 0 and selected_hotbar < hotbar.size():
		var s = hotbar[selected_hotbar]
		if int(s.get("count", 0)) > 0:
			return str(s.get("id", ""))
	return ""


func get_armor_defense():
	var total = 0
	for k in armor_slots.keys():
		var aid = str(armor_slots[k])
		if ARMOR_DEFS.has(aid):
			total += int(ARMOR_DEFS[aid]["def"])
	return total


func is_armor_item(id):
	return ARMOR_DEFS.has(id)


func equip_armor_from_slot(slot_type, idx):
	var arr = hotbar if slot_type == "hotbar" else bag_slots
	if idx < 0 or idx >= arr.size():
		return false
	var id = str(arr[idx].get("id", ""))
	if not ARMOR_DEFS.has(id):
		return false
	var target_part = ARMOR_DEFS[id]["slot"]
	var prev_armor = str(armor_slots.get(target_part, ""))
	armor_slots[target_part] = id
	if prev_armor != "":
		arr[idx] = {"id": prev_armor, "count": 1}
	else:
		arr[idx] = {"id": "", "count": 0}
	_rebuild_totals()
	inventory_changed.emit()
	stats_changed.emit()
	say("Memakai " + ITEM_NAMES.get(id, id) + " (Pertahanan +" + str(get_armor_defense()) + "%)")
	play_sfx("build", 1.12, 0.85)
	return true


func unequip_armor(part):
	var cur = str(armor_slots.get(part, ""))
	if cur == "":
		return false
	if add_item(cur, 1):
		armor_slots[part] = ""
		_rebuild_totals()
		inventory_changed.emit()
		stats_changed.emit()
		say("Melepas " + ITEM_NAMES.get(cur, cur))
		play_sfx("ui", 0.95, 0.8)
		return true
	say("Tas penuh! Kosongkan 1 slot untuk melepas armor.")
	return false


func swap_or_move_slots(src_type, src_idx, dst_type, dst_idx):
	if src_type == dst_type and src_idx == dst_idx:
		return
	var src_arr = hotbar if src_type == "hotbar" else bag_slots
	var dst_arr = hotbar if dst_type == "hotbar" else bag_slots
	if src_idx < 0 or src_idx >= src_arr.size() or dst_idx < 0 or dst_idx >= dst_arr.size():
		return
	var a = src_arr[src_idx].duplicate()
	var b = dst_arr[dst_idx].duplicate()
	var a_id = str(a.get("id", ""))
	var b_id = str(b.get("id", ""))
	if a_id == "":
		return
	if a_id == b_id and not NON_STACKABLE.has(a_id):
		var max_stack = 64
		var total = int(a.get("count", 0)) + int(b.get("count", 0))
		if total <= max_stack:
			dst_arr[dst_idx] = {"id": a_id, "count": total}
			src_arr[src_idx] = {"id": "", "count": 0}
		else:
			dst_arr[dst_idx] = {"id": a_id, "count": max_stack}
			src_arr[src_idx] = {"id": a_id, "count": total - max_stack}
	else:
		dst_arr[dst_idx] = a
		src_arr[src_idx] = b
	_rebuild_totals()
	inventory_changed.emit()
	play_sfx("ui", 1.08, 0.75)


func drop_one_from_slot(slot_type, idx):
	var arr = hotbar if slot_type == "hotbar" else bag_slots
	if idx < 0 or idx >= arr.size():
		return
	var id = str(arr[idx].get("id", ""))
	var c = int(arr[idx].get("count", 0))
	if id == "" or c <= 0:
		return
	if id == "hook" and count("hook") <= 1:
		say("Grappling Hook utama tidak bisa dibuang!")
		return
	c -= 1
	if c <= 0:
		arr[idx] = {"id": "", "count": 0}
	else:
		arr[idx]["count"] = c
	_rebuild_totals()
	inventory_changed.emit()
	say("Membuang 1 " + ITEM_NAMES.get(id, id))
	play_sfx("ui", 0.85, 0.75)


func load_worlds_index():
	worlds_meta = {}
	var cfg = ConfigFile.new()
	if cfg.load(WORLDS_PATH) != OK:
		return
	for slot in [1, 2, 3, 4]:
		var sec = "world_%d" % slot
		if cfg.has_section(sec):
			worlds_meta[slot] = {
				"name": cfg.get_value(sec, "name", "Dunia #%d" % slot),
				"difficulty": cfg.get_value(sec, "difficulty", "survival"),
				"day_count": cfg.get_value(sec, "day_count", 1),
				"time_of_day": cfg.get_value(sec, "time_of_day", 0.32),
				"health": cfg.get_value(sec, "health", 100.0),
				"hunger": cfg.get_value(sec, "hunger", 100.0),
				"thirst": cfg.get_value(sec, "thirst", 100.0),
				"hotbar": cfg.get_value(sec, "hotbar", []),
				"bag_slots": cfg.get_value(sec, "bag_slots", []),
				"armor_slots": cfg.get_value(sec, "armor_slots", {"head": "", "chest": "", "legs": "", "feet": ""}),
				"purifiers": cfg.get_value(sec, "purifiers", 0),
				"grills": cfg.get_value(sec, "grills", 0),
				"lanterns": cfg.get_value(sec, "lanterns", 0),
				"tiles": cfg.get_value(sec, "tiles", [[0, 0], [1, 0], [0, 1], [1, 1]]),
			}


func has_world_slot(slot):
	return worlds_meta.has(slot)


func create_new_world(slot, w_name, diff):
	current_slot = slot
	world_name = w_name if w_name.strip_edges() != "" else ("Samudra #%d" % slot)
	world_difficulty = diff
	reset()
	save_current_world([[0, 0], [1, 0], [0, 1], [1, 1]])
	world_loaded.emit()


func load_world_slot(slot):
	load_worlds_index()
	if not worlds_meta.has(slot):
		create_new_world(slot, "Samudra #%d" % slot, "survival")
		return
	current_slot = slot
	var d = worlds_meta[slot]
	world_name = str(d.get("name", "Samudra #%d" % slot))
	world_difficulty = str(d.get("difficulty", "survival"))
	day_count = int(d.get("day_count", 1))
	time_of_day = float(d.get("time_of_day", 0.32))
	health = clamp(float(d.get("health", 100.0)), 15.0, 100.0)
	hunger = clamp(float(d.get("hunger", 100.0)), 20.0, 100.0)
	thirst = clamp(float(d.get("thirst", 100.0)), 20.0, 100.0)

	_init_empty_slots()
	var saved_hb = d.get("hotbar", [])
	if saved_hb is Array and saved_hb.size() == HOTBAR_SIZE:
		for i in range(HOTBAR_SIZE):
			if saved_hb[i] is Dictionary:
				hotbar[i] = {
					"id": str(saved_hb[i].get("id", "")),
					"count": int(saved_hb[i].get("count", 0)),
				}
	var saved_bg = d.get("bag_slots", [])
	if saved_bg is Array and saved_bg.size() == BAG_SIZE:
		for i in range(BAG_SIZE):
			if saved_bg[i] is Dictionary:
				bag_slots[i] = {
					"id": str(saved_bg[i].get("id", "")),
					"count": int(saved_bg[i].get("count", 0)),
				}
	var saved_arm = d.get("armor_slots", {})
	if saved_arm is Dictionary:
		for k in ["head", "chest", "legs", "feet"]:
			armor_slots[k] = str(saved_arm.get(k, ""))

	_rebuild_totals()
	if count("hook") <= 0:
		add_item("hook", 1)

	purifiers = int(d.get("purifiers", 0))
	grills = int(d.get("grills", 0))
	lanterns = int(d.get("lanterns", 0))
	saved_tiles = d.get("tiles", [[0, 0], [1, 0], [0, 1], [1, 1]])
	dead = false
	inventory_changed.emit()
	stats_changed.emit()
	world_loaded.emit()


func delete_world_slot(slot):
	load_worlds_index()
	worlds_meta.erase(slot)
	var cfg = ConfigFile.new()
	for s in worlds_meta.keys():
		var sec = "world_%d" % s
		var w = worlds_meta[s]
		for k in w.keys():
			cfg.set_value(sec, k, w[k])
	cfg.save(WORLDS_PATH)


func save_current_world(tile_list = null):
	if tile_list != null:
		saved_tiles = tile_list
	var hb_copy = []
	for s in hotbar:
		hb_copy.append(s.duplicate())
	var bg_copy = []
	for s in bag_slots:
		bg_copy.append(s.duplicate())
	worlds_meta[current_slot] = {
		"name": world_name,
		"difficulty": world_difficulty,
		"day_count": day_count,
		"time_of_day": time_of_day,
		"health": health,
		"hunger": hunger,
		"thirst": thirst,
		"hotbar": hb_copy,
		"bag_slots": bg_copy,
		"armor_slots": armor_slots.duplicate(),
		"purifiers": purifiers,
		"grills": grills,
		"lanterns": lanterns,
		"tiles": saved_tiles,
	}
	var cfg = ConfigFile.new()
	for s in worlds_meta.keys():
		var sec = "world_%d" % s
		var w = worlds_meta[s]
		for k in w.keys():
			cfg.set_value(sec, k, w[k])
	cfg.save(WORLDS_PATH)


func load_settings():
	var cfg = ConfigFile.new()
	if cfg.load(SETTINGS_PATH) != OK:
		return
	for k in settings.keys():
		if cfg.has_section_key("settings", k):
			settings[k] = cfg.get_value("settings", k, settings[k])


func save_settings():
	var cfg = ConfigFile.new()
	for k in settings.keys():
		cfg.set_value("settings", k, settings[k])
	cfg.save(SETTINGS_PATH)
	apply_settings()


func apply_gfx_preset(preset):
	settings["gfx_preset"] = preset
	if preset == "low":
		settings["res_scale"] = 0.75
		settings["max_fps"] = 60
		settings["shadows"] = false
		settings["wave_quality"] = 1
		settings["view_dist"] = 0
	elif preset == "medium":
		settings["res_scale"] = 1.0
		settings["max_fps"] = 60
		settings["shadows"] = false
		settings["wave_quality"] = 2
		settings["view_dist"] = 1
	elif preset == "high":
		settings["res_scale"] = 1.0
		settings["max_fps"] = 60
		settings["shadows"] = true
		settings["wave_quality"] = 3
		settings["view_dist"] = 2
	save_settings()


func apply_settings():
	Engine.max_fps = int(settings.get("max_fps", 60))
	var sfx_node = get_node_or_null("/root/Sfx")
	if sfx_node != null and sfx_node.has_method("update_volumes"):
		sfx_node.update_volumes(float(settings.get("sfx_vol", 0.85)), float(settings.get("amb_vol", 0.55)))
	settings_changed.emit()


func reset_custom_hud():
	settings["custom_hud"] = {}
	settings["hud_scale"] = 1.0
	settings["hud_opacity"] = 0.92
	save_settings()


func say(t):
	message.emit(t)


func count(id):
	return int(inventory.get(id, 0))


func add_item(id, n = 1):
	if n <= 0:
		return false
	var rem = int(n)
	var stackable = not NON_STACKABLE.has(id)
	var max_stack = 64 if stackable else 1

	if stackable:
		for i in range(HOTBAR_SIZE):
			if hotbar[i]["id"] == id and hotbar[i]["count"] < max_stack:
				var add = min(rem, max_stack - int(hotbar[i]["count"]))
				hotbar[i]["count"] += add
				rem -= add
				if rem <= 0:
					_rebuild_totals()
					inventory_changed.emit()
					return true
		for i in range(BAG_SIZE):
			if bag_slots[i]["id"] == id and bag_slots[i]["count"] < max_stack:
				var add = min(rem, max_stack - int(bag_slots[i]["count"]))
				bag_slots[i]["count"] += add
				rem -= add
				if rem <= 0:
					_rebuild_totals()
					inventory_changed.emit()
					return true

	# Place remaining in empty slots (Hotbar first if tool/consumable, or Bag/Hotbar)
	for i in range(HOTBAR_SIZE):
		if hotbar[i]["id"] == "" or int(hotbar[i]["count"]) <= 0:
			var put = min(rem, max_stack)
			hotbar[i] = {"id": id, "count": put}
			rem -= put
			if rem <= 0:
				_rebuild_totals()
				inventory_changed.emit()
				return true

	for i in range(BAG_SIZE):
		if bag_slots[i]["id"] == "" or int(bag_slots[i]["count"]) <= 0:
			var put = min(rem, max_stack)
			bag_slots[i] = {"id": id, "count": put}
			rem -= put
			if rem <= 0:
				_rebuild_totals()
				inventory_changed.emit()
				return true

	_rebuild_totals()
	inventory_changed.emit()
	if rem > 0:
		say("Tas penuh! Sebagian barang tidak muat.")
	return rem < n


func has_items(cost):
	for k in cost:
		if count(k) < cost[k]:
			return false
	return true


func spend(cost):
	for k in cost:
		var need = int(cost[k])
		# Deduct from bag first, then hotbar
		for i in range(BAG_SIZE - 1, -1, -1):
			if need <= 0:
				break
			if bag_slots[i]["id"] == k:
				var take = min(need, int(bag_slots[i]["count"]))
				bag_slots[i]["count"] -= take
				need -= take
				if bag_slots[i]["count"] <= 0:
					bag_slots[i] = {"id": "", "count": 0}
		for i in range(HOTBAR_SIZE - 1, -1, -1):
			if need <= 0:
				break
			if hotbar[i]["id"] == k:
				var take = min(need, int(hotbar[i]["count"]))
				hotbar[i]["count"] -= take
				need -= take
				if hotbar[i]["count"] <= 0:
					hotbar[i] = {"id": "", "count": 0}
	_rebuild_totals()
	inventory_changed.emit()


func craft(id):
	if dead:
		return
	var recipe = null
	for r in RECIPES:
		if r["id"] == id:
			recipe = r
	if recipe == null:
		return
	if not has_items(recipe["cost"]):
		say("Bahan belum cukup untuk membuat " + recipe["name"])
		return
	if id == "rod" and has_rod:
		say("Kamu sudah punya Alat Pancing di Tas/Hotbar!")
		return
	if id == "spear" and has_spear:
		say("Kamu sudah punya Tombak Besi di Tas/Hotbar!")
		return
	spend(recipe["cost"])
	match id:
		"foundation":
			add_item("foundation", 1)
			say("Pondasi Rakit dibuat! Tekan BANGUN untuk memasang.")
		"rope":
			add_item("rope", 2)
			say("+2 Tali Serat berhasil dibuat!")
		"rod":
			add_item("rod", 1)
			say("Alat Pancing dibuat dan masuk ke slot inventori!")
		"spear":
			add_item("spear", 1)
			say("Tombak Besi dibuat dan masuk ke slot inventori!")
		"leaf_hat", "wood_vest", "rope_legs", "scrap_boots":
			var part = ARMOR_DEFS[id]["slot"]
			if str(armor_slots.get(part, "")) == "":
				armor_slots[part] = id
				say(ITEM_NAMES.get(id, id) + " dibuat & langsung dipakai! (DEF +" + str(get_armor_defense()) + "%)")
			else:
				add_item(id, 1)
				say(ITEM_NAMES.get(id, id) + " dibuat dan masuk ke Tas!")
		"purifier":
			purifiers += 1
			purifier_added.emit()
			say("Penyaring Air dipasang di atas rakit!")
		"grill":
			grills += 1
			grill_added.emit()
			say("Pemanggang dipasang di atas rakit!")
		"lantern":
			lanterns += 1
			lantern_added.emit()
			say("Lentera Rakit dipasang! Menerangi rakit saat malam.")
	_rebuild_totals()
	inventory_changed.emit()
	stats_changed.emit()
	save_current_world()
	play_sfx("build", 1.05, 0.9)


func use_item(id):
	if dead or count(id) <= 0:
		return
	if is_armor_item(id):
		for i in range(HOTBAR_SIZE):
			if hotbar[i]["id"] == id:
				equip_armor_from_slot("hotbar", i)
				return
		for i in range(BAG_SIZE):
			if bag_slots[i]["id"] == id:
				equip_armor_from_slot("bag", i)
				return
		return
	match id:
		"coconut":
			hunger = min(100.0, hunger + 14.0)
			thirst = min(100.0, thirst + 16.0)
		"can":
			hunger = min(100.0, hunger + 32.0)
			thirst = min(100.0, thirst + 8.0)
		"water":
			thirst = min(100.0, thirst + 38.0)
		"fish":
			hunger = min(100.0, hunger + 18.0)
		"cooked_fish":
			hunger = min(100.0, hunger + 42.0)
			health = min(100.0, health + 8.0)
		"meat":
			hunger = min(100.0, hunger + 28.0)
		"cooked_meat":
			hunger = min(100.0, hunger + 55.0)
			health = min(100.0, health + 15.0)
		_:
			return
	spend({id: 1})
	stats_changed.emit()
	say("Mengonsumsi " + ITEM_NAMES.get(id, id))
	play_sfx("consume", 1.0, 0.85)


func collect(kind):
	if kind == "barrel" or kind == "crate":
		var loot = ["coconut", "can", "water", "wood", "plastic", "scrap", "leaf"]
		var prefix = "Tong Apung: " if kind == "barrel" else "Peti Laut: "
		var n = randi_range(2, 4) if kind == "crate" else randi_range(2, 3)
		for i in range(n):
			var it = loot.pick_random()
			add_item(it, 1)
			prefix += ITEM_NAMES[it]
			if i < n - 1:
				prefix += ", "
		say(prefix)
	else:
		add_item(kind, 1)
		say("+1 " + ITEM_NAMES.get(kind, kind))
	play_sfx("pickup", randf_range(0.96, 1.08), 0.85)


func catch_fish():
	var r = randf()
	if r < 0.72:
		if grills > 0:
			add_item("cooked_fish", 1)
			say("Dapat ikan & langsung dipanggang: +1 Ikan Bakar!")
		else:
			add_item("fish", 1)
			say("Berhasil memancing: +1 Ikan Mentah!")
	elif r < 0.88:
		add_item("plastic", 1)
		say("Kail mengangkat sampah: +1 Plastik Laut")
	else:
		add_item("coconut", 1)
		say("Kail mengangkat Kelapa Segar!")
	play_sfx("pickup", 1.1, 0.9)


func damage(a):
	if dead:
		return
	var def_pct = clamp(float(get_armor_defense()) / 100.0, 0.0, 0.65)
	var final_dmg = float(a) * (1.0 - def_pct)
	health -= final_dmg
	stats_changed.emit()
	_check_death()


func _check_death():
	if health <= 0.0:
		health = 0.0
		dead = true
		stats_changed.emit()
		player_died.emit()


func _process(delta):
	if dead or menu_open or not in_world:
		return
	time_of_day += delta / 240.0
	if time_of_day >= 1.0:
		time_of_day -= 1.0
		day_count += 1
		save_current_world()
		say("Hari ke-%d dimulai di tengah samudra!" % day_count)

	var drain_mul = 0.65 if world_difficulty == "peaceful" else (1.35 if world_difficulty == "hardcore" else 1.0)
	hunger = max(0.0, hunger - 0.14 * drain_mul * delta)
	thirst = max(0.0, thirst - 0.19 * drain_mul * delta)
	if hunger <= 0.0 or thirst <= 0.0:
		health -= 1.10 * delta
	elif hunger > 35.0 and thirst > 35.0 and health < 100.0:
		health = min(100.0, health + 0.65 * delta)

	if purifiers > 0:
		purifier_timer += delta
		if purifier_timer >= 36.0:
			purifier_timer = 0.0
			var room = 12 - count("water")
			if room > 0:
				add_item("water", min(purifiers, room))
				say("Penyaring Air menghasilkan +Air Minum bersih!")
				play_sfx("pickup", 1.2, 0.6)

	if grills > 0:
		if count("fish") > 0 or count("meat") > 0:
			grill_timer += delta
			if grill_timer >= 14.0:
				grill_timer = 0.0
				if count("fish") > 0:
					spend({"fish": 1})
					add_item("cooked_fish", 1)
					say("Pemanggang selesai memasak: +1 Ikan Bakar!")
					play_sfx("pickup", 1.15, 0.7)
				elif count("meat") > 0:
					spend({"meat": 1})
					add_item("cooked_meat", 1)
					say("Pemanggang selesai memasak: +1 Steak Hiu Bakar!")
					play_sfx("pickup", 1.15, 0.7)
		else:
			grill_timer = 0.0

	autosave_timer += delta
	if autosave_timer >= 20.0:
		autosave_timer = 0.0
		save_current_world()

	stat_timer += delta
	if stat_timer > 0.2:
		stat_timer = 0.0
		stats_changed.emit()
	_check_death()
