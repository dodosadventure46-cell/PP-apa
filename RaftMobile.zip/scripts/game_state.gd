extends Node

signal inventory_changed
signal stats_changed
signal message(text)
signal player_died
signal purifier_added
signal grill_added
signal lantern_added
signal settings_changed

const SETTINGS_PATH = "user://raft_settings.cfg"

const ITEM_NAMES = {
	"wood": "Kayu Apung",
	"plastic": "Plastik",
	"scrap": "Besi Tua",
	"leaf": "Daun Palem",
	"rope": "Tali Serat",
	"coconut": "Kelapa Segar",
	"can": "Makanan Kaleng",
	"water": "Air Minum",
	"fish": "Ikan Mentah",
	"cooked_fish": "Ikan Bakar",
	"meat": "Daging Hiu",
	"cooked_meat": "Steak Hiu Bakar",
	"foundation": "Pondasi Rakit",
}

const USABLE = ["water", "coconut", "cooked_fish", "cooked_meat", "can", "fish", "meat"]

const RECIPES = [
	{"id": "foundation", "name": "Pondasi Rakit (+Perluas)", "cost": {"wood": 4, "plastic": 2}},
	{"id": "rope", "name": "Tali Serat (x2)", "cost": {"leaf": 2}},
	{"id": "spear", "name": "Tombak Besi (Senjata Hiu)", "cost": {"wood": 3, "scrap": 2}},
	{"id": "rod", "name": "Alat Pancing Laut", "cost": {"wood": 2, "plastic": 2, "leaf": 1}},
	{"id": "purifier", "name": "Penyaring Air Laut Otomatis", "cost": {"wood": 5, "plastic": 4, "scrap": 2}},
	{"id": "grill", "name": "Pemanggang Ikan & Daging", "cost": {"wood": 4, "scrap": 2, "leaf": 2}},
	{"id": "lantern", "name": "Lentera Rakit (Penerang Malam)", "cost": {"wood": 2, "scrap": 2, "plastic": 1}},
]

var inventory = {}
var health = 100.0
var hunger = 100.0
var thirst = 100.0
var dead = false
var menu_open = false
var has_rod = false
var has_spear = false
var purifiers = 0
var grills = 0
var lanterns = 0
var purifier_timer = 0.0
var grill_timer = 0.0
var stat_timer = 0.0
var day_count = 1
var time_of_day = 0.32 # 0.0 = midnight, 0.25 = dawn, 0.5 = noon, 0.75 = sunset

var settings = {
	"gfx_preset": "medium",
	"res_scale": 1.0,
	"max_fps": 60,
	"shadows": false,
	"wave_quality": 2,
	"view_dist": 1,
	"fov": 75.0,
	"show_fps": true,
	"sfx_vol": 0.85,
	"amb_vol": 0.55,
	"sens": 1.0,
	"invert_y": false,
	"hook_charge_mode": true,
	"auto_reel": true,
	"hud_scale": 1.0,
	"hud_opacity": 0.92,
	"custom_hud": {},
}


func _ready():
	load_settings()
	reset()
	apply_settings()


func reset():
	inventory = {
		"wood": 8,
		"plastic": 6,
		"scrap": 2,
		"leaf": 4,
		"water": 2,
		"coconut": 1,
		"can": 1,
	}
	health = 100.0
	hunger = 100.0
	thirst = 100.0
	dead = false
	menu_open = false
	has_rod = false
	has_spear = false
	purifiers = 0
	grills = 0
	lanterns = 0
	purifier_timer = 0.0
	grill_timer = 0.0
	day_count = 1
	time_of_day = 0.32
	inventory_changed.emit()
	stats_changed.emit()


func load_settings():
	var cfg = ConfigFile.new()
	if cfg.load(SETTINGS_PATH) != OK:
		return
	for k in settings.keys():
		if cfg.has_section_key("settings", k):
			settings[k] = cfg.get_value("settings", k, settings[k])


func save_settings():
	var cfg = ConfigFile.new()
	for k in settings.keys():
		cfg.set_value("settings", k, settings[k])
	cfg.save(SETTINGS_PATH)
	apply_settings()


func apply_gfx_preset(preset):
	settings["gfx_preset"] = preset
	if preset == "low":
		settings["res_scale"] = 0.75
		settings["max_fps"] = 60
		settings["shadows"] = false
		settings["wave_quality"] = 1
		settings["view_dist"] = 0
	elif preset == "medium":
		settings["res_scale"] = 1.0
		settings["max_fps"] = 60
		settings["shadows"] = false
		settings["wave_quality"] = 2
		settings["view_dist"] = 1
	elif preset == "high":
		settings["res_scale"] = 1.0
		settings["max_fps"] = 60
		settings["shadows"] = true
		settings["wave_quality"] = 3
		settings["view_dist"] = 2
	save_settings()


func apply_settings():
	Engine.max_fps = int(settings["max_fps"])
	var vp = get_viewport()
	if vp != null:
		vp.scaling_3d_scale = clamp(float(settings["res_scale"]), 0.5, 1.0)
	if Sfx != null:
		Sfx.update_volumes(float(settings["sfx_vol"]), float(settings["amb_vol"]))
	settings_changed.emit()


func reset_custom_hud():
	settings["custom_hud"] = {}
	settings["hud_scale"] = 1.0
	settings["hud_opacity"] = 0.92
	save_settings()


func say(t):
	message.emit(t)


func count(id):
	return inventory.get(id, 0)


func add_item(id, n = 1):
	inventory[id] = count(id) + n
	inventory_changed.emit()


func has_items(cost):
	for k in cost:
		if count(k) < cost[k]:
			return false
	return true


func spend(cost):
	for k in cost:
		inventory[k] = count(k) - cost[k]
		if inventory[k] <= 0:
			inventory.erase(k)
	inventory_changed.emit()


func craft(id):
	if dead:
		return
	var recipe = null
	for r in RECIPES:
		if r["id"] == id:
			recipe = r
	if recipe == null:
		return
	if not has_items(recipe["cost"]):
		say("Bahan belum cukup untuk membuat " + recipe["name"])
		return
	if id == "rod" and has_rod:
		return
	if id == "spear" and has_spear:
		return
	spend(recipe["cost"])
	Sfx.play("build", 1.05, 0.9)
	match id:
		"foundation":
			add_item("foundation", 1)
			say("Pondasi Rakit dibuat! Tekan BANGUN untuk memasang.")
		"rope":
			add_item("rope", 2)
			say("+2 Tali Serat dibuat!")
		"rod":
			has_rod = true
			say("Alat Pancing siap! Tekan tombol PANCING di HUD.")
		"spear":
			has_spear = true
			say("Tombak Besi siap! Gunakan tombol SERANG.")
		"purifier":
			purifiers += 1
			purifier_added.emit()
			say("Penyaring Air dipasang di rakit (air minum otomatis).")
		"grill":
			grills += 1
			grill_added.emit()
			say("Pemanggang dipasang! Otomatis memanggang ikan/daging mentah.")
		"lantern":
			lanterns += 1
			lantern_added.emit()
			say("Lentera Rakit dipasang! Menerangi rakit saat malam.")
	inventory_changed.emit()


func use_item(id):
	if dead or count(id) <= 0:
		return
	match id:
		"coconut":
			hunger = min(100.0, hunger + 14.0)
			thirst = min(100.0, thirst + 16.0)
		"can":
			hunger = min(100.0, hunger + 32.0)
			thirst = min(100.0, thirst + 8.0)
		"water":
			thirst = min(100.0, thirst + 38.0)
		"fish":
			hunger = min(100.0, hunger + 18.0)
		"cooked_fish":
			hunger = min(100.0, hunger + 42.0)
			health = min(100.0, health + 8.0)
		"meat":
			hunger = min(100.0, hunger + 28.0)
		"cooked_meat":
			hunger = min(100.0, hunger + 55.0)
			health = min(100.0, health + 15.0)
		_:
			return
	Sfx.play("consume", 1.0, 0.85)
	inventory[id] = count(id) - 1
	if inventory[id] <= 0:
		inventory.erase(id)
	inventory_changed.emit()
	stats_changed.emit()
	say("Mengonsumsi " + ITEM_NAMES.get(id, id))


func collect(kind):
	Sfx.play("pickup", randf_range(0.96, 1.08), 0.85)
	if kind == "barrel" or kind == "crate":
		var loot = ["coconut", "can", "water", "wood", "plastic", "scrap", "leaf"]
		var prefix = "Tong Apung: " if kind == "barrel" else "Peti Laut: "
		var n = randi_range(2, 4) if kind == "crate" else randi_range(2, 3)
		for i in range(n):
			var it = loot.pick_random()
			add_item(it, 1)
			prefix += ITEM_NAMES[it]
			if i < n - 1:
				prefix += ", "
		say(prefix)
	else:
		add_item(kind, 1)
		say("+1 " + ITEM_NAMES.get(kind, kind))


func catch_fish():
	Sfx.play("pickup", 1.1, 0.9)
	var r = randf()
	if r < 0.72:
		if grills > 0:
			add_item("cooked_fish", 1)
			say("Dapat ikan & langsung dipanggang: +1 Ikan Bakar!")
		else:
			add_item("fish", 1)
			say("Berhasil memancing: +1 Ikan Mentah!")
	elif r < 0.88:
		add_item("plastic", 1)
		say("Kail mengangkat sampah: +1 Plastik")
	else:
		add_item("coconut", 1)
		say("Kail mengangkat Kelapa Segar!")


func damage(a):
	if dead:
		return
	health -= a
	stats_changed.emit()
	_check_death()


func _check_death():
	if health <= 0.0:
		health = 0.0
		dead = true
		stats_changed.emit()
		player_died.emit()


func _process(delta):
	if dead or menu_open:
		return
	# Day-night progression (1 full day = ~240 seconds)
	time_of_day += delta / 240.0
	if time_of_day >= 1.0:
		time_of_day -= 1.0
		day_count += 1
		say("Hari ke-%d dimulai di tengah samudra!" % day_count)

	hunger = max(0.0, hunger - 0.15 * delta)
	thirst = max(0.0, thirst - 0.21 * delta)
	if hunger <= 0.0 or thirst <= 0.0:
		health -= 1.15 * delta
	elif hunger > 35.0 and thirst > 35.0 and health < 100.0:
		health = min(100.0, health + 0.65 * delta)

	if purifiers > 0:
		purifier_timer += delta
		if purifier_timer >= 36.0:
			purifier_timer = 0.0
			var room = 12 - count("water")
			if room > 0:
				add_item("water", min(purifiers, room))
				Sfx.play("pickup", 1.2, 0.6)
				say("Penyaring Air menghasilkan +Air Minum bersih!")

	if grills > 0:
		if count("fish") > 0 or count("meat") > 0:
			grill_timer += delta
			if grill_timer >= 14.0:
				grill_timer = 0.0
				if count("fish") > 0:
					spend({"fish": 1})
					add_item("cooked_fish", 1)
					Sfx.play("pickup", 1.15, 0.7)
					say("Pemanggang selesai memasak: +1 Ikan Bakar!")
				elif count("meat") > 0:
					spend({"meat": 1})
					add_item("cooked_meat", 1)
					Sfx.play("pickup", 1.15, 0.7)
					say("Pemanggang selesai memasak: +1 Steak Hiu Bakar!")
		else:
			grill_timer = 0.0

	stat_timer += delta
	if stat_timer > 0.2:
		stat_timer = 0.0
		stats_changed.emit()
	_check_death()
