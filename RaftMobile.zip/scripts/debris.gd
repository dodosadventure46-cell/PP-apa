extends Area3D

const OceanScript = preload("res://scripts/ocean.gd")

var kind = "wood"
var speed = 1.25
var phase = 0.0
var spin = 0.0
var hooked = false
var hook_ref = null
var hook_offset = Vector3.ZERO


func _ready():
	add_to_group("debris")
	collision_layer = 2
	collision_mask = 0
	monitoring = false
	phase = randf() * TAU
	spin = randf_range(-0.45, 0.45)
	rotation.y = randf() * TAU
	var cs = CollisionShape3D.new()
	var sp = SphereShape3D.new()
	sp.radius = 1.25
	cs.shape = sp
	add_child(cs)
	_build_mesh()


func _add_box(size, color, pos = Vector3.ZERO, rot = Vector3.ZERO, metal = 0.0, rough = 0.8):
	var mi = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	var m = StandardMaterial3D.new()
	m.albedo_color = color
	m.metallic = metal
	m.roughness = rough
	mi.material_override = m
	mi.position = pos
	mi.rotation = rot
	add_child(mi)


func _add_cyl(top_r, bot_r, height, color, pos = Vector3.ZERO, rot = Vector3.ZERO, metal = 0.0):
	var mi = MeshInstance3D.new()
	var cm = CylinderMesh.new()
	cm.top_radius = top_r
	cm.bottom_radius = bot_r
	cm.height = height
	mi.mesh = cm
	var m = StandardMaterial3D.new()
	m.albedo_color = color
	m.metallic = metal
	m.roughness = 0.65
	mi.material_override = m
	mi.position = pos
	mi.rotation = rot
	add_child(mi)


func _build_mesh():
	match kind:
		"wood":
			_add_box(Vector3(1.45, 0.11, 0.28), Color(0.54, 0.36, 0.18), Vector3(0, 0.04, -0.1))
			_add_box(Vector3(1.2, 0.1, 0.26), Color(0.46, 0.30, 0.14), Vector3(0.08, 0.09, 0.18), Vector3(0, 0.18, 0))
			_add_box(Vector3(0.16, 0.13, 0.56), Color(0.72, 0.58, 0.34), Vector3(-0.25, 0.07, 0.04))
		"plastic":
			_add_cyl(0.16, 0.16, 0.52, Color(0.65, 0.88, 0.98), Vector3(0, 0.12, 0), Vector3(0, 0, PI / 2.0), 0.1)
			_add_cyl(0.17, 0.17, 0.18, Color(0.18, 0.48, 0.85), Vector3(0.02, 0.12, 0), Vector3(0, 0, PI / 2.0), 0.1)
			_add_cyl(0.07, 0.07, 0.1, Color(0.92, 0.2, 0.18), Vector3(0.31, 0.12, 0), Vector3(0, 0, PI / 2.0))
		"scrap":
			_add_box(Vector3(0.76, 0.06, 0.54), Color(0.52, 0.55, 0.6), Vector3(0, 0.05, 0), Vector3(0, 0, 0.08), 0.82, 0.45)
			_add_box(Vector3(0.45, 0.07, 0.34), Color(0.58, 0.36, 0.22), Vector3(0.16, 0.1, 0.08), Vector3(0.08, 0.45, 0), 0.65, 0.6)
			_add_cyl(0.12, 0.12, 0.14, Color(0.38, 0.4, 0.44), Vector3(-0.15, 0.1, -0.05), Vector3.ZERO, 0.85)
		"leaf":
			_add_box(Vector3(1.15, 0.03, 0.24), Color(0.22, 0.64, 0.22), Vector3(0, 0.05, 0), Vector3(0, 0.1, 0.06))
			_add_box(Vector3(0.95, 0.03, 0.22), Color(0.28, 0.72, 0.26), Vector3(0.05, 0.06, 0.14), Vector3(0, -0.22, 0.04))
			_add_box(Vector3(0.95, 0.03, 0.22), Color(0.18, 0.56, 0.18), Vector3(0.05, 0.06, -0.14), Vector3(0, 0.35, -0.04))
		"barrel":
			_add_cyl(0.38, 0.38, 0.86, Color(0.76, 0.28, 0.14), Vector3(0, 0.26, 0))
			_add_cyl(0.40, 0.40, 0.07, Color(0.22, 0.24, 0.26), Vector3(0, 0.52, 0), Vector3.ZERO, 0.8)
			_add_cyl(0.40, 0.40, 0.07, Color(0.22, 0.24, 0.26), Vector3(0, 0.02, 0), Vector3.ZERO, 0.8)
		"crate":
			_add_box(Vector3(0.74, 0.52, 0.74), Color(0.62, 0.42, 0.20), Vector3(0, 0.22, 0))
			_add_box(Vector3(0.78, 0.08, 0.78), Color(0.36, 0.24, 0.12), Vector3(0, 0.44, 0))
			_add_box(Vector3(0.14, 0.16, 0.79), Color(0.85, 0.68, 0.22), Vector3(0, 0.28, 0), Vector3.ZERO, 0.75)


func snag_by_hook(h_node, offset = Vector3.ZERO):
	if hooked:
		return false
	hooked = true
	hook_ref = h_node
	hook_offset = offset
	collision_layer = 0
	return true


func _process(delta):
	if hooked:
		if hook_ref != null and is_instance_valid(hook_ref):
			var hp = hook_ref.global_position + hook_offset
			hp.y = OceanScript.height(hp.x, hp.z) + 0.06
			global_position = global_position.lerp(hp, clamp(delta * 18.0, 0.0, 1.0))
			rotation.y += delta * 3.5
		return
	var pos = global_position
	pos.x += speed * delta
	pos.z += speed * 0.18 * delta
	pos.y = OceanScript.height(pos.x, pos.z) + sin(Time.get_ticks_msec() * 0.0018 + phase) * 0.035
	global_position = pos
	rotation.y += spin * delta
	if pos.x > 72.0:
		queue_free()
