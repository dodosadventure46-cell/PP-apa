extends Area3D

const OceanScript = preload("res://scripts/ocean.gd")

var kind = "wood"
var speed = 1.3
var phase = 0.0
var spin = 0.0
var pulled = false
var pull_t = 0.0
var pull_start = Vector3.ZERO
var target_player = null


func _ready():
	add_to_group("debris")
	collision_layer = 2
	collision_mask = 0
	monitoring = false
	phase = randf() * TAU
	spin = randf_range(-0.4, 0.4)
	rotation.y = randf() * TAU
	var cs = CollisionShape3D.new()
	var sp = SphereShape3D.new()
	sp.radius = 1.1
	cs.shape = sp
	add_child(cs)
	_build_mesh()


func _add_box(size, color, pos = Vector3.ZERO, rot = Vector3.ZERO, metal = 0.0):
	var mi = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	var m = StandardMaterial3D.new()
	m.albedo_color = color
	m.metallic = metal
	m.roughness = 0.8
	mi.material_override = m
	mi.position = pos
	mi.rotation = rot
	add_child(mi)


func _add_cyl(radius, height, color, pos = Vector3.ZERO):
	var mi = MeshInstance3D.new()
	var cm = CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = height
	mi.mesh = cm
	var m = StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.7
	mi.material_override = m
	mi.position = pos
	add_child(mi)


func _build_mesh():
	match kind:
		"wood":
			_add_box(Vector3(1.4, 0.1, 0.3), Color(0.5, 0.33, 0.16))
			_add_box(Vector3(1.1, 0.1, 0.28), Color(0.45, 0.3, 0.14), Vector3(0.1, 0.1, 0.32), Vector3(0, 0.15, 0))
		"plastic":
			_add_box(Vector3(0.55, 0.25, 0.25), Color(0.7, 0.86, 0.95), Vector3(0, 0.1, 0))
			_add_box(Vector3(0.1, 0.12, 0.12), Color(0.9, 0.2, 0.2), Vector3(0.32, 0.1, 0))
		"scrap":
			_add_box(Vector3(0.7, 0.06, 0.5), Color(0.55, 0.57, 0.6), Vector3(0, 0.05, 0), Vector3(0, 0, 0.1), 0.8)
			_add_box(Vector3(0.4, 0.05, 0.3), Color(0.45, 0.35, 0.3), Vector3(0.2, 0.1, 0.1), Vector3(0.1, 0.5, 0), 0.6)
		"leaf":
			_add_box(Vector3(1.1, 0.02, 0.4), Color(0.2, 0.6, 0.2), Vector3(0, 0.05, 0), Vector3(0, 0, 0.08))
		"barrel":
			_add_cyl(0.4, 0.85, Color(0.8, 0.2, 0.1), Vector3(0, 0.3, 0))
			_add_cyl(0.42, 0.08, Color(0.25, 0.1, 0.08), Vector3(0, 0.55, 0))
			_add_cyl(0.42, 0.08, Color(0.25, 0.1, 0.08), Vector3(0, 0.05, 0))


func pull_to(p):
	if pulled:
		return
	pulled = true
	target_player = p
	pull_start = global_position
	collision_layer = 0


func _process(delta):
	if pulled:
		pull_t += delta / 0.6
		var t = clamp(pull_t, 0.0, 1.0)
		var tp = target_player.global_position + Vector3(0, 1.2, 0)
		var s = t * t * (3.0 - 2.0 * t)
		var p = pull_start.lerp(tp, s)
		p.y += sin(t * PI) * 1.2
		global_position = p
		rotation.y += delta * 8.0
		if t >= 1.0:
			Game.collect(kind)
			queue_free()
		return
	var pos = global_position
	pos.x += speed * delta
	pos.z += speed * 0.2 * delta
	pos.y = OceanScript.height(pos.x, pos.z) + sin(Time.get_ticks_msec() * 0.0015 + phase) * 0.03
	global_position = pos
	rotation.y += spin * delta
	if pos.x > 70.0:
		queue_free()
