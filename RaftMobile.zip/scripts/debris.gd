extends Area3D

const OceanScript = preload("res://scripts/ocean.gd")
const PixelUI = preload("res://scripts/pixel_ui.gd")

var kind = "wood"
var speed = 1.25
var phase = 0.0
var spin = 0.0
var hooked = false
var hook_ref = null
var hook_offset = Vector3.ZERO


func _ready():
	add_to_group("debris")
	collision_layer = 2
	collision_mask = 0
	monitoring = false
	phase = randf() * TAU
	spin = randf_range(-0.45, 0.45)
	rotation.y = randf() * TAU
	var cs = CollisionShape3D.new()
	var sp = SphereShape3D.new()
	sp.radius = 1.35
	cs.shape = sp
	add_child(cs)
	_build_mesh()


func _add_box_tex(size, tex_kind, pos = Vector3.ZERO, rot = Vector3.ZERO, uv_sc = Vector3(1, 1, 1), metal = 0.0, rough = 0.85, tint = Color.WHITE):
	var mi = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = PixelUI.make_3d_mat(tex_kind, uv_sc, false, metal, rough, tint)
	mi.position = pos
	mi.rotation = rot
	add_child(mi)


func _add_cyl_tex(top_r, bot_r, height, tex_kind, pos = Vector3.ZERO, rot = Vector3.ZERO, uv_sc = Vector3(1, 1, 1), metal = 0.0, rough = 0.72, tint = Color.WHITE):
	var mi = MeshInstance3D.new()
	var cm = CylinderMesh.new()
	cm.top_radius = top_r
	cm.bottom_radius = bot_r
	cm.height = height
	mi.mesh = cm
	mi.material_override = PixelUI.make_3d_mat(tex_kind, uv_sc, false, metal, rough, tint)
	mi.position = pos
	mi.rotation = rot
	add_child(mi)


func _build_mesh():
	match kind:
		"wood":
			_add_box_tex(Vector3(1.45, 0.12, 0.30), "wood_deck", Vector3(0, 0.04, -0.10), Vector3.ZERO, Vector3(1.5, 1.0, 0.5))
			_add_box_tex(Vector3(1.22, 0.11, 0.28), "wood_log", Vector3(0.08, 0.09, 0.18), Vector3(0, 0.18, 0), Vector3(1.2, 1.0, 0.5))
			_add_box_tex(Vector3(0.18, 0.14, 0.58), "rope_3d", Vector3(-0.25, 0.07, 0.04), Vector3.ZERO, Vector3(1, 1, 1))
		"plastic":
			_add_cyl_tex(0.16, 0.16, 0.54, "plastic_blue", Vector3(0, 0.12, 0), Vector3(0, 0, PI / 2.0), Vector3(1, 1, 1), 0.05, 0.45)
			_add_cyl_tex(0.07, 0.07, 0.11, "rust_metal", Vector3(0.31, 0.12, 0), Vector3(0, 0, PI / 2.0), Vector3(1, 1, 1), 0.1, 0.6, Color(0.95, 0.35, 0.28))
		"scrap":
			_add_box_tex(Vector3(0.78, 0.07, 0.56), "metal_steel", Vector3(0, 0.05, 0), Vector3(0, 0, 0.08), Vector3(1, 1, 1), 0.72, 0.48)
			_add_box_tex(Vector3(0.46, 0.08, 0.36), "rust_metal", Vector3(0.16, 0.10, 0.08), Vector3(0.08, 0.45, 0), Vector3(1, 1, 1), 0.55, 0.65)
			_add_cyl_tex(0.12, 0.12, 0.15, "metal_steel", Vector3(-0.15, 0.10, -0.05), Vector3.ZERO, Vector3(1, 1, 1), 0.78, 0.42)
		"leaf":
			_add_box_tex(Vector3(1.18, 0.035, 0.26), "palm_leaf", Vector3(0, 0.05, 0), Vector3(0, 0.1, 0.06), Vector3(1, 1, 1))
			_add_box_tex(Vector3(0.98, 0.035, 0.24), "palm_leaf", Vector3(0.05, 0.06, 0.14), Vector3(0, -0.22, 0.04), Vector3(1, 1, 1), 0.0, 0.85, Color(0.9, 1.0, 0.9))
			_add_box_tex(Vector3(0.98, 0.035, 0.24), "palm_leaf", Vector3(0.05, 0.06, -0.14), Vector3(0, 0.35, -0.04), Vector3(1, 1, 1), 0.0, 0.85, Color(0.82, 0.94, 0.82))
		"barrel":
			_add_cyl_tex(0.38, 0.38, 0.86, "rust_metal", Vector3(0, 0.26, 0), Vector3.ZERO, Vector3(2, 1, 1), 0.25, 0.75)
			_add_cyl_tex(0.40, 0.40, 0.08, "metal_steel", Vector3(0, 0.52, 0), Vector3.ZERO, Vector3(1, 1, 1), 0.78, 0.45)
			_add_cyl_tex(0.40, 0.40, 0.08, "metal_steel", Vector3(0, 0.02, 0), Vector3.ZERO, Vector3(1, 1, 1), 0.78, 0.45)
		"crate":
			_add_box_tex(Vector3(0.76, 0.54, 0.76), "wood_crate", Vector3(0, 0.22, 0), Vector3.ZERO, Vector3(1, 1, 1))
			_add_box_tex(Vector3(0.80, 0.09, 0.80), "wood_log", Vector3(0, 0.45, 0), Vector3.ZERO, Vector3(1, 1, 1))
			_add_box_tex(Vector3(0.16, 0.18, 0.81), "metal_steel", Vector3(0, 0.28, 0), Vector3.ZERO, Vector3(1, 1, 1), 0.75, 0.45)


func snag_by_hook(h_node, offset = Vector3.ZERO):
	if hooked:
		return false
	hooked = true
	hook_ref = h_node
	hook_offset = offset
	collision_layer = 0
	return true


func _process(delta):
	if hooked:
		if hook_ref != null and is_instance_valid(hook_ref) and hook_ref.visible:
			var hp = hook_ref.global_position + hook_offset
			hp.y = OceanScript.height(hp.x, hp.z) + 0.06
			global_position = global_position.lerp(hp, clamp(delta * 18.0, 0.0, 1.0))
			rotation.y += delta * 3.5
		else:
			Game.collect(kind)
			queue_free()
		return
	var pos = global_position
	var drift_mul = 0.12 if Game.anchor_down else clamp(OceanScript.wave_amp * 0.85, 0.6, 1.8)
	pos.x += speed * drift_mul * delta
	pos.z += (speed * 0.18 * drift_mul + sin(OceanScript.wave_time * 0.9 + phase) * 0.22) * delta
	var h_c = OceanScript.height(pos.x, pos.z)
	var h_x = OceanScript.height(pos.x + 0.6, pos.z)
	var h_z = OceanScript.height(pos.x, pos.z + 0.6)
	pos.y = h_c + 0.02
	global_position = pos
	rotation.y += spin * delta
	rotation.x = lerp(rotation.x, clamp((h_z - h_c) * 1.1, -0.35, 0.35), delta * 6.0)
	rotation.z = lerp(rotation.z, clamp((h_c - h_x) * 1.1, -0.35, 0.35), delta * 6.0)
	if pos.x > 72.0:
		queue_free()
