extends MeshInstance3D

const SHADER = """
shader_type spatial;

uniform vec4 deep_color : source_color = vec4(0.012, 0.048, 0.125, 1.0);
uniform vec4 shallow_color : source_color = vec4(0.024, 0.105, 0.225, 1.0);
uniform vec4 trough_color : source_color = vec4(0.006, 0.026, 0.075, 1.0);
uniform vec4 foam_color : source_color = vec4(0.42, 0.54, 0.66, 1.0);
uniform float foam_strength = 0.20;
uniform float u_time = 0.0;
uniform float u_wave_amp = 1.25;

varying float v_h;
varying vec3 v_wp;

float raw_wave(vec2 p, float t) {
	float w = sin(p.x * 0.28 + t * 1.35) * 0.52;
	w += cos(p.y * 0.24 - t * 1.05) * 0.38;
	w += sin((p.x * 0.70 + p.y * 0.50) * 0.36 + t * 1.85) * 0.25;
	return w * 0.42 * u_wave_amp;
}

void vertex() {
	vec3 wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	float e = raw_wave(wp.xz, u_time);
	float ex = raw_wave(wp.xz + vec2(0.55, 0.0), u_time);
	float ez = raw_wave(wp.xz + vec2(0.0, 0.55), u_time);
	VERTEX.y += e;
	NORMAL = normalize(vec3(-(ex - e) / 0.55, 1.0, -(ez - e) / 0.55));
	v_h = e;
	v_wp = wp;
}

void fragment() {
	// Crisp pixel-art water cell quantization so water texture looks sharp and never blurry
	vec2 pix_uv = floor((v_wp.xz + vec2(u_time * 0.45, -u_time * 0.28)) * 3.5) / 3.5;
	float cell_pat = sin(pix_uv.x * 2.4 + u_time * 1.2) * cos(pix_uv.y * 2.4 - u_time * 1.0);
	float q_cell = floor((cell_pat * 0.5 + 0.5) * 4.0) / 4.0;

	float f = clamp(v_h * 1.45 + 0.48, 0.0, 1.0);
	vec3 base_col = mix(trough_color.rgb, deep_color.rgb, clamp(f * 1.3, 0.0, 1.0));
	base_col = mix(base_col, shallow_color.rgb, clamp((f - 0.35) * 1.4 + q_cell * 0.14, 0.0, 1.0));

	float crest = step(0.28 * u_wave_amp, v_h + q_cell * 0.08) * foam_strength;
	ALBEDO = mix(base_col, foam_color.rgb, crest);
	ROUGHNESS = 0.68;
	SPECULAR = 0.18;
}
"""

static var wave_time = 0.0
static var wave_amp = 1.25

var plane_mesh = null
var shader_mat = null


static func height(x, z):
	var t = wave_time
	var w = sin(x * 0.28 + t * 1.35) * 0.52
	w += cos(z * 0.24 - t * 1.05) * 0.38
	w += sin((x * 0.70 + z * 0.50) * 0.36 + t * 1.85) * 0.25
	return w * 0.42 * wave_amp


static func current_surge(t = -1.0):
	var tm = wave_time if t < 0.0 else t
	return Vector2(
		sin(tm * 0.95) * 0.34 + cos(tm * 0.48) * 0.14,
		cos(tm * 0.78) * 0.26 + sin(tm * 0.52) * 0.12
	) * wave_amp


func _ready():
	plane_mesh = PlaneMesh.new()
	plane_mesh.size = Vector2(720, 720)
	plane_mesh.subdivide_width = 130
	plane_mesh.subdivide_depth = 130
	mesh = plane_mesh
	var sh = Shader.new()
	sh.code = SHADER
	shader_mat = ShaderMaterial.new()
	shader_mat.shader = sh
	material_override = shader_mat
	cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	Game.settings_changed.connect(_apply_quality)
	_apply_quality()


func _process(delta):
	wave_time += delta
	wave_amp = clamp(float(Game.settings.get("wave_strength", 1.25)), 0.5, 2.2)
	if shader_mat != null:
		shader_mat.set_shader_parameter("u_time", wave_time)
		shader_mat.set_shader_parameter("u_wave_amp", wave_amp)


func _apply_quality():
	if plane_mesh == null or shader_mat == null:
		return
	wave_amp = clamp(float(Game.settings.get("wave_strength", 1.25)), 0.5, 2.2)
	shader_mat.set_shader_parameter("u_wave_amp", wave_amp)
	var q = int(Game.settings.get("wave_quality", 2))
	if q <= 1:
		plane_mesh.subdivide_width = 72
		plane_mesh.subdivide_depth = 72
		shader_mat.set_shader_parameter("foam_strength", 0.08)
	elif q == 2:
		plane_mesh.subdivide_width = 130
		plane_mesh.subdivide_depth = 130
		shader_mat.set_shader_parameter("foam_strength", 0.20)
	else:
		plane_mesh.subdivide_width = 180
		plane_mesh.subdivide_depth = 180
		shader_mat.set_shader_parameter("foam_strength", 0.30)
