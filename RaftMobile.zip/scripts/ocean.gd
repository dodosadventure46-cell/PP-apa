extends MeshInstance3D

const SHADER = """
shader_type spatial;

uniform vec4 deep_color : source_color = vec4(0.02, 0.24, 0.45, 1.0);
uniform vec4 shallow_color : source_color = vec4(0.12, 0.58, 0.72, 1.0);

varying float h;

float wave(vec2 p, float t) {
	float w = sin(p.x * 0.35 + t * 1.1) * 0.5;
	w += sin(p.y * 0.27 - t * 0.9) * 0.4;
	w += sin((p.x + p.y) * 0.6 + t * 1.7) * 0.2;
	return w * 0.18;
}

void vertex() {
	vec3 wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	float e = wave(wp.xz, TIME);
	float ex = wave(wp.xz + vec2(0.6, 0.0), TIME);
	float ez = wave(wp.xz + vec2(0.0, 0.6), TIME);
	VERTEX.y += e;
	NORMAL = normalize(vec3(-(ex - e) / 0.6, 1.0, -(ez - e) / 0.6));
	h = e;
}

void fragment() {
	float f = clamp(h * 2.5 + 0.5, 0.0, 1.0);
	ALBEDO = mix(deep_color.rgb, shallow_color.rgb, f);
	ROUGHNESS = 0.12;
	SPECULAR = 0.7;
}
"""


static func height(x, z):
	var t = Time.get_ticks_msec() / 1000.0
	var w = sin(x * 0.35 + t * 1.1) * 0.5
	w += sin(z * 0.27 - t * 0.9) * 0.4
	w += sin((x + z) * 0.6 + t * 1.7) * 0.2
	return w * 0.18


func _ready():
	var pm = PlaneMesh.new()
	pm.size = Vector2(700, 700)
	pm.subdivide_width = 140
	pm.subdivide_depth = 140
	mesh = pm
	var sh = Shader.new()
	sh.code = SHADER
	var m = ShaderMaterial.new()
	m.shader = sh
	material_override = m
	cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
