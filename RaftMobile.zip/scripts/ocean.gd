extends MeshInstance3D

const SHADER = """
shader_type spatial;

uniform vec4 deep_color : source_color = vec4(0.02, 0.22, 0.44, 1.0);
uniform vec4 shallow_color : source_color = vec4(0.10, 0.56, 0.72, 1.0);
uniform vec4 foam_color : source_color = vec4(0.86, 0.95, 0.99, 1.0);
uniform float foam_strength = 0.35;

varying float h;

float wave(vec2 p, float t) {
	float w = sin(p.x * 0.35 + t * 1.1) * 0.5;
	w += sin(p.y * 0.27 - t * 0.9) * 0.4;
	w += sin((p.x + p.y) * 0.6 + t * 1.7) * 0.2;
	return w * 0.18;
}

void vertex() {
	vec3 wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	float e = wave(wp.xz, TIME);
	float ex = wave(wp.xz + vec2(0.55, 0.0), TIME);
	float ez = wave(wp.xz + vec2(0.0, 0.55), TIME);
	VERTEX.y += e;
	NORMAL = normalize(vec3(-(ex - e) / 0.55, 1.0, -(ez - e) / 0.55));
	h = e;
}

void fragment() {
	float f = clamp(h * 2.6 + 0.5, 0.0, 1.0);
	vec3 col = mix(deep_color.rgb, shallow_color.rgb, f);
	float crest = smoothstep(0.11, 0.19, h) * foam_strength;
	ALBEDO = mix(col, foam_color.rgb, crest);
	ROUGHNESS = mix(0.11, 0.45, crest);
	SPECULAR = 0.75;
}
"""

var plane_mesh = null
var shader_mat = null


static func height(x, z):
	var t = Time.get_ticks_msec() / 1000.0
	var w = sin(x * 0.35 + t * 1.1) * 0.5
	w += sin(z * 0.27 - t * 0.9) * 0.4
	w += sin((x + z) * 0.6 + t * 1.7) * 0.2
	return w * 0.18


func _ready():
	plane_mesh = PlaneMesh.new()
	plane_mesh.size = Vector2(720, 720)
	plane_mesh.subdivide_width = 120
	plane_mesh.subdivide_depth = 120
	mesh = plane_mesh
	var sh = Shader.new()
	sh.code = SHADER
	shader_mat = ShaderMaterial.new()
	shader_mat.shader = sh
	material_override = shader_mat
	cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	Game.settings_changed.connect(_apply_quality)
	_apply_quality()


func _apply_quality():
	if plane_mesh == null or shader_mat == null:
		return
	var q = int(Game.settings.get("wave_quality", 2))
	if q <= 1:
		plane_mesh.subdivide_width = 64
		plane_mesh.subdivide_depth = 64
		shader_mat.set_shader_parameter("foam_strength", 0.0)
	elif q == 2:
		plane_mesh.subdivide_width = 120
		plane_mesh.subdivide_depth = 120
		shader_mat.set_shader_parameter("foam_strength", 0.32)
	else:
		plane_mesh.subdivide_width = 175
		plane_mesh.subdivide_depth = 175
		shader_mat.set_shader_parameter("foam_strength", 0.52)
