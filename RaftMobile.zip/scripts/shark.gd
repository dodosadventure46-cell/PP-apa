extends Area3D

const OceanScript = preload("res://scripts/ocean.gd")
const INVALID = Vector2i(99999, 99999)

var raft
var player
var hp = 6.0
var state = "circle"
var angle = 0.0
var radius = 9.0
var state_t = 0.0
var circle_time = 10.0
var bite_cd = 0.0
var target_cell = Vector2i(99999, 99999)
var dead = false
var speed = 5.0
var tail_pivot = null
var skin_mat = null
var hit_flash_t = 0.0
var swim_phase = 0.0


func _ready():
	add_to_group("shark")
	collision_layer = 4
	collision_mask = 0
	monitoring = false
	var cs = CollisionShape3D.new()
	var bs = BoxShape3D.new()
	bs.size = Vector3(1.7, 1.8, 3.3)
	cs.shape = bs
	cs.position = Vector3(0, 0.3, 0)
	add_child(cs)

	skin_mat = StandardMaterial3D.new()
	skin_mat.albedo_color = Color(0.32, 0.39, 0.46)
	skin_mat.roughness = 0.48

	var belly_mat = StandardMaterial3D.new()
	belly_mat.albedo_color = Color(0.78, 0.82, 0.85)
	belly_mat.roughness = 0.55

	var body = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = Vector3(0.84, 0.62, 2.2)
	body.mesh = bm
	body.material_override = skin_mat
	add_child(body)

	var belly = MeshInstance3D.new()
	var blm = BoxMesh.new()
	blm.size = Vector3(0.76, 0.22, 2.0)
	belly.mesh = blm
	belly.material_override = belly_mat
	belly.position = Vector3(0, -0.24, -0.05)
	add_child(belly)

	var snout = MeshInstance3D.new()
	var sm = PrismMesh.new()
	sm.size = Vector3(0.78, 0.75, 0.52)
	snout.mesh = sm
	snout.material_override = skin_mat
	snout.rotation.x = -PI / 2.0
	snout.position = Vector3(0, 0.02, -1.42)
	add_child(snout)

	var fin = MeshInstance3D.new()
	var pm = PrismMesh.new()
	pm.size = Vector3(0.85, 0.85, 0.12)
	fin.mesh = pm
	fin.material_override = skin_mat
	fin.rotation.y = PI / 2.0
	fin.position = Vector3(0, 0.62, 0.05)
	add_child(fin)

	for s in [-1.0, 1.0]:
		var pfin = MeshInstance3D.new()
		var pfm = BoxMesh.new()
		pfm.size = Vector3(0.65, 0.07, 0.38)
		pfin.mesh = pfm
		pfin.material_override = skin_mat
		pfin.position = Vector3(s * 0.62, -0.12, -0.35)
		pfin.rotation.z = -s * 0.22
		pfin.rotation.y = -s * 0.28
		add_child(pfin)

	tail_pivot = Node3D.new()
	tail_pivot.position = Vector3(0, 0.05, 1.1)
	add_child(tail_pivot)

	var tail_stalk = MeshInstance3D.new()
	var tsm = BoxMesh.new()
	tsm.size = Vector3(0.42, 0.38, 0.75)
	tail_stalk.mesh = tsm
	tail_stalk.material_override = skin_mat
	tail_stalk.position = Vector3(0, 0, 0.32)
	tail_pivot.add_child(tail_stalk)

	var tail_fin = MeshInstance3D.new()
	var tm = PrismMesh.new()
	tm.size = Vector3(0.55, 0.95, 0.10)
	tail_fin.mesh = tm
	tail_fin.material_override = skin_mat
	tail_fin.rotation.y = PI / 2.0
	tail_fin.rotation.x = 0.25
	tail_fin.position = Vector3(0, 0.14, 0.78)
	tail_pivot.add_child(tail_fin)

	circle_time = randf_range(8.0, 14.0)


func _move_to(goal, sp, delta):
	var pos = global_position
	var to = goal - pos
	to.y = 0.0
	var dist = to.length()
	if dist > 0.05:
		pos += to.normalized() * min(dist, sp * delta)
	pos.y = -0.34 + OceanScript.height(pos.x, pos.z)
	global_position = pos
	if dist > 0.3:
		look_at(pos + to.normalized(), Vector3.UP)
	return dist


func _process(delta):
	if dead:
		return
	bite_cd -= delta
	state_t += delta
	swim_phase += delta * (10.5 if state != "circle" else 6.8)
	if tail_pivot != null:
		tail_pivot.rotation.y = sin(swim_phase) * 0.36
	if hit_flash_t > 0.0:
		hit_flash_t -= delta
		if hit_flash_t <= 0.0 and skin_mat != null:
			skin_mat.albedo_color = Color(0.32, 0.39, 0.46)

	match state:
		"circle":
			_do_circle(delta)
		"raft":
			_do_raft(delta)
		"player":
			_do_player(delta)
		"retreat":
			_do_retreat(delta)


func _do_circle(delta):
	radius = 8.0 + sqrt(float(raft.tiles.size())) * 1.5
	var center = raft.center()
	angle += (speed * 0.6 / radius) * delta
	var goal = center + Vector3(cos(angle), 0, sin(angle)) * radius
	_move_to(goal, speed, delta)
	if player.in_water and state_t > 2.0 and not Game.dead:
		state = "player"
		state_t = 0.0
		return
	if state_t >= circle_time:
		state_t = 0.0
		target_cell = raft.nearest_edge_cell(global_position)
		if target_cell != INVALID:
			state = "raft"


func _do_raft(delta):
	if player.in_water and not Game.dead:
		state = "player"
		state_t = 0.0
		return
	if not raft.tiles.has(target_cell) or state_t > 25.0:
		state = "circle"
		state_t = circle_time - 3.0
		return
	var goal = raft.attack_point(target_cell, global_position)
	var d = _move_to(goal, speed, delta)
	if d < 0.72 and bite_cd <= 0.0:
		bite_cd = 1.5
		Game.say("Hiu menggigit pinggiran rakit! Tusuk dengan SERANG!")
		if raft.bite(target_cell):
			state = "circle"
			state_t = circle_time - 4.0


func _do_player(delta):
	if not player.in_water or Game.dead:
		state = "circle"
		state_t = circle_time - 3.0
		return
	var d = _move_to(player.global_position, speed * 1.15, delta)
	if d < 1.8 and bite_cd <= 0.0:
		bite_cd = 1.3
		Game.damage(12.0)
		Game.say("Hiu menggigitmu! Dekati rakit lalu tekan LOMPAT!")
		Game.play_sfx("bite", 0.95, 1.0)


func _do_retreat(delta):
	var center = raft.center()
	var away = global_position - center
	away.y = 0.0
	if away.length() < 0.1:
		away = Vector3(1, 0, 0)
	var goal = center + away.normalized() * 18.0
	_move_to(goal, speed * 1.3, delta)
	if state_t > 3.0:
		state = "circle"
		state_t = circle_time - 4.0


func hit(dmg):
	if dead:
		return
	hp -= dmg
	if skin_mat != null:
		skin_mat.albedo_color = Color(0.88, 0.25, 0.22)
		hit_flash_t = 0.18
	Game.play_sfx("hit", 1.0, 0.95)
	if hp <= 0.0:
		_die()
	else:
		Game.say("Kena! Hiu terluka (Sisa HP: %d) & mundur" % int(ceil(hp)))
		state = "retreat"
		state_t = 0.0


func _die():
	dead = true
	collision_layer = 0
	Game.add_item("meat", 2)
	Game.say("Hiu dikalahkan! +2 Daging Hiu")
	Game.play_sfx("pickup", 0.9, 1.0)
	var tw = create_tween()
	tw.tween_property(self, "position:y", -3.2, 1.5)
	tw.tween_callback(queue_free)
