extends Area3D

const OceanScript = preload("res://scripts/ocean.gd")
const PixelUI = preload("res://scripts/pixel_ui.gd")
const INVALID = Vector2i(99999, 99999)

var raft
var player
var hp = 6.0
var state = "circle"
var angle = 0.0
var radius = 12.0
var state_t = 0.0
var circle_time = 65.0
var bite_cd = 0.0
var target_cell = Vector2i(99999, 99999)
var dead = false
var speed = 4.6
var tail_pivot = null
var skin_mat = null
var hit_flash_t = 0.0
var swim_phase = 0.0


func _ready():
	add_to_group("shark")
	collision_layer = 4
	collision_mask = 0
	monitoring = false
	var cs = CollisionShape3D.new()
	var bs = BoxShape3D.new()
	bs.size = Vector3(1.7, 1.8, 3.3)
	cs.shape = bs
	cs.position = Vector3(0, 0.3, 0)
	add_child(cs)

	skin_mat = PixelUI.make_3d_mat("shark_skin", Vector3(2, 1, 2), false, 0.05, 0.52)
	var belly_mat = PixelUI.make_3d_mat("shark_belly", Vector3(2, 1, 2), false, 0.0, 0.60)

	var body = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = Vector3(0.84, 0.62, 2.2)
	body.mesh = bm
	body.material_override = skin_mat
	add_child(body)

	var belly = MeshInstance3D.new()
	var blm = BoxMesh.new()
	blm.size = Vector3(0.76, 0.22, 2.0)
	belly.mesh = blm
	belly.material_override = belly_mat
	belly.position = Vector3(0, -0.24, -0.05)
	add_child(belly)

	var snout = MeshInstance3D.new()
	var sm = PrismMesh.new()
	sm.size = Vector3(0.78, 0.75, 0.52)
	snout.mesh = sm
	snout.material_override = skin_mat
	snout.rotation.x = -PI / 2.0
	snout.position = Vector3(0, 0.02, -1.42)
	add_child(snout)

	var fin = MeshInstance3D.new()
	var pm = PrismMesh.new()
	pm.size = Vector3(0.85, 0.85, 0.12)
	fin.mesh = pm
	fin.material_override = skin_mat
	fin.rotation.y = PI / 2.0
	fin.position = Vector3(0, 0.62, 0.05)
	add_child(fin)

	for s in [-1.0, 1.0]:
		var pfin = MeshInstance3D.new()
		var pfm = BoxMesh.new()
		pfm.size = Vector3(0.65, 0.07, 0.38)
		pfin.mesh = pfm
		pfin.material_override = skin_mat
		pfin.position = Vector3(s * 0.62, -0.12, -0.35)
		pfin.rotation.z = -s * 0.22
		pfin.rotation.y = -s * 0.28
		add_child(pfin)

	tail_pivot = Node3D.new()
	tail_pivot.position = Vector3(0, 0.05, 1.1)
	add_child(tail_pivot)

	var tail_stalk = MeshInstance3D.new()
	var tsm = BoxMesh.new()
	tsm.size = Vector3(0.42, 0.38, 0.75)
	tail_stalk.mesh = tsm
	tail_stalk.material_override = skin_mat
	tail_stalk.position = Vector3(0, 0, 0.32)
	tail_pivot.add_child(tail_stalk)

	var tail_fin = MeshInstance3D.new()
	var tm = PrismMesh.new()
	tm.size = Vector3(0.55, 0.95, 0.10)
	tail_fin.mesh = tm
	tail_fin.material_override = skin_mat
	tail_fin.rotation.y = PI / 2.0
	tail_fin.rotation.x = 0.25
	tail_fin.position = Vector3(0, 0.14, 0.78)
	tail_pivot.add_child(tail_fin)

	# Point #4: Long 55-85s patrol interval so the shark isn't constantly attacking!
	circle_time = randf_range(55.0, 85.0)


func _move_to(goal, sp, delta):
	var pos = global_position
	var to = goal - pos
	to.y = 0.0
	var dist = to.length()
	if dist > 0.05:
		pos += to.normalized() * min(dist, sp * delta)
	pos.y = -0.34 + OceanScript.height(pos.x, pos.z)
	global_position = pos
	if dist > 0.3:
		look_at(pos + to.normalized(), Vector3.UP)
	return dist


func _process(delta):
	if dead or Game.menu_open or not Game.in_world:
		return
	bite_cd -= delta
	state_t += delta
	swim_phase += delta * (10.5 if state != "circle" else 6.8)
	if tail_pivot != null:
		tail_pivot.rotation.y = sin(swim_phase) * 0.36
	if hit_flash_t > 0.0:
		hit_flash_t -= delta
		if hit_flash_t <= 0.0 and skin_mat != null:
			skin_mat.albedo_color = Color.WHITE

	# F10: If Shark Bait is active in the water, the shark swims to the bait instead of attacking!
	if Game.bait_timer > 0.0:
		_move_to(Game.bait_pos, speed, delta)
		state = "circle"
		state_t = 0.0
		return

	match state:
		"circle":
			_do_circle(delta)
		"raft":
			_do_raft(delta)
		"player":
			_do_player(delta)
		"retreat":
			_do_retreat(delta)


func _do_circle(delta):
	radius = 11.5 + sqrt(float(raft.tiles.size())) * 1.6
	var center = raft.center()
	angle += (speed * 0.52 / radius) * delta
	var goal = center + Vector3(cos(angle), 0, sin(angle)) * radius
	_move_to(goal, speed, delta)
	if player.in_water and state_t > 6.0 and not Game.dead:
		state = "player"
		state_t = 0.0
		return
	if state_t >= circle_time:
		state_t = 0.0
		circle_time = randf_range(55.0, 85.0)
		target_cell = raft.nearest_edge_cell(global_position)
		if target_cell != INVALID:
			state = "raft"


func _do_raft(delta):
	if player.in_water and not Game.dead:
		state = "player"
		state_t = 0.0
		return
	if not raft.tiles.has(target_cell) or state_t > 20.0:
		state = "circle"
		state_t = 0.0
		circle_time = randf_range(55.0, 85.0)
		return
	var goal = raft.attack_point(target_cell, global_position)
	var d = _move_to(goal, speed, delta)
	if d < 0.75 and bite_cd <= 0.0:
		bite_cd = 2.6
		Game.say("Hiu menggigit pinggiran rakit! Tusuk dengan SERANG / PANAH!")
		if raft.bite(target_cell):
			# Point #4: Reset state_t to 0.0 so shark leaves for a full minute after destroying a tile!
			state = "circle"
			state_t = 0.0
			circle_time = randf_range(60.0, 90.0)


func _do_player(delta):
	if not player.in_water or Game.dead:
		state = "circle"
		state_t = 0.0
		return
	var d = _move_to(player.global_position, speed * 1.08, delta)
	if d < 1.3 and bite_cd <= 0.0:
		bite_cd = 1.8
		Game.damage(18.0)
		Game.say("Kamu digigit hiu di air! Cepat naik ke rakit!")
		Game.play_sfx("bite", 0.9, 1.0)


func _do_retreat(delta):
	var center = raft.center()
	var away = global_position - center
	away.y = 0.0
	if away.length() < 0.1:
		away = Vector3(1, 0, 0)
	else:
		away = away.normalized()
	_move_to(center + away * (radius + 10.0), speed * 1.45, delta)
	if state_t > 7.5:
		# Point #4: Reset state_t = 0.0 and set a fresh 55-85s cooldown so shark does NOT immediately return!
		state = "circle"
		state_t = 0.0
		circle_time = randf_range(55.0, 85.0)


func hit(dmg):
	if dead:
		return
	hp -= dmg
	if skin_mat != null:
		skin_mat.albedo_color = Color(1.0, 0.35, 0.30)
		hit_flash_t = 0.18
	Game.play_sfx("hit", 1.0, 0.95)
	if hp <= 0.0:
		dead = true
		Game.add_item("meat", 2)
		Game.say("Hiu dikalahkan! +2 Daging Hiu masuk ke Tas")
		queue_free()
	else:
		state = "retreat"
		state_t = 0.0
		Game.say("Hiu terluka dan kabur menjauh selama ~1 menit!")
