extends Area3D

const OceanScript = preload("res://scripts/ocean.gd")
const INVALID = Vector2i(99999, 99999)

var raft
var player
var hp = 6.0
var state = "circle"
var angle = 0.0
var radius = 9.0
var state_t = 0.0
var circle_time = 10.0
var bite_cd = 0.0
var target_cell = Vector2i(99999, 99999)
var dead = false
var speed = 5.0


func _ready():
	add_to_group("shark")
	collision_layer = 4
	collision_mask = 0
	monitoring = false
	var cs = CollisionShape3D.new()
	var bs = BoxShape3D.new()
	bs.size = Vector3(1.6, 1.8, 3.2)
	cs.shape = bs
	cs.position = Vector3(0, 0.3, 0)
	add_child(cs)
	var skin = StandardMaterial3D.new()
	skin.albedo_color = Color(0.34, 0.4, 0.46)
	skin.roughness = 0.6
	var body = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = Vector3(0.8, 0.6, 2.8)
	body.mesh = bm
	body.material_override = skin
	add_child(body)
	var fin = MeshInstance3D.new()
	var pm = PrismMesh.new()
	pm.size = Vector3(0.8, 0.8, 0.12)
	fin.mesh = pm
	fin.material_override = skin
	fin.rotation.y = PI / 2.0
	fin.position = Vector3(0, 0.6, 0.1)
	add_child(fin)
	var tail = MeshInstance3D.new()
	var tm = BoxMesh.new()
	tm.size = Vector3(0.1, 0.8, 0.5)
	tail.mesh = tm
	tail.material_override = skin
	tail.position = Vector3(0, 0.15, 1.5)
	add_child(tail)
	circle_time = randf_range(8.0, 14.0)


func _move_to(goal, sp, delta):
	var pos = global_position
	var to = goal - pos
	to.y = 0.0
	var dist = to.length()
	if dist > 0.05:
		pos += to.normalized() * min(dist, sp * delta)
	pos.y = -0.35 + OceanScript.height(pos.x, pos.z)
	global_position = pos
	if dist > 0.3:
		look_at(pos + to.normalized(), Vector3.UP)
	return dist


func _process(delta):
	if dead:
		return
	bite_cd -= delta
	state_t += delta
	match state:
		"circle":
			_do_circle(delta)
		"raft":
			_do_raft(delta)
		"player":
			_do_player(delta)
		"retreat":
			_do_retreat(delta)


func _do_circle(delta):
	radius = 8.0 + sqrt(float(raft.tiles.size())) * 1.5
	var center = raft.center()
	angle += (speed * 0.6 / radius) * delta
	var goal = center + Vector3(cos(angle), 0, sin(angle)) * radius
	_move_to(goal, speed, delta)
	if player.in_water and state_t > 2.0 and not Game.dead:
		state = "player"
		state_t = 0.0
		return
	if state_t >= circle_time:
		state_t = 0.0
		target_cell = raft.nearest_edge_cell(global_position)
		if target_cell != INVALID:
			state = "raft"


func _do_raft(delta):
	if player.in_water and not Game.dead:
		state = "player"
		state_t = 0.0
		return
	if not raft.tiles.has(target_cell) or state_t > 25.0:
		state = "circle"
		state_t = circle_time - 3.0
		return
	var goal = raft.attack_point(target_cell, global_position)
	var d = _move_to(goal, speed, delta)
	if d < 0.7 and bite_cd <= 0.0:
		bite_cd = 1.5
		Game.say("Hiu menggigit rakit!")
		if raft.bite(target_cell):
			state = "circle"
			state_t = circle_time - 4.0


func _do_player(delta):
	if not player.in_water or Game.dead:
		state = "circle"
		state_t = circle_time - 3.0
		return
	var d = _move_to(player.global_position, speed * 1.15, delta)
	if d < 1.8 and bite_cd <= 0.0:
		bite_cd = 1.3
		Game.damage(12.0)
		Game.say("Hiu menggigit kamu! Naik ke rakit (LOMPAT)!")


func _do_retreat(delta):
	var center = raft.center()
	var away = global_position - center
	away.y = 0.0
	if away.length() < 0.1:
		away = Vector3(1, 0, 0)
	var goal = center + away.normalized() * 18.0
	_move_to(goal, speed * 1.3, delta)
	if state_t > 3.0:
		state = "circle"
		state_t = circle_time - 4.0


func hit(dmg):
	if dead:
		return
	hp -= dmg
	if hp <= 0.0:
		_die()
	else:
		Game.say("Kena! Hiu mundur")
		state = "retreat"
		state_t = 0.0


func _die():
	dead = true
	collision_layer = 0
	Game.add_item("meat", 2)
	Game.say("Hiu kalah! +2 Daging Hiu")
	var tw = create_tween()
	tw.tween_property(self, "position:y", -3.0, 1.5)
	tw.tween_callback(queue_free)
