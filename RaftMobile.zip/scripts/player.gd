extends CharacterBody3D

const OceanScript = preload("res://scripts/ocean.gd")
const PixelUI = preload("res://scripts/pixel_ui.gd")

enum HookState { IDLE, CHARGING, FLYING, REELING }

var raft
var move_input = Vector2.ZERO
var look_delta = Vector2.ZERO
var jump_held = false
var yaw = 0.0
var pitch = 0.0
var head
var cam
var tool_root
var hook_hand_mesh
var hook_claw_hand
var spear_mesh
var rod_mesh
var bobber_node
var splash_ring
var splash_timer = 0.0

var hook_state = HookState.IDLE
var hook_charge = 0.0
var hook_cd = 0.0
var hook_proj
var hook_vel = Vector3.ZERO
var hook_land_wait = 0.0
var hook_state_elapsed = 0.0
var reel_boost = false
var snagged_items = []
var rope_segments = []

var in_water = false
var fishing = false
var fish_timer = 0.0
var atk_cd = 0.0
var bob_time = 0.0

var mat_wood
var mat_steel
var mat_rope
var mat_splash

const SPEED = 4.3
const SWIM_SPEED = 2.75
const GRAVITY = 16.0
const HOOK_GRAVITY = 21.5
const MAX_HOOK_DIST = 29.0
const JUMP = 5.6
const BASE_SENS = 0.0045
const SPEAR_HOME = Vector3(0.36, -0.30, -0.78)
const HOOK_HOME = Vector3(0.33, -0.26, -0.58)
const ROD_HOME = Vector3(0.34, -0.28, -0.72)
const ROPE_COUNT = 14


func _ready():
	collision_layer = 16
	collision_mask = 1
	floor_snap_length = 0.45
	var cs = CollisionShape3D.new()
	var cap = CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.7
	cs.shape = cap
	cs.position = Vector3(0, 0.85, 0)
	add_child(cs)

	head = Node3D.new()
	head.position = Vector3(0, 1.56, 0)
	add_child(head)

	cam = Camera3D.new()
	cam.fov = 75.0
	cam.near = 0.05
	cam.far = 650.0
	head.add_child(cam)
	cam.current = true

	tool_root = Node3D.new()
	cam.add_child(tool_root)

	_init_materials()
	_make_hook_hand()
	_make_spear()
	_make_rod()

	Game.settings_changed.connect(_apply_camera_settings)
	_apply_camera_settings()


func setup_world_fx(world_parent):
	hook_proj = Node3D.new()
	hook_proj.visible = false
	world_parent.add_child(hook_proj)
	_build_claw_head(hook_proj, 1.55)

	for i in range(ROPE_COUNT):
		var seg = MeshInstance3D.new()
		var bm = BoxMesh.new()
		bm.size = Vector3(0.024, 0.024, 1.0)
		seg.mesh = bm
		seg.material_override = mat_rope
		seg.visible = false
		world_parent.add_child(seg)
		rope_segments.append(seg)

	splash_ring = MeshInstance3D.new()
	var sc = CylinderMesh.new()
	sc.top_radius = 0.55
	sc.bottom_radius = 0.45
	sc.height = 0.06
	splash_ring.mesh = sc
	splash_ring.material_override = mat_splash
	splash_ring.visible = false
	world_parent.add_child(splash_ring)

	bobber_node = Node3D.new()
	bobber_node.visible = false
	var b_red = MeshInstance3D.new()
	var bs = SphereMesh.new()
	bs.radius = 0.14
	bs.height = 0.28
	b_red.mesh = bs
	b_red.material_override = PixelUI.make_3d_mat("rust_metal", Vector3(1, 1, 1), false, 0.1, 0.5, Color(0.95, 0.22, 0.20))
	bobber_node.add_child(b_red)
	world_parent.add_child(bobber_node)


func _apply_camera_settings():
	if cam == null:
		return
	cam.fov = clamp(float(Game.settings.get("fov", 75.0)), 60.0, 98.0)
	var vd = int(Game.settings.get("view_dist", 1))
	if vd <= 0:
		cam.far = 360.0
	elif vd == 1:
		cam.far = 650.0
	else:
		cam.far = 1000.0


func _init_materials():
	mat_wood = PixelUI.make_3d_mat("wood_log", Vector3(1, 2, 1), false, 0.0, 0.85)
	mat_steel = PixelUI.make_3d_mat("metal_steel", Vector3(1, 1, 1), false, 0.78, 0.35)
	mat_rope = PixelUI.make_3d_mat("rope_3d", Vector3(1, 2, 1), false, 0.0, 0.90)

	mat_splash = StandardMaterial3D.new()
	mat_splash.albedo_color = Color(0.75, 0.88, 0.96, 0.72)
	mat_splash.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat_splash.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED


func _build_claw_head(parent_node, scale_mul = 1.0):
	var stem = MeshInstance3D.new()
	var sc = CylinderMesh.new()
	sc.top_radius = 0.018 * scale_mul
	sc.bottom_radius = 0.022 * scale_mul
	sc.height = 0.28 * scale_mul
	stem.mesh = sc
	stem.material_override = mat_steel
	stem.rotation.x = PI / 2.0
	parent_node.add_child(stem)

	var ring = MeshInstance3D.new()
	var rc = CylinderMesh.new()
	rc.top_radius = 0.036 * scale_mul
	rc.bottom_radius = 0.036 * scale_mul
	rc.height = 0.018 * scale_mul
	ring.mesh = rc
	ring.material_override = mat_rope
	ring.position = Vector3(0, 0, 0.15 * scale_mul)
	parent_node.add_child(ring)

	for i in range(3):
		var prong_pivot = Node3D.new()
		prong_pivot.position = Vector3(0, 0, -0.13 * scale_mul)
		prong_pivot.rotation.z = float(i) * TAU / 3.0
		parent_node.add_child(prong_pivot)

		var arm1 = MeshInstance3D.new()
		var bm1 = BoxMesh.new()
		bm1.size = Vector3(0.022 * scale_mul, 0.13 * scale_mul, 0.028 * scale_mul)
		arm1.mesh = bm1
		arm1.material_override = mat_steel
		arm1.position = Vector3(0, 0.06 * scale_mul, 0.02 * scale_mul)
		arm1.rotation.x = -0.45
		prong_pivot.add_child(arm1)

		var barb = MeshInstance3D.new()
		var cm2 = CylinderMesh.new()
		cm2.top_radius = 0.0
		cm2.bottom_radius = 0.022 * scale_mul
		cm2.height = 0.10 * scale_mul
		barb.mesh = cm2
		barb.material_override = mat_steel
		barb.position = Vector3(0, 0.11 * scale_mul, 0.07 * scale_mul)
		barb.rotation.x = 0.85
		prong_pivot.add_child(barb)


func _make_hook_hand():
	hook_hand_mesh = Node3D.new()
	hook_hand_mesh.position = HOOK_HOME
	tool_root.add_child(hook_hand_mesh)

	var handle = MeshInstance3D.new()
	var hc = CylinderMesh.new()
	hc.top_radius = 0.032
	hc.bottom_radius = 0.032
	hc.height = 0.24
	handle.mesh = hc
	handle.material_override = mat_wood
	handle.position = Vector3(0, -0.05, 0.08)
	hook_hand_mesh.add_child(handle)

	for i in range(3):
		var coil = MeshInstance3D.new()
		var cc = CylinderMesh.new()
		cc.top_radius = 0.048
		cc.bottom_radius = 0.048
		cc.height = 0.025
		coil.mesh = cc
		coil.material_override = mat_rope
		coil.position = Vector3(0, -0.09 + i * 0.032, 0.08)
		hook_hand_mesh.add_child(coil)

	hook_claw_hand = Node3D.new()
	hook_claw_hand.position = Vector3(0, 0.03, -0.10)
	hook_hand_mesh.add_child(hook_claw_hand)
	_build_claw_head(hook_claw_hand, 1.0)


func _make_spear():
	spear_mesh = Node3D.new()
	spear_mesh.position = SPEAR_HOME
	spear_mesh.rotation = Vector3(0.0, deg_to_rad(5.0), 0.0)
	tool_root.add_child(spear_mesh)

	var shaft = MeshInstance3D.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 0.019
	cm.bottom_radius = 0.019
	cm.height = 1.45
	shaft.mesh = cm
	shaft.material_override = mat_wood
	shaft.rotation.x = PI / 2.0
	spear_mesh.add_child(shaft)

	var grip = MeshInstance3D.new()
	var gm = CylinderMesh.new()
	gm.top_radius = 0.023
	gm.bottom_radius = 0.023
	gm.height = 0.28
	grip.mesh = gm
	grip.material_override = mat_rope
	grip.rotation.x = PI / 2.0
	grip.position = Vector3(0, 0, -0.15)
	spear_mesh.add_child(grip)

	var tip = MeshInstance3D.new()
	var tm = CylinderMesh.new()
	tm.top_radius = 0.0
	tm.bottom_radius = 0.046
	tm.height = 0.24
	tip.mesh = tm
	tip.material_override = mat_steel
	tip.rotation.x = -PI / 2.0
	tip.position = Vector3(0, 0, -0.82)
	spear_mesh.add_child(tip)
	spear_mesh.visible = false


func _make_rod():
	rod_mesh = Node3D.new()
	rod_mesh.position = ROD_HOME
	rod_mesh.rotation = Vector3(deg_to_rad(18.0), deg_to_rad(6.0), 0.0)
	tool_root.add_child(rod_mesh)

	var pole = MeshInstance3D.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 0.008
	cm.bottom_radius = 0.022
	cm.height = 1.65
	pole.mesh = cm
	pole.material_override = mat_wood
	pole.rotation.x = PI / 2.0
	pole.position = Vector3(0, 0, -0.45)
	rod_mesh.add_child(pole)

	var reel_box = MeshInstance3D.new()
	var rm = CylinderMesh.new()
	rm.top_radius = 0.038
	rm.bottom_radius = 0.038
	rm.height = 0.04
	reel_box.mesh = rm
	reel_box.material_override = mat_steel
	reel_box.rotation.z = PI / 2.0
	reel_box.position = Vector3(0.03, -0.03, -0.1)
	rod_mesh.add_child(reel_box)
	rod_mesh.visible = false


func _spawn_splash(pos):
	if splash_ring == null:
		return
	splash_ring.global_position = Vector3(pos.x, OceanScript.height(pos.x, pos.z) + 0.05, pos.z)
	splash_ring.scale = Vector3(0.4, 1.0, 0.4)
	splash_ring.visible = true
	splash_timer = 0.42


func get_aim_target_text():
	var r_debris = _ray(2, 29.0)
	if not r_debris.is_empty() and r_debris["collider"] != null:
		var c = r_debris["collider"]
		var d = int(global_position.distance_to(c.global_position))
		var nm = Game.ITEM_NAMES.get(c.kind, "Barang Apung")
		if c.kind == "barrel":
			nm = "Tong Apung"
		elif c.kind == "crate":
			nm = "Peti Laut"
		return {"text": "%s (%dm)" % [nm, d], "type": "debris"}
	var r_shark = _ray(4, 14.0)
	if not r_shark.is_empty() and r_shark["collider"] != null:
		return {"text": "HIU PEMANGSA! (SERANG)", "type": "shark"}
	return {"text": "", "type": "none"}


func _process(delta):
	if Game.dead or not Game.in_world:
		hook_hand_mesh.visible = false
		spear_mesh.visible = false
		rod_mesh.visible = false
		_reset_hook()
		return

	if splash_timer > 0.0 and splash_ring != null:
		splash_timer -= delta
		var p = 1.0 - (splash_timer / 0.42)
		var sc = lerp(0.4, 2.2, p)
		splash_ring.scale = Vector3(sc, 1.0, sc)
		if splash_timer <= 0.0:
			splash_ring.visible = false

	bob_time += delta * (6.5 if velocity.length() > 0.5 else 1.8)
	var bob_y = sin(bob_time) * (0.016 if velocity.length() > 0.5 else 0.005)
	var bob_x = cos(bob_time * 0.5) * (0.012 if velocity.length() > 0.5 else 0.003)
	tool_root.position = Vector3(bob_x, bob_y, 0.0)

	var held_item = Game.get_selected_item_id()
	rod_mesh.visible = fishing or (held_item == "rod" and not fishing)
	spear_mesh.visible = (not fishing) and ((Game.has_spear and atk_cd > 0.05) or held_item == "spear")
	hook_hand_mesh.visible = (not fishing) and (held_item != "spear") and (held_item != "rod")
	if hook_claw_hand != null:
		hook_claw_hand.visible = (hook_state == HookState.IDLE or hook_state == HookState.CHARGING)

	if hook_state == HookState.CHARGING:
		hook_charge = min(1.0, hook_charge + delta / 0.78)
		hook_hand_mesh.position = HOOK_HOME + Vector3(0.04, 0.08 * hook_charge, 0.14 * hook_charge)
		hook_hand_mesh.rotation.x = deg_to_rad(24.0 * hook_charge)
	elif hook_state == HookState.IDLE:
		hook_hand_mesh.position = hook_hand_mesh.position.lerp(HOOK_HOME, clamp(delta * 12.0, 0.0, 1.0))
		hook_hand_mesh.rotation.x = lerp(hook_hand_mesh.rotation.x, 0.0, clamp(delta * 12.0, 0.0, 1.0))

	if fishing:
		if move_input.length() > 0.5 or in_water or Game.dead:
			fishing = false
			if bobber_node != null:
				bobber_node.visible = false
			Game.say("Memancing dibatalkan karena bergerak")
			return
		if bobber_node != null:
			bobber_node.visible = true
			var fwd = -cam.global_transform.basis.z
			fwd.y = 0.0
			if fwd.length() < 0.1:
				fwd = Vector3(0, 0, -1)
			var bp = global_position + fwd.normalized() * 5.2
			bp.y = OceanScript.height(bp.x, bp.z) + sin(Time.get_ticks_msec() * 0.008) * 0.06
			bobber_node.global_position = bp
		fish_timer -= delta
		if fish_timer <= 0.0:
			fishing = false
			if bobber_node != null:
				bobber_node.visible = false
			Game.catch_fish()
	elif bobber_node != null:
		bobber_node.visible = false

	_update_rope_visual()


func _physics_process(delta):
	atk_cd = max(0.0, atk_cd - delta)
	hook_cd = max(0.0, hook_cd - delta)
	var active = (not Game.dead) and (not Game.menu_open) and Game.in_world
	if active:
		var sens = BASE_SENS * float(Game.settings.get("sens", 1.0))
		var inv_y = -1.0 if bool(Game.settings.get("invert_y", false)) else 1.0
		yaw -= look_delta.x * sens
		pitch = clamp(pitch - look_delta.y * sens * inv_y, -1.45, 1.45)
	look_delta = Vector2.ZERO
	rotation.y = yaw

	# Couple camera horizon roll & pitch slightly to the raft's wave rocking so the player feels the ocean swell
	var raft_roll_sway = 0.0
	var raft_pitch_sway = 0.0
	if raft != null and not in_water:
		raft_roll_sway = raft.rotation.z * 0.42
		raft_pitch_sway = raft.rotation.x * 0.35
	head.rotation.x = clamp(pitch + raft_pitch_sway, -1.48, 1.48)
	head.rotation.z = lerp(head.rotation.z, raft_roll_sway, clamp(delta * 8.0, 0.0, 1.0))

	var inp = Vector2.ZERO
	if active:
		inp = move_input
	var dir = transform.basis * Vector3(inp.x, 0.0, inp.y)
	dir.y = 0.0

	var water_surf = OceanScript.height(global_position.x, global_position.z)
	var on_raft_tile = false
	var deck_y = 0.25
	if raft != null:
		on_raft_tile = raft.is_point_over_raft(global_position.x, global_position.z)
		deck_y = raft.get_deck_height_at(global_position.x, global_position.z)

	in_water = (not on_raft_tile) and (global_position.y < water_surf - 0.15)
	if in_water:
		velocity.x = dir.x * SWIM_SPEED
		velocity.z = dir.z * SWIM_SPEED
		velocity.y = ((water_surf - 0.85) - global_position.y) * 3.8
		if active and jump_held:
			_try_climb()
		move_and_slide()
	else:
		# Carry player with raft's horizontal current drift
		if raft != null and on_raft_tile:
			global_position.x += raft.frame_motion.x
			global_position.z += raft.frame_motion.z
		velocity.x = dir.x * SPEED
		velocity.z = dir.z * SPEED
		if not is_on_floor() and not (on_raft_tile and global_position.y <= deck_y + 0.22 and velocity.y <= 0.1):
			velocity.y -= GRAVITY * delta
		elif active and jump_held:
			velocity.y = JUMP
			Game.play_sfx("ui", 0.7, 0.5)
		else:
			velocity.y = 0.0
		move_and_slide()
		# Keep player smoothly riding the pitching/rolling raft deck height when standing on the raft
		if raft != null and on_raft_tile and velocity.y <= 0.05 and global_position.y <= deck_y + 0.38:
			global_position.y = lerp(global_position.y, deck_y, clamp(delta * 18.0, 0.0, 1.0))

	_update_hook_physics(delta)


func _flat_dist_to_player(pos):
	return Vector2(pos.x - global_position.x, pos.z - global_position.z).length()


func _update_hook_physics(delta):
	if hook_proj == null:
		return

	if hook_state == HookState.FLYING:
		hook_proj.visible = true
		hook_state_elapsed += delta
		hook_vel.y -= HOOK_GRAVITY * delta

		var flat_from_p = Vector2(hook_proj.global_position.x - global_position.x, hook_proj.global_position.z - global_position.z)
		if flat_from_p.length() >= MAX_HOOK_DIST:
			var out_dir = flat_from_p.normalized()
			var horiz_v = Vector2(hook_vel.x, hook_vel.z)
			if horiz_v.dot(out_dir) > 0.0:
				hook_vel.x = 0.0
				hook_vel.z = 0.0

		hook_proj.global_position += hook_vel * delta
		if hook_vel.length() > 0.25:
			var vel_dir = hook_vel.normalized()
			if abs(vel_dir.y) < 0.96:
				hook_proj.look_at(hook_proj.global_position + vel_dir, Vector3.UP)

		_check_hook_snag()
		var water_y = OceanScript.height(hook_proj.global_position.x, hook_proj.global_position.z)
		if hook_proj.global_position.y <= water_y + 0.06 or hook_state_elapsed > 3.5:
			hook_proj.global_position.y = water_y + 0.06
			hook_vel = Vector3.ZERO
			hook_state = HookState.REELING
			hook_state_elapsed = 0.0
			hook_land_wait = 0.10
			_spawn_splash(hook_proj.global_position)
			Game.play_sfx("splash", 1.0, 0.9)

	elif hook_state == HookState.REELING:
		hook_proj.visible = true
		hook_state_elapsed += delta
		if hook_land_wait > 0.0:
			hook_land_wait -= delta

		var water_y = OceanScript.height(hook_proj.global_position.x, hook_proj.global_position.z)
		if hook_proj.global_position.y > water_y + 0.12:
			hook_vel.y = max(hook_vel.y - HOOK_GRAVITY * delta, -18.0)
			hook_proj.global_position.y = max(water_y + 0.06, hook_proj.global_position.y + hook_vel.y * delta)
		else:
			hook_proj.global_position.y = water_y + 0.06

		_check_hook_snag()

		var auto_r = bool(Game.settings.get("auto_reel", true))
		var should_pull = auto_r or reel_boost
		var to_p = global_position - hook_proj.global_position
		var flat_to = Vector3(to_p.x, 0.0, to_p.z)
		var dist_before = flat_to.length()

		if dist_before > 0.35:
			var back_dir = -flat_to.normalized()
			if abs(back_dir.y) < 0.95:
				hook_proj.look_at(hook_proj.global_position + back_dir, Vector3.UP)

		if should_pull and hook_land_wait <= 0.0 and dist_before > 0.05:
			var pull_spd = 18.0 if reel_boost else 12.8
			if snagged_items.size() > 0:
				pull_spd *= 0.90
			var step = min(dist_before, pull_spd * delta)
			hook_proj.global_position += flat_to.normalized() * step
			if hook_proj.global_position.y <= water_y + 0.12:
				hook_proj.global_position.y = OceanScript.height(hook_proj.global_position.x, hook_proj.global_position.z) + 0.06
			Game.play_reel_tick()

		var dist_after = _flat_dist_to_player(hook_proj.global_position)
		if dist_after <= 2.15 or (should_pull and hook_state_elapsed > 3.2) or hook_state_elapsed > 8.0:
			_finish_hook_reel()


func _check_hook_snag():
	if snagged_items.size() >= 3:
		return
	var hp = hook_proj.global_position
	for d in get_tree().get_nodes_in_group("debris"):
		if d == null or not is_instance_valid(d) or d.hooked:
			continue
		var d_flat = Vector2(hp.x - d.global_position.x, hp.z - d.global_position.z).length()
		if d_flat <= 1.85 and abs(hp.y - d.global_position.y) <= 1.85:
			var off = Vector3(randf_range(-0.22, 0.22), 0.0, randf_range(-0.22, 0.22))
			if d.snag_by_hook(hook_proj, off):
				snagged_items.append(d)
				_spawn_splash(d.global_position)
				if hook_state == HookState.FLYING:
					hook_state = HookState.REELING
					hook_state_elapsed = 0.0
					hook_land_wait = 0.06
				Game.play_sfx("snag", 1.0, 0.95)


func _finish_hook_reel():
	var items_to_collect = snagged_items.duplicate()
	snagged_items.clear()
	_reset_hook()
	hook_cd = 0.45

	var collected_count = 0
	for d in items_to_collect:
		if d != null and is_instance_valid(d):
			var k = d.kind
			d.queue_free()
			Game.collect(k)
			collected_count += 1
	if collected_count == 0:
		Game.play_sfx("ui", 0.9, 0.4)


func _reset_hook():
	hook_state = HookState.IDLE
	hook_charge = 0.0
	hook_vel = Vector3.ZERO
	hook_land_wait = 0.0
	hook_state_elapsed = 0.0
	reel_boost = false
	if hook_proj != null:
		hook_proj.visible = false
	for seg in rope_segments:
		if seg != null:
			seg.visible = false


func _update_rope_visual():
	if hook_state != HookState.FLYING and hook_state != HookState.REELING:
		for seg in rope_segments:
			if seg != null:
				seg.visible = false
		return
	if hook_proj == null or rope_segments.is_empty():
		return
	var p0 = hook_hand_mesh.global_position + Vector3(0, 0.02, -0.05)
	var p2 = hook_proj.global_position
	var dist = p0.distance_to(p2)
	if dist < 0.15:
		for seg in rope_segments:
			if seg != null:
				seg.visible = false
		return
	var sag = clamp(dist * 0.07, 0.04, 1.2) if hook_state == HookState.FLYING else clamp(dist * 0.015, 0.0, 0.22)
	var p1 = (p0 + p2) * 0.5 - Vector3(0, sag, 0)
	var n = rope_segments.size()
	for i in range(n):
		var t0 = float(i) / float(n)
		var t1 = float(i + 1) / float(n)
		var a = (1.0 - t0) * (1.0 - t0) * p0 + 2.0 * (1.0 - t0) * t0 * p1 + t0 * t0 * p2
		var b = (1.0 - t1) * (1.0 - t1) * p0 + 2.0 * (1.0 - t1) * t1 * p1 + t1 * t1 * p2
		var seg = rope_segments[i]
		var seg_len = a.distance_to(b)
		if seg_len < 0.01:
			seg.visible = false
			continue
		seg.visible = true
		seg.scale = Vector3.ONE
		seg.global_position = (a + b) * 0.5
		var dir = (b - a).normalized()
		var up = Vector3.UP if abs(dir.y) < 0.95 else Vector3.RIGHT
		seg.look_at(b, up)
		seg.scale = Vector3(1.0, 1.0, seg_len + 0.02)


func start_hook_action():
	if Game.dead or Game.menu_open or not Game.in_world:
		return
	if fishing:
		fishing = false
	if hook_state == HookState.IDLE:
		if hook_cd > 0.0:
			return
		for d in get_tree().get_nodes_in_group("debris"):
			if d != null and is_instance_valid(d) and not d.hooked:
				if d.global_position.distance_to(global_position) <= 2.4:
					var k = d.kind
					d.queue_free()
					Game.collect(k)
					return
		if bool(Game.settings.get("hook_charge_mode", true)):
			hook_state = HookState.CHARGING
			hook_charge = 0.30
		else:
			hook_charge = 0.85
			_launch_hook()
	elif hook_state == HookState.FLYING or hook_state == HookState.REELING:
		reel_boost = true
		if hook_state == HookState.FLYING:
			hook_state = HookState.REELING
			hook_state_elapsed = 0.0
			hook_land_wait = 0.0
		elif _flat_dist_to_player(hook_proj.global_position) <= 3.0:
			_finish_hook_reel()


func release_hook_action():
	reel_boost = false
	if hook_state == HookState.CHARGING:
		_launch_hook()


func _launch_hook():
	if hook_proj == null:
		_reset_hook()
		return
	var pwr = clamp(hook_charge, 0.38, 1.0)
	hook_state = HookState.FLYING
	hook_state_elapsed = 0.0
	snagged_items.clear()
	var aim_dir = -cam.global_transform.basis.z
	var launch_dir = (aim_dir + Vector3(0, 0.25, 0)).normalized()
	var spd = lerp(14.0, 23.5, pwr)
	hook_proj.global_position = cam.global_position + aim_dir * 0.70 + Vector3(0, -0.12, 0)
	hook_proj.visible = true
	hook_vel = launch_dir * spd

	hook_hand_mesh.position = HOOK_HOME + Vector3(0, -0.08, -0.18)
	hook_hand_mesh.rotation.x = deg_to_rad(-28.0)
	Game.play_sfx("hook_throw", lerp(0.92, 1.15, pwr), 0.9)


func _try_climb():
	var info = raft.nearest_tile_info(global_position)
	if info["dist"] > 1.85:
		return
	var tp = info["pos"]
	var off = global_position - tp
	off.y = 0.0
	if abs(off.x) > abs(off.z):
		off = Vector3(sign(off.x) * 0.9, 0.0, 0.0)
	else:
		off = Vector3(0.0, 0.0, sign(off.z) * 0.9)
	global_position = tp + off + Vector3(0, 0.55, 0)
	velocity = Vector3.ZERO
	Game.say("Berhasil naik ke atas rakit")
	Game.play_sfx("splash", 1.2, 0.7)


func _ray(mask, length):
	var from = cam.global_position
	var to = from - cam.global_transform.basis.z * length
	var q = PhysicsRayQueryParameters3D.create(from, to, mask)
	q.collide_with_areas = true
	q.collide_with_bodies = false
	return get_world_3d().direct_space_state.intersect_ray(q)


func attack():
	if atk_cd > 0.0 or Game.dead:
		return
	atk_cd = 0.52
	_thrust()
	Game.play_sfx("spear", 1.0, 0.85)
	var res = _ray(4, 6.2)
	if res.is_empty():
		return
	var c = res["collider"]
	if c != null and c.has_method("hit"):
		if Game.has_spear:
			c.hit(2.2)
		else:
			c.hit(0.8)


func _thrust():
	spear_mesh.visible = true
	var tw = create_tween()
	tw.tween_property(spear_mesh, "position", Vector3(0.12, -0.16, -1.55), 0.09)
	tw.tween_property(spear_mesh, "position", SPEAR_HOME, 0.24)


func toggle_fishing():
	if Game.dead:
		return
	if fishing:
		fishing = false
		if bobber_node != null:
			bobber_node.visible = false
		Game.say("Memancing dihentikan")
		return
	if not Game.has_rod:
		Game.say("Buat Alat Pancing dulu di menu TAS")
		return
	if in_water:
		Game.say("Naik ke rakit dulu untuk memancing")
		return
	fishing = true
	fish_timer = randf_range(3.2, 6.5)
	Game.say("Memancing... tunggu umpan disambar ikan!")
	Game.play_sfx("splash", 1.25, 0.65)
