extends CharacterBody3D

var raft
var move_input = Vector2.ZERO
var look_delta = Vector2.ZERO
var jump_held = false
var yaw = 0.0
var pitch = 0.0
var head
var cam
var spear_mesh
var in_water = false
var fishing = false
var fish_timer = 0.0
var hook_cd = 0.0
var atk_cd = 0.0

const SPEED = 4.2
const SWIM_SPEED = 2.6
const GRAVITY = 16.0
const JUMP = 5.5
const SENS = 0.0045
const SPEAR_HOME = Vector3(0.35, -0.3, -0.9)


func _ready():
	collision_layer = 16
	collision_mask = 1
	floor_snap_length = 0.3
	var cs = CollisionShape3D.new()
	var cap = CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.7
	cs.shape = cap
	cs.position = Vector3(0, 0.85, 0)
	add_child(cs)
	head = Node3D.new()
	head.position = Vector3(0, 1.55, 0)
	add_child(head)
	cam = Camera3D.new()
	cam.fov = 75.0
	cam.near = 0.05
	cam.far = 800.0
	head.add_child(cam)
	cam.current = true
	_make_spear()


func _make_spear():
	spear_mesh = Node3D.new()
	spear_mesh.position = SPEAR_HOME
	spear_mesh.rotation = Vector3(0.0, deg_to_rad(6.0), 0.0)
	cam.add_child(spear_mesh)
	var wood = StandardMaterial3D.new()
	wood.albedo_color = Color(0.45, 0.3, 0.14)
	var steel = StandardMaterial3D.new()
	steel.albedo_color = Color(0.7, 0.72, 0.75)
	steel.metallic = 0.8
	var shaft = MeshInstance3D.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 0.018
	cm.bottom_radius = 0.018
	cm.height = 1.4
	shaft.mesh = cm
	shaft.material_override = wood
	shaft.rotation.x = PI / 2.0
	spear_mesh.add_child(shaft)
	var tip = MeshInstance3D.new()
	var tm = CylinderMesh.new()
	tm.top_radius = 0.0
	tm.bottom_radius = 0.045
	tm.height = 0.22
	tip.mesh = tm
	tip.material_override = steel
	tip.rotation.x = -PI / 2.0
	tip.position = Vector3(0, 0, -0.8)
	spear_mesh.add_child(tip)
	spear_mesh.visible = false


func _process(_delta):
	spear_mesh.visible = Game.has_spear and not Game.dead
	if fishing:
		if move_input.length() > 0.5 or in_water or Game.dead:
			fishing = false
			Game.say("Memancing dibatalkan")
			return
		fish_timer -= _delta
		if fish_timer <= 0.0:
			fishing = false
			Game.catch_fish()


func _physics_process(delta):
	hook_cd = max(0.0, hook_cd - delta)
	atk_cd = max(0.0, atk_cd - delta)
	var active = (not Game.dead) and (not Game.menu_open)
	if active:
		yaw -= look_delta.x * SENS
		pitch = clamp(pitch - look_delta.y * SENS, -1.45, 1.45)
	look_delta = Vector2.ZERO
	rotation.y = yaw
	head.rotation.x = pitch

	var inp = Vector2.ZERO
	if active:
		inp = move_input
	var dir = transform.basis * Vector3(inp.x, 0.0, inp.y)
	dir.y = 0.0

	in_water = global_position.y < -0.25
	if in_water:
		velocity.x = dir.x * SWIM_SPEED
		velocity.z = dir.z * SWIM_SPEED
		velocity.y = (-0.95 - global_position.y) * 3.0
		if active and jump_held:
			_try_climb()
	else:
		velocity.x = dir.x * SPEED
		velocity.z = dir.z * SPEED
		if not is_on_floor():
			velocity.y -= GRAVITY * delta
		elif active and jump_held:
			velocity.y = JUMP
		else:
			velocity.y = 0.0
	move_and_slide()


func _try_climb():
	var info = raft.nearest_tile_info(global_position)
	if info["dist"] > 1.6:
		return
	var tp = info["pos"]
	var off = global_position - tp
	off.y = 0.0
	if abs(off.x) > abs(off.z):
		off = Vector3(sign(off.x) * 0.9, 0.0, 0.0)
	else:
		off = Vector3(0.0, 0.0, sign(off.z) * 0.9)
	global_position = tp + off + Vector3(0, 0.35, 0)
	velocity = Vector3.ZERO
	Game.say("Naik ke rakit")


func _ray(mask, length):
	var from = cam.global_position
	var to = from - cam.global_transform.basis.z * length
	var q = PhysicsRayQueryParameters3D.create(from, to, mask)
	q.collide_with_areas = true
	q.collide_with_bodies = false
	return get_world_3d().direct_space_state.intersect_ray(q)


func throw_hook():
	if hook_cd > 0.0 or Game.dead:
		return
	hook_cd = 0.5
	var res = _ray(2, 24.0)
	if res.is_empty():
		Game.say("Arahkan tanda + ke barang yang mengapung")
		return
	var c = res["collider"]
	if c != null and c.has_method("pull_to"):
		c.pull_to(self)


func attack():
	if atk_cd > 0.0 or Game.dead:
		return
	atk_cd = 0.6
	_thrust()
	var res = _ray(4, 5.5)
	if res.is_empty():
		return
	var c = res["collider"]
	if c != null and c.has_method("hit"):
		if Game.has_spear:
			c.hit(2.0)
		else:
			c.hit(0.7)


func _thrust():
	var tw = create_tween()
	tw.tween_property(spear_mesh, "position", Vector3(0.1, -0.15, -1.6), 0.1)
	tw.tween_property(spear_mesh, "position", SPEAR_HOME, 0.25)


func toggle_fishing():
	if Game.dead:
		return
	if fishing:
		fishing = false
		Game.say("Memancing dibatalkan")
		return
	if not Game.has_rod:
		Game.say("Buat Pancing dulu di menu TAS")
		return
	if in_water:
		return
	fishing = true
	fish_timer = randf_range(3.0, 7.0)
	Game.say("Memancing... jangan bergerak")
