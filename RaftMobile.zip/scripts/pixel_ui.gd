extends RefCounted

static var _cache = {}


static func _hash2(x, y):
	var n = (int(x) * 374761393 + int(y) * 668265263) ^ 0x5BF03635
	n = (n ^ (n >> 13)) * 1274126177
	return float(abs(n) % 1000) / 1000.0


static func get_3d_tex(kind):
	var key = "tex3d_" + kind
	if _cache.has(key):
		return _cache[key]
	var sz = 64 if kind == "wood_deck" else 32
	var img = Image.create(sz, sz, false, Image.FORMAT_RGBA8)

	for y in range(sz):
		for x in range(sz):
			var h = _hash2(x, y)
			var c = Color(0.42, 0.28, 0.15, 1.0)

			if kind == "wood_deck":
				var row = int(y / 16)
				var ly = y % 16
				var joint_x = (row * 23 + 14) % 64
				var base = Color(0.44, 0.29, 0.15) if (row % 2 == 0) else Color(0.38, 0.25, 0.13)
				if (row == 1 or row == 3) and x > joint_x:
					base = base.darkened(0.06)
				var streak = sin(float(x) * 0.38 + float(row) * 2.1 + float(ly) * 0.15) * 0.045
				var fine = (h - 0.5) * 0.05
				c = base.lightened(streak + fine)
				if ly == 0 or ly == 15 or x == joint_x or ((x == joint_x + 1) and ly > 0):
					c = Color(0.15, 0.09, 0.04)
				elif ly == 1:
					c = base.lightened(0.08)
				elif ly == 14:
					c = base.darkened(0.12)
				var dx_nail = abs(x - ((joint_x + 4) % 64))
				var dx_nail2 = abs(x - ((joint_x + 59) % 64))
				if (dx_nail <= 1 or dx_nail2 <= 1) and (ly == 4 or ly == 11):
					c = Color(0.20, 0.21, 0.23)

			elif kind == "wood_log":
				var bark = Color(0.29, 0.19, 0.10)
				var ridge = int(x / 3) % 2
				if ridge == 0:
					c = bark.darkened(0.08 + h * 0.06)
				else:
					c = bark.lightened(0.04 + h * 0.05)
				if x % 8 == 0 or y % 16 == 0:
					c = bark.darkened(0.22)

			elif kind == "rope_3d":
				var base_r = Color(0.66, 0.53, 0.30)
				var braid = (x + y * 2) % 6
				if braid == 0:
					c = base_r.darkened(0.26)
				elif braid <= 2:
					c = base_r.lightened(0.08 - h * 0.05)
				else:
					c = base_r.darkened(0.06 + h * 0.06)

			elif kind == "metal_steel":
				var base_m = Color(0.52, 0.56, 0.62)
				var brush = ((x / 2 + y) % 4) * 0.025
				c = base_m.lightened(brush - 0.03 + (h - 0.5) * 0.05)
				if x == 0 or y == 0 or x == sz - 1 or y == sz - 1:
					c = base_m.darkened(0.25)
				elif (x == 3 or x == sz - 4) and (y == 3 or y == sz - 4):
					c = Color(0.74, 0.78, 0.84)

			elif kind == "rust_metal":
				var rust_a = Color(0.46, 0.25, 0.14)
				var iron_b = Color(0.32, 0.34, 0.37)
				var p = sin(float(x) * 0.45 + float(y) * 0.55) * 0.5 + 0.5
				c = iron_b.lerp(rust_a, clamp(p + (h - 0.5) * 0.35, 0.0, 1.0))
				if y % 8 == 0 or y % 8 == 1:
					c = Color(0.18, 0.19, 0.21)

			elif kind == "plastic_blue":
				var p_col = Color(0.14, 0.42, 0.68)
				if y >= 11 and y <= 19:
					p_col = Color(0.78, 0.82, 0.86)
					if y == 13 or y == 17:
						p_col = Color(0.75, 0.22, 0.18)
				elif y % 4 == 0:
					p_col = p_col.darkened(0.16)
				elif x % 6 == 0:
					p_col = p_col.lightened(0.10)
				c = p_col.lightened((h - 0.5) * 0.04)

			elif kind == "palm_leaf":
				var l_col = Color(0.17, 0.48, 0.20)
				if abs(x - sz / 2) <= 1:
					c = Color(0.36, 0.62, 0.24)
				elif (x + y) % 4 == 0 or (x - y + 64) % 4 == 0:
					c = l_col.darkened(0.16)
				else:
					c = l_col.lightened((h - 0.5) * 0.06)

			elif kind == "wood_crate":
				var cr_base = Color(0.48, 0.32, 0.16)
				var border = (x < 4 or x >= sz - 4 or y < 4 or y >= sz - 4)
				var diag = abs(x - y) <= 2 or abs(x - (sz - 1 - y)) <= 2
				if border or diag:
					c = Color(0.34, 0.22, 0.11).lightened((h - 0.5) * 0.05)
					if (x < 3 and y < 3) or (x >= sz - 3 and y < 3) or (x < 3 and y >= sz - 3) or (x >= sz - 3 and y >= sz - 3):
						c = Color(0.24, 0.26, 0.28)
				else:
					c = cr_base.darkened(0.18 if (y % 6 == 0) else ((h - 0.5) * 0.06))

			elif kind == "sail_cloth":
				var sc_col = Color(0.84, 0.79, 0.68)
				var weave = ((x + y) % 2) * 0.03
				c = sc_col.darkened(weave + h * 0.04)
				if x % 8 == 0 or y % 8 == 0:
					c = sc_col.darkened(0.14)
				if x >= 20 and x <= 28 and y >= 18 and y <= 26:
					c = Color(0.64, 0.48, 0.30).darkened(weave)

			elif kind == "shark_skin":
				var sk = Color(0.22, 0.29, 0.38)
				var scale_pat = ((x * 3 + y * 5) % 4 == 0)
				c = sk.darkened(0.08 if scale_pat else 0.0).lightened((h - 0.5) * 0.05)

			elif kind == "shark_belly":
				var sb_col = Color(0.64, 0.69, 0.74)
				c = sb_col.lightened((h - 0.5) * 0.04)

			elif kind == "sand_beach":
				var sd_col = Color(0.66, 0.56, 0.36)
				var ripple = sin(float(x) * 0.4 + float(y) * 0.25) * 0.04
				var pebble = 0.08 if (int(h * 100.0) % 17 == 0) else 0.0
				c = sd_col.lightened(ripple - pebble + (h - 0.5) * 0.05)

			elif kind == "grass_island":
				var gr_col = Color(0.20, 0.44, 0.18)
				var blade = 0.07 if ((x + y * 3) % 5 == 0) else 0.0
				c = gr_col.lightened(blade + (h - 0.5) * 0.06)

			elif kind == "rock_stone":
				var rk_col = Color(0.34, 0.36, 0.39)
				var crk = ((x * 2 + y) % 9 == 0)
				c = rk_col.darkened(0.18 if crk else 0.0).lightened((h - 0.5) * 0.08)

			img.set_pixel(x, y, c)

	var tex = ImageTexture.create_from_image(img)
	_cache[key] = tex
	return tex


static func make_3d_mat(kind, uv_scale = Vector3(1, 1, 1), triplanar = false, metal = 0.0, rough = 0.85, tint = Color.WHITE):
	var m = StandardMaterial3D.new()
	m.albedo_texture = get_3d_tex(kind)
	m.albedo_color = tint
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	m.uv1_scale = uv_scale
	m.uv1_triplanar = triplanar
	m.metallic = metal
	m.roughness = rough
	return m


static func get_wood_panel_style(bg_col = Color(0.20, 0.13, 0.07, 0.96), border_col = Color(0.52, 0.34, 0.17, 1.0)):
	var key = "wood_panel_" + bg_col.to_html() + "_" + border_col.to_html()
	if _cache.has(key):
		return _cache[key]
	var img = Image.create(24, 24, false, Image.FORMAT_RGBA8)
	var dark_edge = Color(0.06, 0.03, 0.01, 0.98)
	var hi_edge = border_col.lightened(0.20)
	var sh_edge = border_col.darkened(0.28)
	var rivet = Color(0.64, 0.68, 0.72, 1.0)
	for y in range(24):
		for x in range(24):
			if (x == 0 or x == 23) and (y == 0 or y == 23):
				img.set_pixel(x, y, Color(0, 0, 0, 0))
				continue
			if x == 0 or x == 23 or y == 0 or y == 23:
				img.set_pixel(x, y, dark_edge)
			elif x == 1 or x == 22 or y == 1 or y == 22:
				if x == 1 or y == 1:
					img.set_pixel(x, y, hi_edge)
				else:
					img.set_pixel(x, y, sh_edge)
			elif x == 2 or x == 21 or y == 2 or y == 21:
				img.set_pixel(x, y, border_col)
			elif x == 3 or x == 20 or y == 3 or y == 20:
				img.set_pixel(x, y, dark_edge)
			else:
				var plank = floori(y / 5.0) % 2
				var grain = 0.035 * sin(float(x) * 0.9 + float(y) * 1.7)
				var c = bg_col.lightened(grain) if plank == 0 else bg_col.darkened(0.05 - grain)
				if y % 5 == 0:
					c = bg_col.darkened(0.14)
				img.set_pixel(x, y, c)
	for pt in [Vector2i(2, 2), Vector2i(21, 2), Vector2i(2, 21), Vector2i(21, 21)]:
		img.set_pixel(pt.x, pt.y, rivet)
	var tex = ImageTexture.create_from_image(img)
	var sb = StyleBoxTexture.new()
	sb.texture = tex
	sb.texture_margin_left = 6
	sb.texture_margin_right = 6
	sb.texture_margin_top = 6
	sb.texture_margin_bottom = 6
	_cache[key] = sb
	return sb


static func get_slot_style(selected = false, is_armor = false):
	var key = "mc_slot_" + ("sel" if selected else "norm") + ("_arm" if is_armor else "")
	if _cache.has(key):
		return _cache[key]
	var img = Image.create(20, 20, false, Image.FORMAT_RGBA8)
	var outer = Color(0.98, 0.86, 0.28, 1.0) if selected else Color(0.07, 0.04, 0.02, 0.96)
	var rim = Color(1.0, 0.94, 0.52, 1.0) if selected else (Color(0.32, 0.36, 0.42, 0.95) if is_armor else Color(0.38, 0.25, 0.14, 0.95))
	var top_in = Color(0.05, 0.03, 0.02, 0.95)
	var bot_in = Color(0.28, 0.19, 0.11, 0.95)
	var center_bg = Color(0.16, 0.12, 0.07, 0.94) if selected else (Color(0.10, 0.12, 0.15, 0.92) if is_armor else Color(0.11, 0.07, 0.04, 0.92))
	for y in range(20):
		for x in range(20):
			if x == 0 or x == 19 or y == 0 or y == 19:
				img.set_pixel(x, y, outer)
			elif x == 1 or x == 18 or y == 1 or y == 18:
				img.set_pixel(x, y, rim)
			elif x == 2 or y == 2:
				img.set_pixel(x, y, top_in)
			elif x == 17 or y == 17:
				img.set_pixel(x, y, bot_in)
			else:
				var checker = ((x + y) % 2 == 0)
				img.set_pixel(x, y, center_bg.lightened(0.015) if checker else center_bg.darkened(0.015))
	var sb = StyleBoxTexture.new()
	sb.texture = ImageTexture.create_from_image(img)
	sb.texture_margin_left = 4
	sb.texture_margin_right = 4
	sb.texture_margin_top = 4
	sb.texture_margin_bottom = 4
	_cache[key] = sb
	return sb


static func get_pixel_button_style(fill_col, border_col = Color(0.84, 0.70, 0.42, 0.95), pressed = false):
	var key = "btn_" + fill_col.to_html() + "_" + border_col.to_html() + ("_p" if pressed else "_n")
	if _cache.has(key):
		return _cache[key]
	var img = Image.create(20, 20, false, Image.FORMAT_RGBA8)
	var outline = Color(0.06, 0.04, 0.02, 0.96)
	var top_bevel = fill_col.darkened(0.22) if pressed else fill_col.lightened(0.22)
	var bot_bevel = fill_col.lightened(0.12) if pressed else fill_col.darkened(0.28)
	for y in range(20):
		for x in range(20):
			var d_corner = (x == 0 or x == 19) and (y <= 1 or y >= 18) or (y == 0 or y == 19) and (x <= 1 or x >= 18)
			if d_corner:
				img.set_pixel(x, y, Color(0, 0, 0, 0))
				continue
			if x == 0 or x == 19 or y == 0 or y == 19 or ((x == 1 or x == 18) and (y == 1 or y == 18)):
				img.set_pixel(x, y, outline)
			elif x == 1 or x == 18 or y == 1 or y == 18:
				img.set_pixel(x, y, border_col)
			elif y == 2 or x == 2:
				img.set_pixel(x, y, top_bevel)
			elif y == 17 or x == 17:
				img.set_pixel(x, y, bot_bevel)
			else:
				var checker = ((x + y) % 2 == 0)
				var c = fill_col.lightened(0.025) if checker else fill_col.darkened(0.025)
				img.set_pixel(x, y, c)
	var tex = ImageTexture.create_from_image(img)
	var sb = StyleBoxTexture.new()
	sb.texture = tex
	sb.texture_margin_left = 5
	sb.texture_margin_right = 5
	sb.texture_margin_top = 5
	sb.texture_margin_bottom = 5
	_cache[key] = sb
	return sb


static func get_bar_bg_style():
	if _cache.has("bar_bg"):
		return _cache["bar_bg"]
	var img = Image.create(16, 12, false, Image.FORMAT_RGBA8)
	var out = Color(0.05, 0.03, 0.02, 0.95)
	var rim = Color(0.46, 0.30, 0.15, 0.95)
	var bg = Color(0.09, 0.07, 0.06, 0.92)
	for y in range(12):
		for x in range(16):
			if (x == 0 or x == 15) and (y == 0 or y == 11):
				img.set_pixel(x, y, Color(0, 0, 0, 0))
			elif x == 0 or x == 15 or y == 0 or y == 11:
				img.set_pixel(x, y, out)
			elif x == 1 or x == 14 or y == 1 or y == 10:
				img.set_pixel(x, y, rim)
			else:
				img.set_pixel(x, y, bg)
	var sb = StyleBoxTexture.new()
	sb.texture = ImageTexture.create_from_image(img)
	sb.texture_margin_left = 3
	sb.texture_margin_right = 3
	sb.texture_margin_top = 3
	sb.texture_margin_bottom = 3
	_cache["bar_bg"] = sb
	return sb


static func get_bar_fill_style(col):
	var key = "bar_fill_" + col.to_html()
	if _cache.has(key):
		return _cache[key]
	var img = Image.create(12, 8, false, Image.FORMAT_RGBA8)
	var hi = col.lightened(0.26)
	var sh = col.darkened(0.28)
	for y in range(8):
		for x in range(12):
			var c = col
			if y <= 1:
				c = hi
			elif y >= 6:
				c = sh
			if x == 11:
				c = c.darkened(0.2)
			img.set_pixel(x, y, c)
	var sb = StyleBoxTexture.new()
	sb.texture = ImageTexture.create_from_image(img)
	sb.texture_margin_left = 2
	sb.texture_margin_right = 2
	sb.texture_margin_top = 2
	sb.texture_margin_bottom = 2
	_cache[key] = sb
	return sb


static func make_joy_ring_tex():
	if _cache.has("joy_ring"):
		return _cache["joy_ring"]
	var sz = 48
	var img = Image.create(sz, sz, false, Image.FORMAT_RGBA8)
	var center = Vector2(23.5, 23.5)
	for y in range(sz):
		for x in range(sz):
			var d = Vector2(x, y).distance_to(center)
			if d >= 21.0 and d <= 23.2:
				img.set_pixel(x, y, Color(0.08, 0.05, 0.02, 0.85))
			elif d >= 18.5 and d < 21.0:
				var c = Color(0.72, 0.50, 0.25, 0.72)
				if (x + y) % 4 == 0:
					c = c.lightened(0.18)
				img.set_pixel(x, y, c)
			elif d < 18.5:
				img.set_pixel(x, y, Color(0.08, 0.12, 0.18, 0.28))
			else:
				img.set_pixel(x, y, Color(0, 0, 0, 0))
	for i in range(3):
		img.set_pixel(23 + i - 1, 3, Color(0.92, 0.78, 0.42, 0.9))
		img.set_pixel(23 + i - 1, 44, Color(0.92, 0.78, 0.42, 0.9))
		img.set_pixel(3, 23 + i - 1, Color(0.92, 0.78, 0.42, 0.9))
		img.set_pixel(44, 23 + i - 1, Color(0.92, 0.78, 0.42, 0.9))
	var tex = ImageTexture.create_from_image(img)
	_cache["joy_ring"] = tex
	return tex


static func make_joy_knob_tex():
	if _cache.has("joy_knob"):
		return _cache["joy_knob"]
	var sz = 24
	var img = Image.create(sz, sz, false, Image.FORMAT_RGBA8)
	var center = Vector2(11.5, 11.5)
	for y in range(sz):
		for x in range(sz):
			var d = Vector2(x, y).distance_to(center)
			if d <= 10.8 and d >= 9.2:
				img.set_pixel(x, y, Color(0.08, 0.05, 0.02, 0.95))
			elif d < 9.2:
				var c = Color(0.82, 0.62, 0.32, 0.92)
				if y < 9 and x < 14:
					c = c.lightened(0.20)
				elif y > 14:
					c = c.darkened(0.2)
				img.set_pixel(x, y, c)
			else:
				img.set_pixel(x, y, Color(0, 0, 0, 0))
	var tex = ImageTexture.create_from_image(img)
	_cache["joy_knob"] = tex
	return tex


# ---------- 3D Volumetric Model Icon Rasterizer (40x40) ----------

static func _shade_3d(base_col, nx, ny, nz, spec_str = 0.35):
	var ldir = Vector3(-0.48, -0.62, 0.62).normalized()
	var n = Vector3(nx, ny, nz).normalized()
	var ndotl = max(0.0, n.dot(ldir))
	var h_vec = (ldir + Vector3(0, 0, 1)).normalized()
	var spec = pow(max(0.0, n.dot(h_vec)), 14.0) * spec_str
	var c = base_col.darkened((1.0 - ndotl) * 0.46)
	c = c.lightened(max(0.0, ndotl - 0.55) * 0.32 + spec)
	return Color(clamp(c.r, 0.0, 1.0), clamp(c.g, 0.0, 1.0), clamp(c.b, 0.0, 1.0), base_col.a)


static func _draw_3d_cyl(img, p0, p1, r0, r1, col, spec_str = 0.35):
	var ab = p1 - p0
	var len_sq = max(0.001, ab.length_squared())
	var perp = Vector2(-ab.y, ab.x).normalized()
	var min_x = clampi(int(min(p0.x, p1.x) - max(r0, r1) - 2), 0, 39)
	var max_x = clampi(int(max(p0.x, p1.x) + max(r0, r1) + 2), 0, 39)
	var min_y = clampi(int(min(p0.y, p1.y) - max(r0, r1) - 2), 0, 39)
	var max_y = clampi(int(max(p0.y, p1.y) + max(r0, r1) + 2), 0, 39)
	for y in range(min_y, max_y + 1):
		for x in range(min_x, max_x + 1):
			var pt = Vector2(float(x) + 0.5, float(y) + 0.5)
			var t = clamp((pt - p0).dot(ab) / len_sq, 0.0, 1.0)
			var closest = p0 + ab * t
			var r = lerp(float(r0), float(r1), t)
			var dist = pt.distance_to(closest)
			if dist <= r and r > 0.1:
				var u = (pt - closest).dot(perp) / r
				var nz = sqrt(max(0.05, 1.0 - u * u))
				var n2 = perp * u
				var sc = _shade_3d(col, n2.x, n2.y, nz, spec_str)
				img.set_pixel(x, y, sc)


static func _draw_3d_sphere(img, center, rad, col, spec_str = 0.45):
	var min_x = clampi(int(center.x - rad - 1), 0, 39)
	var max_x = clampi(int(center.x + rad + 1), 0, 39)
	var min_y = clampi(int(center.y - rad - 1), 0, 39)
	var max_y = clampi(int(center.y + rad + 1), 0, 39)
	for y in range(min_y, max_y + 1):
		for x in range(min_x, max_x + 1):
			var dx = (float(x) + 0.5 - center.x) / float(rad)
			var dy = (float(y) + 0.5 - center.y) / float(rad)
			var d2 = dx * dx + dy * dy
			if d2 <= 1.0:
				var dz = sqrt(max(0.05, 1.0 - d2))
				img.set_pixel(x, y, _shade_3d(col, dx, dy, dz, spec_str))


static func _draw_3d_iso_box(img, cx, cy, rx, ry, height_z, col):
	var top_c = col.lightened(0.18)
	var left_c = col.darkened(0.08)
	var right_c = col.darkened(0.28)
	var seam_c = col.darkened(0.45)
	for y in range(40):
		for x in range(40):
			var dx = float(x) - float(cx)
			var dy = float(y) - float(cy)
			var d_top = abs(dx) / float(rx) + abs(dy) / float(ry)
			if d_top <= 1.0:
				var grain = sin(dx * 0.7 + dy * 1.1) * 0.04
				var c = top_c.lightened(grain)
				if d_top > 0.88:
					c = col.lightened(0.28)
				img.set_pixel(x, y, c)
			elif abs(dx) <= float(rx):
				var edge_y = float(ry) * (1.0 - abs(dx) / float(rx))
				if dy > edge_y and dy <= edge_y + float(height_z):
					if abs(dx) < 0.8 or dy > edge_y + float(height_z) - 1.1:
						img.set_pixel(x, y, seam_c)
					elif dx < 0.0:
						img.set_pixel(x, y, left_c.darkened((dy - edge_y) / float(height_z) * 0.12))
					else:
						img.set_pixel(x, y, right_c.darkened((dy - edge_y) / float(height_z) * 0.12))


static func _apply_3d_outline_and_shadow(img):
	var out = Image.create(40, 40, false, Image.FORMAT_RGBA8)
	for y in range(40):
		for x in range(40):
			if x >= 1 and y >= 2:
				if img.get_pixel(x - 1, y - 2).a > 0.2:
					out.set_pixel(x, y, Color(0.0, 0.0, 0.0, 0.35))
	for y in range(40):
		for x in range(40):
			var c = img.get_pixel(x, y)
			if c.a > 0.1:
				out.set_pixel(x, y, c)
			else:
				var near = false
				for dy in [-1, 0, 1]:
					for dx in [-1, 0, 1]:
						var nx = x + dx
						var ny = y + dy
						if nx >= 0 and nx < 40 and ny >= 0 and ny < 40:
							if img.get_pixel(nx, ny).a > 0.1:
								near = true
				if near:
					out.set_pixel(x, y, Color(0.05, 0.03, 0.02, 0.92))
	return out


static func get_icon(id):
	var key = "icon3d_" + id
	if _cache.has(key):
		return _cache[key]

	var img = Image.create(40, 40, false, Image.FORMAT_RGBA8)
	var wood_c = Color(0.62, 0.40, 0.20)
	var log_c = Color(0.45, 0.28, 0.14)
	var rope_c = Color(0.82, 0.66, 0.36)
	var steel_c = Color(0.76, 0.80, 0.86)
	var dark_steel = Color(0.42, 0.46, 0.52)

	match id:
		"hook":
			_draw_3d_cyl(img, Vector2(8, 33), Vector2(18, 23), 4.2, 4.0, log_c, 0.18)
			_draw_3d_cyl(img, Vector2(10, 31), Vector2(12, 29), 5.2, 5.2, rope_c, 0.20)
			_draw_3d_cyl(img, Vector2(13, 28), Vector2(15, 26), 5.2, 5.2, rope_c, 0.20)
			_draw_3d_cyl(img, Vector2(16, 25), Vector2(18, 23), 5.2, 5.2, rope_c, 0.20)
			_draw_3d_cyl(img, Vector2(18, 23), Vector2(28, 13), 2.5, 2.5, steel_c, 0.75)
			_draw_3d_cyl(img, Vector2(28, 13), Vector2(18, 8), 2.4, 2.0, steel_c, 0.80)
			_draw_3d_cyl(img, Vector2(18, 8), Vector2(14, 14), 2.0, 0.8, steel_c, 0.85)
			_draw_3d_cyl(img, Vector2(28, 13), Vector2(33, 23), 2.4, 2.0, steel_c, 0.80)
			_draw_3d_cyl(img, Vector2(33, 23), Vector2(27, 27), 2.0, 0.8, steel_c, 0.85)
			_draw_3d_cyl(img, Vector2(28, 13), Vector2(34, 7), 2.4, 1.0, steel_c, 0.85)

		"spear":
			_draw_3d_cyl(img, Vector2(6, 34), Vector2(26, 14), 2.8, 2.6, wood_c, 0.20)
			_draw_3d_cyl(img, Vector2(13, 27), Vector2(19, 21), 3.6, 3.6, rope_c, 0.22)
			_draw_3d_cyl(img, Vector2(25, 15), Vector2(35, 5), 4.8, 0.6, steel_c, 0.85)

		"bow":
			# 3D Curved Wooden Bow + Bowstring + Arrow
			_draw_3d_cyl(img, Vector2(10, 8), Vector2(24, 18), 2.8, 3.2, wood_c, 0.28)
			_draw_3d_cyl(img, Vector2(24, 18), Vector2(12, 32), 3.2, 2.8, wood_c, 0.28)
			_draw_3d_cyl(img, Vector2(10, 9), Vector2(12, 31), 0.9, 0.9, rope_c, 0.25)
			_draw_3d_cyl(img, Vector2(8, 22), Vector2(33, 12), 1.6, 1.6, log_c, 0.25)
			_draw_3d_cyl(img, Vector2(30, 13), Vector2(35, 11), 3.2, 0.6, steel_c, 0.85)

		"arrow":
			_draw_3d_cyl(img, Vector2(8, 32), Vector2(30, 10), 1.8, 1.8, wood_c, 0.22)
			_draw_3d_cyl(img, Vector2(28, 12), Vector2(35, 5), 3.6, 0.6, steel_c, 0.85)
			_draw_3d_cyl(img, Vector2(8, 32), Vector2(13, 27), 3.2, 2.0, Color(0.92, 0.95, 0.98), 0.35)

		"paddle":
			# 3D Wooden Paddle
			_draw_3d_cyl(img, Vector2(7, 33), Vector2(24, 16), 2.4, 2.4, log_c, 0.22)
			_draw_3d_cyl(img, Vector2(22, 18), Vector2(33, 7), 6.2, 5.2, wood_c, 0.30)

		"rod":
			_draw_3d_cyl(img, Vector2(6, 33), Vector2(31, 7), 3.2, 1.3, wood_c, 0.22)
			_draw_3d_sphere(img, Vector2(14, 27), 4.2, steel_c, 0.75)
			_draw_3d_cyl(img, Vector2(31, 7), Vector2(31, 24), 0.8, 0.8, Color(0.92, 0.95, 0.98), 0.3)
			_draw_3d_sphere(img, Vector2(31, 27), 4.5, Color(0.92, 0.20, 0.18), 0.65)
			_draw_3d_cyl(img, Vector2(27, 28), Vector2(35, 28), 1.4, 1.4, Color(0.96, 0.96, 0.96), 0.4)

		"hammer":
			_draw_3d_cyl(img, Vector2(20, 35), Vector2(20, 14), 3.2, 2.8, wood_c, 0.20)
			_draw_3d_cyl(img, Vector2(10, 13), Vector2(30, 13), 5.2, 4.8, steel_c, 0.75)
			_draw_3d_cyl(img, Vector2(18, 17), Vector2(22, 17), 3.8, 3.8, rope_c, 0.25)

		"sail":
			# 3D Classic Billowing Ship Sail on Wooden Mast & Yardarms
			_draw_3d_cyl(img, Vector2(20, 6), Vector2(20, 35), 2.5, 2.8, log_c, 0.22)
			_draw_3d_cyl(img, Vector2(8, 10), Vector2(32, 10), 2.0, 2.0, log_c, 0.22)
			_draw_3d_cyl(img, Vector2(9, 12), Vector2(9, 28), 9.5, 8.8, Color(0.94, 0.90, 0.80), 0.28)
			_draw_3d_cyl(img, Vector2(20, 12), Vector2(20, 28), 10.5, 9.8, Color(0.96, 0.92, 0.82), 0.32)
			_draw_3d_cyl(img, Vector2(8, 29), Vector2(32, 29), 2.0, 2.0, log_c, 0.22)

		"wall", "window_wall":
			_draw_3d_iso_box(img, 20, 12, 14, 5, 18, wood_c)
			_draw_3d_cyl(img, Vector2(8, 12), Vector2(8, 31), 2.4, 2.4, log_c, 0.2)
			_draw_3d_cyl(img, Vector2(32, 12), Vector2(32, 31), 2.4, 2.4, log_c, 0.2)
			if id == "window_wall":
				_draw_3d_iso_box(img, 20, 17, 6, 3, 6, Color(0.18, 0.42, 0.68))

		"fence":
			_draw_3d_cyl(img, Vector2(9, 14), Vector2(9, 32), 2.8, 2.8, log_c, 0.2)
			_draw_3d_cyl(img, Vector2(31, 14), Vector2(31, 32), 2.8, 2.8, log_c, 0.2)
			_draw_3d_cyl(img, Vector2(7, 17), Vector2(33, 17), 2.4, 2.4, wood_c, 0.25)
			_draw_3d_cyl(img, Vector2(7, 25), Vector2(33, 25), 2.4, 2.4, wood_c, 0.25)

		"roof":
			_draw_3d_cyl(img, Vector2(9, 16), Vector2(9, 34), 2.4, 2.4, log_c, 0.2)
			_draw_3d_cyl(img, Vector2(31, 16), Vector2(31, 34), 2.4, 2.4, log_c, 0.2)
			_draw_3d_iso_box(img, 20, 13, 16, 8, 4, wood_c)

		"stairs":
			_draw_3d_iso_box(img, 14, 26, 7, 4, 5, wood_c)
			_draw_3d_iso_box(img, 20, 20, 7, 4, 5, wood_c)
			_draw_3d_iso_box(img, 26, 14, 7, 4, 5, wood_c)

		"net":
			_draw_3d_cyl(img, Vector2(7, 12), Vector2(33, 12), 3.0, 3.0, log_c, 0.2)
			for i in range(4):
				var x_p = 10 + i * 6
				_draw_3d_cyl(img, Vector2(x_p, 13), Vector2(x_p, 32), 1.4, 1.4, rope_c, 0.25)
			_draw_3d_cyl(img, Vector2(8, 20), Vector2(32, 20), 1.4, 1.4, rope_c, 0.25)
			_draw_3d_cyl(img, Vector2(8, 28), Vector2(32, 28), 1.4, 1.4, rope_c, 0.25)

		"chest":
			_draw_3d_iso_box(img, 20, 17, 14, 8, 12, wood_c)
			_draw_3d_cyl(img, Vector2(8, 18), Vector2(32, 18), 2.0, 2.0, steel_c, 0.75)
			_draw_3d_sphere(img, Vector2(20, 20), 3.0, Color(0.98, 0.84, 0.28), 0.85)

		"crop_plot":
			_draw_3d_iso_box(img, 20, 22, 14, 8, 6, log_c)
			_draw_3d_cyl(img, Vector2(20, 22), Vector2(20, 9), 2.5, 1.8, Color(0.24, 0.68, 0.28), 0.3)
			_draw_3d_cyl(img, Vector2(20, 11), Vector2(11, 7), 3.2, 1.2, Color(0.28, 0.76, 0.32), 0.3)
			_draw_3d_cyl(img, Vector2(20, 11), Vector2(29, 7), 3.2, 1.2, Color(0.28, 0.76, 0.32), 0.3)

		"hammock":
			_draw_3d_cyl(img, Vector2(7, 12), Vector2(7, 32), 2.6, 2.6, log_c, 0.2)
			_draw_3d_cyl(img, Vector2(33, 12), Vector2(33, 32), 2.6, 2.6, log_c, 0.2)
			_draw_3d_cyl(img, Vector2(8, 18), Vector2(20, 26), 4.2, 5.5, Color(0.88, 0.82, 0.68), 0.3)
			_draw_3d_cyl(img, Vector2(20, 26), Vector2(32, 18), 5.5, 4.2, Color(0.88, 0.82, 0.68), 0.3)

		"cooking_pot", "fish_stew":
			_draw_3d_cyl(img, Vector2(20, 16), Vector2(20, 31), 11.5, 10.5, dark_steel, 0.65)
			_draw_3d_sphere(img, Vector2(20, 16), 9.5, Color(0.92, 0.56, 0.20), 0.55)

		"scarecrow":
			_draw_3d_cyl(img, Vector2(20, 12), Vector2(20, 35), 2.4, 2.4, log_c, 0.2)
			_draw_3d_cyl(img, Vector2(8, 18), Vector2(32, 18), 2.4, 2.4, log_c, 0.2)
			_draw_3d_sphere(img, Vector2(20, 10), 5.5, rope_c, 0.3)
			_draw_3d_cyl(img, Vector2(20, 16), Vector2(20, 27), 5.5, 4.8, Color(0.76, 0.26, 0.20), 0.3)

		"shark_bait":
			_draw_3d_cyl(img, Vector2(20, 6), Vector2(20, 18), 1.8, 1.8, rope_c, 0.25)
			_draw_3d_sphere(img, Vector2(20, 24), 9.0, Color(0.84, 0.24, 0.22), 0.45)
			_draw_3d_cyl(img, Vector2(14, 22), Vector2(26, 26), 3.0, 3.0, Color(0.42, 0.72, 0.88), 0.5)

		"armor_tile":
			_draw_3d_iso_box(img, 20, 18, 15, 8, 6, steel_c)
			_draw_3d_sphere(img, Vector2(12, 18), 2.2, dark_steel, 0.8)
			_draw_3d_sphere(img, Vector2(28, 18), 2.2, dark_steel, 0.8)

		"research_table", "decor":
			_draw_3d_iso_box(img, 20, 15, 15, 7, 4, wood_c)
			_draw_3d_cyl(img, Vector2(10, 19), Vector2(10, 33), 2.4, 2.4, log_c, 0.2)
			_draw_3d_cyl(img, Vector2(30, 19), Vector2(30, 33), 2.4, 2.4, log_c, 0.2)
			_draw_3d_sphere(img, Vector2(20, 12), 4.5, Color(0.95, 0.92, 0.80), 0.4)

		"seaweed":
			_draw_3d_cyl(img, Vector2(14, 34), Vector2(12, 10), 3.2, 1.8, Color(0.16, 0.58, 0.32), 0.35)
			_draw_3d_cyl(img, Vector2(20, 34), Vector2(22, 8), 3.5, 2.0, Color(0.20, 0.68, 0.38), 0.35)
			_draw_3d_cyl(img, Vector2(26, 34), Vector2(28, 13), 3.0, 1.6, Color(0.14, 0.52, 0.28), 0.35)

		"clay":
			_draw_3d_sphere(img, Vector2(16, 22), 8.5, Color(0.58, 0.38, 0.26), 0.25)
			_draw_3d_sphere(img, Vector2(25, 20), 7.5, Color(0.68, 0.56, 0.38), 0.25)

		"wood":
			_draw_3d_cyl(img, Vector2(7, 26), Vector2(33, 20), 4.5, 4.5, log_c, 0.18)
			_draw_3d_iso_box(img, 20, 16, 13, 5, 4, wood_c)
			_draw_3d_cyl(img, Vector2(18, 12), Vector2(22, 27), 2.6, 2.6, rope_c, 0.25)

		"foundation":
			_draw_3d_cyl(img, Vector2(8, 25), Vector2(22, 32), 3.2, 3.2, log_c, 0.15)
			_draw_3d_cyl(img, Vector2(18, 20), Vector2(32, 27), 3.2, 3.2, log_c, 0.15)
			_draw_3d_iso_box(img, 20, 17, 15, 8, 5, wood_c)
			_draw_3d_sphere(img, Vector2(10, 17), 2.4, rope_c, 0.2)
			_draw_3d_sphere(img, Vector2(30, 17), 2.4, rope_c, 0.2)

		"plastic":
			_draw_3d_cyl(img, Vector2(12, 31), Vector2(26, 13), 6.2, 5.8, Color(0.20, 0.56, 0.88), 0.65)
			_draw_3d_cyl(img, Vector2(16, 25), Vector2(22, 18), 6.4, 6.2, Color(0.92, 0.94, 0.96), 0.45)
			_draw_3d_cyl(img, Vector2(18, 23), Vector2(20, 20), 6.5, 6.4, Color(0.88, 0.22, 0.18), 0.45)
			_draw_3d_cyl(img, Vector2(26, 13), Vector2(30, 8), 3.0, 2.8, Color(0.92, 0.20, 0.18), 0.55)

		"scrap":
			_draw_3d_iso_box(img, 19, 21, 13, 7, 4, dark_steel)
			_draw_3d_iso_box(img, 23, 16, 9, 5, 3, Color(0.64, 0.36, 0.20))
			_draw_3d_sphere(img, Vector2(15, 16), 4.0, steel_c, 0.80)

		"leaf":
			_draw_3d_cyl(img, Vector2(8, 33), Vector2(32, 9), 2.0, 1.0, Color(0.45, 0.68, 0.24), 0.25)
			for i in range(4):
				var t = float(i + 1) / 5.0
				var base_p = Vector2(8, 33).lerp(Vector2(31, 10), t)
				_draw_3d_cyl(img, base_p, base_p + Vector2(-9, -3), 3.2, 1.0, Color(0.22, 0.66, 0.26), 0.30)
				_draw_3d_cyl(img, base_p, base_p + Vector2(3, 9), 3.2, 1.0, Color(0.18, 0.56, 0.22), 0.30)

		"rope":
			for i in range(12):
				var a0 = float(i) * TAU / 12.0
				var a1 = float(i + 1) * TAU / 12.0
				var p0 = Vector2(20, 19) + Vector2(cos(a0) * 9.5, sin(a0) * 7.5)
				var p1 = Vector2(20, 19) + Vector2(cos(a1) * 9.5, sin(a1) * 7.5)
				_draw_3d_cyl(img, p0, p1, 3.8, 3.8, rope_c, 0.25)
			_draw_3d_cyl(img, Vector2(26, 24), Vector2(31, 34), 3.2, 2.5, rope_c, 0.25)

		"coconut":
			_draw_3d_sphere(img, Vector2(20, 21), 12.5, Color(0.44, 0.27, 0.13), 0.22)
			_draw_3d_sphere(img, Vector2(18, 16), 6.5, Color(0.95, 0.94, 0.88), 0.35)
			_draw_3d_sphere(img, Vector2(18, 16), 3.8, Color(0.32, 0.78, 0.96), 0.65)

		"can":
			_draw_3d_cyl(img, Vector2(20, 10), Vector2(20, 31), 9.5, 9.5, steel_c, 0.70)
			_draw_3d_cyl(img, Vector2(20, 16), Vector2(20, 26), 9.8, 9.8, Color(0.84, 0.24, 0.18), 0.35)
			_draw_3d_iso_box(img, 20, 10, 9, 4, 2, steel_c)

		"water", "thirst":
			_draw_3d_cyl(img, Vector2(20, 11), Vector2(20, 32), 8.5, 7.5, Color(0.22, 0.68, 0.96), 0.75)
			_draw_3d_cyl(img, Vector2(20, 8), Vector2(20, 12), 5.0, 5.0, rope_c, 0.30)

		"fish", "cooked_fish":
			var fc = Color(0.36, 0.68, 0.88) if id == "fish" else Color(0.84, 0.50, 0.18)
			_draw_3d_cyl(img, Vector2(10, 22), Vector2(27, 18), 6.5, 4.5, fc, 0.55)
			_draw_3d_cyl(img, Vector2(27, 18), Vector2(35, 12), 3.5, 1.2, fc, 0.45)
			_draw_3d_cyl(img, Vector2(27, 18), Vector2(35, 25), 3.5, 1.2, fc, 0.45)
			_draw_3d_sphere(img, Vector2(12, 20), 2.0, Color(0.98, 0.96, 0.90), 0.6)

		"meat", "cooked_meat", "hunger":
			var mc = Color(0.82, 0.24, 0.22) if id == "meat" else Color(0.78, 0.42, 0.16)
			_draw_3d_cyl(img, Vector2(10, 29), Vector2(20, 19), 3.0, 3.0, Color(0.95, 0.92, 0.84), 0.35)
			_draw_3d_sphere(img, Vector2(24, 16), 9.5, mc, 0.40)

		"purifier":
			_draw_3d_cyl(img, Vector2(20, 16), Vector2(20, 34), 8.5, 8.5, Color(0.22, 0.58, 0.86), 0.60)
			_draw_3d_cyl(img, Vector2(20, 16), Vector2(20, 7), 10.0, 1.5, steel_c, 0.75)

		"grill":
			_draw_3d_cyl(img, Vector2(20, 19), Vector2(20, 33), 10.5, 11.0, dark_steel, 0.60)
			_draw_3d_sphere(img, Vector2(20, 17), 7.5, Color(0.98, 0.42, 0.12), 0.80)
			_draw_3d_cyl(img, Vector2(11, 16), Vector2(29, 16), 1.6, 1.6, steel_c, 0.75)

		"lantern":
			_draw_3d_cyl(img, Vector2(20, 18), Vector2(20, 35), 2.8, 3.2, log_c, 0.20)
			_draw_3d_sphere(img, Vector2(20, 13), 7.5, Color(1.0, 0.86, 0.36), 0.90)

		"anchor":
			_draw_3d_cyl(img, Vector2(20, 8), Vector2(20, 31), 3.0, 3.2, steel_c, 0.78)
			_draw_3d_cyl(img, Vector2(12, 14), Vector2(28, 14), 2.6, 2.6, rope_c, 0.30)
			_draw_3d_cyl(img, Vector2(20, 31), Vector2(9, 23), 3.2, 1.8, steel_c, 0.80)
			_draw_3d_cyl(img, Vector2(20, 31), Vector2(31, 23), 3.2, 1.8, steel_c, 0.80)
			_draw_3d_sphere(img, Vector2(20, 7), 3.5, rope_c, 0.35)

		"leaf_hat", "slot_head":
			var hc = Color(0.24, 0.68, 0.28) if id == "leaf_hat" else dark_steel
			_draw_3d_sphere(img, Vector2(20, 20), 10.5, hc, 0.35)
			_draw_3d_cyl(img, Vector2(7, 24), Vector2(33, 24), 3.2, 3.2, rope_c if id == "leaf_hat" else hc, 0.30)

		"wood_vest", "slot_chest":
			var vc = wood_c if id == "wood_vest" else dark_steel
			_draw_3d_cyl(img, Vector2(20, 11), Vector2(20, 32), 10.5, 9.5, vc, 0.30)
			_draw_3d_cyl(img, Vector2(11, 14), Vector2(29, 14), 4.0, 4.0, rope_c if id == "wood_vest" else vc, 0.25)

		"rope_legs", "slot_legs":
			var lc = rope_c if id == "rope_legs" else dark_steel
			_draw_3d_cyl(img, Vector2(12, 11), Vector2(28, 11), 4.0, 4.0, lc, 0.25)
			_draw_3d_cyl(img, Vector2(14, 12), Vector2(13, 33), 4.2, 3.6, lc, 0.25)
			_draw_3d_cyl(img, Vector2(26, 12), Vector2(27, 33), 4.2, 3.6, lc, 0.25)

		"scrap_boots", "slot_feet":
			var bc = steel_c if id == "scrap_boots" else dark_steel
			_draw_3d_cyl(img, Vector2(13, 14), Vector2(13, 30), 4.2, 4.5, bc, 0.65)
			_draw_3d_cyl(img, Vector2(13, 30), Vector2(8, 31), 4.0, 3.5, Color(0.22, 0.52, 0.82), 0.50)
			_draw_3d_cyl(img, Vector2(27, 14), Vector2(27, 30), 4.2, 4.5, bc, 0.65)
			_draw_3d_cyl(img, Vector2(27, 30), Vector2(32, 31), 4.0, 3.5, Color(0.22, 0.52, 0.82), 0.50)

		"climb_person":
			_draw_3d_cyl(img, Vector2(24, 14), Vector2(36, 14), 3.6, 3.6, wood_c, 0.25)
			_draw_3d_cyl(img, Vector2(5, 34), Vector2(35, 34), 3.2, 3.2, Color(0.18, 0.54, 0.88), 0.55)
			_draw_3d_sphere(img, Vector2(18, 13), 4.4, Color(0.95, 0.76, 0.56), 0.35)
			_draw_3d_cyl(img, Vector2(17, 18), Vector2(15, 29), 4.0, 3.5, Color(0.24, 0.68, 0.42), 0.30)
			_draw_3d_cyl(img, Vector2(18, 19), Vector2(27, 14), 2.6, 2.4, Color(0.95, 0.76, 0.56), 0.30)
			_draw_3d_cyl(img, Vector2(16, 28), Vector2(24, 24), 2.6, 2.4, rope_c, 0.25)
			_draw_3d_cyl(img, Vector2(8, 25), Vector2(8, 9), 2.4, 2.4, Color(0.98, 0.88, 0.32), 0.60)
			_draw_3d_cyl(img, Vector2(8, 8), Vector2(4, 14), 2.2, 1.6, Color(0.98, 0.88, 0.32), 0.60)
			_draw_3d_cyl(img, Vector2(8, 8), Vector2(12, 14), 2.2, 1.6, Color(0.98, 0.88, 0.32), 0.60)

		"dive":
			_draw_3d_cyl(img, Vector2(6, 10), Vector2(34, 10), 2.8, 2.8, Color(0.20, 0.62, 0.94), 0.55)
			_draw_3d_cyl(img, Vector2(20, 12), Vector2(20, 30), 3.6, 3.6, Color(0.32, 0.88, 0.96), 0.55)
			_draw_3d_cyl(img, Vector2(20, 31), Vector2(12, 23), 3.2, 2.2, Color(0.32, 0.88, 0.96), 0.55)
			_draw_3d_cyl(img, Vector2(20, 31), Vector2(28, 23), 3.2, 2.2, Color(0.32, 0.88, 0.96), 0.55)

		"jump":
			_draw_3d_cyl(img, Vector2(10, 32), Vector2(30, 32), 3.2, 3.2, wood_c, 0.25)
			_draw_3d_cyl(img, Vector2(20, 26), Vector2(20, 9), 3.8, 3.8, Color(0.32, 0.86, 0.48), 0.55)
			_draw_3d_cyl(img, Vector2(20, 8), Vector2(12, 16), 3.4, 2.2, Color(0.32, 0.86, 0.48), 0.55)
			_draw_3d_cyl(img, Vector2(20, 8), Vector2(28, 16), 3.4, 2.2, Color(0.32, 0.86, 0.48), 0.55)

		"bag":
			_draw_3d_cyl(img, Vector2(20, 13), Vector2(20, 32), 11.5, 12.0, Color(0.68, 0.44, 0.22), 0.30)
			_draw_3d_cyl(img, Vector2(11, 18), Vector2(29, 18), 3.2, 3.2, rope_c, 0.35)
			_draw_3d_sphere(img, Vector2(20, 20), 3.5, Color(0.96, 0.82, 0.32), 0.75)

		"settings":
			for i in range(8):
				var a = float(i) * TAU / 8.0
				_draw_3d_cyl(img, Vector2(20, 20), Vector2(20, 20) + Vector2(cos(a), sin(a)) * 13.0, 3.4, 3.0, steel_c, 0.70)
			_draw_3d_sphere(img, Vector2(20, 20), 9.5, steel_c, 0.75)
			_draw_3d_sphere(img, Vector2(20, 20), 4.2, Color(0.18, 0.22, 0.28), 0.20)

		"heart":
			_draw_3d_sphere(img, Vector2(15, 16), 7.5, Color(0.92, 0.20, 0.24), 0.65)
			_draw_3d_sphere(img, Vector2(25, 16), 7.5, Color(0.92, 0.20, 0.24), 0.65)
			_draw_3d_cyl(img, Vector2(12, 19), Vector2(20, 32), 6.5, 1.5, Color(0.92, 0.20, 0.24), 0.55)
			_draw_3d_cyl(img, Vector2(28, 19), Vector2(20, 32), 6.5, 1.5, Color(0.92, 0.20, 0.24), 0.55)

		_:
			_draw_3d_iso_box(img, 20, 18, 12, 7, 6, wood_c)

	var final_img = _apply_3d_outline_and_shadow(img)
	var tex = ImageTexture.create_from_image(final_img)
	_cache[key] = tex
	return tex
