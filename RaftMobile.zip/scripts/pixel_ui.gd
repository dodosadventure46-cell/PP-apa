extends RefCounted

static var _cache = {}


static func get_wood_panel_style(bg_col = Color(0.24, 0.15, 0.08, 0.95), border_col = Color(0.55, 0.36, 0.18, 1.0)):
	var key = "wood_panel_" + bg_col.to_html() + "_" + border_col.to_html()
	if _cache.has(key):
		return _cache[key]
	var img = Image.create(24, 24, false, Image.FORMAT_RGBA8)
	var dark_edge = Color(0.08, 0.04, 0.02, 0.98)
	var hi_edge = border_col.lightened(0.22)
	var sh_edge = border_col.darkened(0.28)
	var rivet = Color(0.68, 0.72, 0.76, 1.0)
	for y in range(24):
		for x in range(24):
			# Stepped pixel corners
			if (x == 0 or x == 23) and (y == 0 or y == 23):
				img.set_pixel(x, y, Color(0, 0, 0, 0))
				continue
			if x == 0 or x == 23 or y == 0 or y == 23:
				img.set_pixel(x, y, dark_edge)
			elif x == 1 or x == 22 or y == 1 or y == 22:
				if x == 1 or y == 1:
					img.set_pixel(x, y, hi_edge)
				else:
					img.set_pixel(x, y, sh_edge)
			elif x == 2 or x == 21 or y == 2 or y == 21:
				img.set_pixel(x, y, border_col)
			elif x == 3 or x == 20 or y == 3 or y == 20:
				img.set_pixel(x, y, dark_edge)
			else:
				# Interior pixel wood grain
				var plank = floori(y / 5.0) % 2
				var grain = 0.04 * sin(float(x) * 0.9 + float(y) * 1.7)
				var c = bg_col.lightened(grain) if plank == 0 else bg_col.darkened(0.05 - grain)
				if y % 5 == 0:
					c = bg_col.darkened(0.14)
				img.set_pixel(x, y, c)
	# Corner pixel rivets
	for pt in [Vector2i(2, 2), Vector2i(21, 2), Vector2i(2, 21), Vector2i(21, 21)]:
		img.set_pixel(pt.x, pt.y, rivet)
	var tex = ImageTexture.create_from_image(img)
	var sb = StyleBoxTexture.new()
	sb.texture = tex
	sb.texture_margin_left = 6
	sb.texture_margin_right = 6
	sb.texture_margin_top = 6
	sb.texture_margin_bottom = 6
	_cache[key] = sb
	return sb


static func get_pixel_button_style(fill_col, border_col = Color(0.88, 0.74, 0.46, 0.95), pressed = false):
	var key = "btn_" + fill_col.to_html() + "_" + border_col.to_html() + ("_p" if pressed else "_n")
	if _cache.has(key):
		return _cache[key]
	var img = Image.create(20, 20, false, Image.FORMAT_RGBA8)
	var outline = Color(0.06, 0.04, 0.02, 0.96)
	var top_bevel = fill_col.darkened(0.22) if pressed else fill_col.lightened(0.26)
	var bot_bevel = fill_col.lightened(0.12) if pressed else fill_col.darkened(0.28)
	for y in range(20):
		for x in range(20):
			var d_corner = (x == 0 or x == 19) and (y <= 1 or y >= 18) or (y == 0 or y == 19) and (x <= 1 or x >= 18)
			if d_corner:
				img.set_pixel(x, y, Color(0, 0, 0, 0))
				continue
			if x == 0 or x == 19 or y == 0 or y == 19 or ((x == 1 or x == 18) and (y == 1 or y == 18)):
				img.set_pixel(x, y, outline)
			elif x == 1 or x == 18 or y == 1 or y == 18:
				img.set_pixel(x, y, border_col)
			elif y == 2 or x == 2:
				img.set_pixel(x, y, top_bevel)
			elif y == 17 or x == 17:
				img.set_pixel(x, y, bot_bevel)
			else:
				var checker = ((x + y) % 2 == 0)
				var c = fill_col.lightened(0.03) if checker else fill_col.darkened(0.03)
				img.set_pixel(x, y, c)
	var tex = ImageTexture.create_from_image(img)
	var sb = StyleBoxTexture.new()
	sb.texture = tex
	sb.texture_margin_left = 5
	sb.texture_margin_right = 5
	sb.texture_margin_top = 5
	sb.texture_margin_bottom = 5
	_cache[key] = sb
	return sb


static func get_bar_bg_style():
	if _cache.has("bar_bg"):
		return _cache["bar_bg"]
	var img = Image.create(16, 12, false, Image.FORMAT_RGBA8)
	var out = Color(0.05, 0.03, 0.02, 0.95)
	var rim = Color(0.48, 0.32, 0.16, 0.95)
	var bg = Color(0.1, 0.08, 0.07, 0.92)
	for y in range(12):
		for x in range(16):
			if (x == 0 or x == 15) and (y == 0 or y == 11):
				img.set_pixel(x, y, Color(0, 0, 0, 0))
			elif x == 0 or x == 15 or y == 0 or y == 11:
				img.set_pixel(x, y, out)
			elif x == 1 or x == 14 or y == 1 or y == 10:
				img.set_pixel(x, y, rim)
			else:
				img.set_pixel(x, y, bg)
	var sb = StyleBoxTexture.new()
	sb.texture = ImageTexture.create_from_image(img)
	sb.texture_margin_left = 3
	sb.texture_margin_right = 3
	sb.texture_margin_top = 3
	sb.texture_margin_bottom = 3
	_cache["bar_bg"] = sb
	return sb


static func get_bar_fill_style(col):
	var key = "bar_fill_" + col.to_html()
	if _cache.has(key):
		return _cache[key]
	var img = Image.create(12, 8, false, Image.FORMAT_RGBA8)
	var hi = col.lightened(0.3)
	var sh = col.darkened(0.28)
	for y in range(8):
		for x in range(12):
			var c = col
			if y <= 1:
				c = hi
			elif y >= 6:
				c = sh
			if x == 11:
				c = c.darkened(0.2)
			img.set_pixel(x, y, c)
	var sb = StyleBoxTexture.new()
	sb.texture = ImageTexture.create_from_image(img)
	sb.texture_margin_left = 2
	sb.texture_margin_right = 2
	sb.texture_margin_top = 2
	sb.texture_margin_bottom = 2
	_cache[key] = sb
	return sb


static func make_joy_ring_tex():
	if _cache.has("joy_ring"):
		return _cache["joy_ring"]
	var sz = 48
	var img = Image.create(sz, sz, false, Image.FORMAT_RGBA8)
	var center = Vector2(23.5, 23.5)
	for y in range(sz):
		for x in range(sz):
			var d = Vector2(x, y).distance_to(center)
			if d >= 21.0 and d <= 23.2:
				img.set_pixel(x, y, Color(0.08, 0.05, 0.02, 0.85))
			elif d >= 18.5 and d < 21.0:
				var c = Color(0.75, 0.54, 0.28, 0.72)
				if (x + y) % 4 == 0:
					c = c.lightened(0.2)
				img.set_pixel(x, y, c)
			elif d < 18.5:
				img.set_pixel(x, y, Color(0.12, 0.16, 0.22, 0.28))
			else:
				img.set_pixel(x, y, Color(0, 0, 0, 0))
	# Cardinal pixel ticks
	for i in range(3):
		img.set_pixel(23 + i - 1, 3, Color(0.95, 0.82, 0.45, 0.9))
		img.set_pixel(23 + i - 1, 44, Color(0.95, 0.82, 0.45, 0.9))
		img.set_pixel(3, 23 + i - 1, Color(0.95, 0.82, 0.45, 0.9))
		img.set_pixel(44, 23 + i - 1, Color(0.95, 0.82, 0.45, 0.9))
	var tex = ImageTexture.create_from_image(img)
	_cache["joy_ring"] = tex
	return tex


static func make_joy_knob_tex():
	if _cache.has("joy_knob"):
		return _cache["joy_knob"]
	var sz = 24
	var img = Image.create(sz, sz, false, Image.FORMAT_RGBA8)
	var center = Vector2(11.5, 11.5)
	for y in range(sz):
		for x in range(sz):
			var d = Vector2(x, y).distance_to(center)
			if d <= 10.8 and d >= 9.2:
				img.set_pixel(x, y, Color(0.08, 0.05, 0.02, 0.95))
			elif d < 9.2:
				var c = Color(0.86, 0.65, 0.34, 0.92)
				if y < 9 and x < 14:
					c = c.lightened(0.22)
				elif y > 14:
					c = c.darkened(0.2)
				img.set_pixel(x, y, c)
			else:
				img.set_pixel(x, y, Color(0, 0, 0, 0))
	var tex = ImageTexture.create_from_image(img)
	_cache["joy_knob"] = tex
	return tex


static func get_icon(id):
	var key = "icon_" + id
	if _cache.has(key):
		return _cache[key]
	var patterns = {
		"heart": [
			"................",
			"..####....####..",
			".######..######.",
			"################",
			"###@@###########",
			"##@#############",
			"################",
			".##############.",
			"..############..",
			"...##########...",
			"....########....",
			".....######.....",
			"......####......",
			".......##.......",
			"................",
			"................",
		],
		"hunger": [
			"..........####..",
			".........######.",
			"........#######.",
			".......########.",
			"......#########.",
			".....#########..",
			"....#########...",
			"....########....",
			"....#######.....",
			"...@@@###.......",
			"..@@@@@.........",
			".@@@.@@@........",
			"@@@...@@........",
			".@..............",
			"................",
			"................",
		],
		"thirst": [
			".......##.......",
			"......####......",
			"......####......",
			".....######.....",
			"....########....",
			"....########....",
			"...##########...",
			"..###@@#######..",
			"..##@@########..",
			"..##@@########..",
			"..###@@#######..",
			"...##########...",
			"....########....",
			".....######.....",
			"................",
			"................",
		],
		"hook": [
			"......####......",
			".....##..##.....",
			"..........##....",
			"....##....##....",
			"...##....##.....",
			"........##......",
			".......##..##...",
			"......##..##....",
			".....@@@.##.....",
			"....@@@.........",
			"...@@@..........",
			"..@@@...........",
			".@@@............",
			"@@@.............",
			"................",
			"................",
		],
		"spear": [
			".............###",
			"............####",
			"...........#####",
			"..........#####.",
			".........###@@..",
			"........@@@.#...",
			".......@@@......",
			"......@@@.......",
			".....@@@........",
			"....@@@.........",
			"...@@@..........",
			"..@@@...........",
			".@@@............",
			"@@@.............",
			"@@..............",
			"................",
		],
		"rod": [
			"...........###..",
			"..........###.#.",
			".........###..#.",
			"........###...#.",
			".......###....#.",
			"......###.....#.",
			".....###......#.",
			"....###......@@@.",
			"...###.......###.",
			"..###...........",
			".###............",
			"###.............",
			"##..............",
			"................",
			"................",
			"................",
		],
		"hammer": [
			"....########....",
			"...##########...",
			"...##########...",
			"....########....",
			".......@@.......",
			".......@@.......",
			".......@@.......",
			".......@@.......",
			".......@@.......",
			".......@@.......",
			".......@@.......",
			".......@@.......",
			"......@@@@......",
			"......@@@@......",
			"................",
			"................",
		],
		"bag": [
			".....######.....",
			"....##....##....",
			"...##########...",
			"..############..",
			"..############..",
			"..###@@@@@@###..",
			"..###@@##@@###..",
			"..############..",
			"..############..",
			"..############..",
			"..############..",
			"...##########...",
			"................",
			"................",
			"................",
			"................",
		],
		"settings": [
			"......####......",
			"..##..####..##..",
			".##############.",
			".####......####.",
			"..##..####..##..",
			"#####.####.#####",
			"####........####",
			"#####.####.#####",
			"..##..####..##..",
			".####......####.",
			".##############.",
			"..##..####..##..",
			"......####......",
			"................",
			"................",
			"................",
		],
		"jump": [
			".......##.......",
			"......####......",
			".....######.....",
			"....########....",
			"...###.##.###...",
			"......####......",
			"......####......",
			"......####......",
			"......####......",
			"....########....",
			"...##########...",
			"................",
			"..@@@@@@@@@@@@..",
			".@@@@@@@@@@@@@@.",
			"................",
			"................",
		],
		"wood": [
			"................",
			"..############..",
			".##############.",
			".###@@@##@@@###.",
			"..############..",
			"................",
			"...############.",
			"..##############",
			"..###@@@##@@@###",
			"...############.",
			"................",
			"..############..",
			".##############.",
			"..############..",
			"................",
			"................",
		],
		"plastic": [
			"......@@@@......",
			"......@@@@......",
			".....######.....",
			"....########....",
			"....########....",
			"....@@@@@@@@....",
			"....@@@@@@@@....",
			"....########....",
			"....########....",
			"....########....",
			"....########....",
			".....######.....",
			"................",
			"................",
			"................",
			"................",
		],
		"scrap": [
			"....########....",
			"..############..",
			".####..##..####.",
			".###...##...###.",
			"#####@@@@@@#####",
			"####@@@@@@@@####",
			".###..@@@@..###.",
			"..###......###..",
			"...##########...",
			"....########....",
			"................",
			"................",
			"................",
			"................",
			"................",
			"................",
		],
		"leaf": [
			"...........###..",
			".........#####..",
			".......#######..",
			"......########..",
			".....#####@@##..",
			"....#####@@###..",
			"...#####@@###...",
			"...####@@###....",
			"..####@@###.....",
			"..###@@###......",
			"...#@@###.......",
			"...@@###........",
			"..@@............",
			".@@.............",
			"................",
			"................",
		],
	}
	var p_col = Color(0.92, 0.85, 0.72)
	var s_col = Color(0.98, 0.96, 0.9)
	match id:
		"heart":
			p_col = Color(0.92, 0.22, 0.25)
			s_col = Color(1.0, 0.75, 0.78)
		"hunger":
			p_col = Color(0.88, 0.52, 0.18)
			s_col = Color(0.95, 0.92, 0.82)
		"thirst", "water":
			p_col = Color(0.24, 0.68, 0.98)
			s_col = Color(0.82, 0.95, 1.0)
		"hook":
			p_col = Color(0.78, 0.84, 0.9)
			s_col = Color(0.75, 0.52, 0.26)
		"spear":
			p_col = Color(0.82, 0.86, 0.92)
			s_col = Color(0.68, 0.44, 0.22)
		"rod":
			p_col = Color(0.72, 0.48, 0.24)
			s_col = Color(0.95, 0.25, 0.25)
		"hammer", "foundation", "wood":
			p_col = Color(0.72, 0.48, 0.24)
			s_col = Color(0.52, 0.34, 0.16)
		"bag":
			p_col = Color(0.76, 0.54, 0.28)
			s_col = Color(0.95, 0.82, 0.35)
		"settings", "scrap":
			p_col = Color(0.72, 0.76, 0.82)
			s_col = Color(0.45, 0.48, 0.54)
		"jump":
			p_col = Color(0.35, 0.88, 0.48)
			s_col = Color(0.78, 0.56, 0.3)
		"plastic":
			p_col = Color(0.55, 0.84, 0.96)
			s_col = Color(0.92, 0.26, 0.24)
		"leaf":
			p_col = Color(0.28, 0.78, 0.32)
			s_col = Color(0.58, 0.92, 0.45)

	var grid = patterns.get(id, patterns["wood"])
	var img = Image.create(16, 16, false, Image.FORMAT_RGBA8)
	for y in range(16):
		var row = grid[y]
		for x in range(16):
			var ch = row[x]
			if ch == "#":
				img.set_pixel(x, y, p_col)
			elif ch == "@":
				img.set_pixel(x, y, s_col)
			else:
				img.set_pixel(x, y, Color(0, 0, 0, 0))
	# Add subtle 1px dark outline around non-empty pixels
	var out = Image.create(16, 16, false, Image.FORMAT_RGBA8)
	for y in range(16):
		for x in range(16):
			var c = img.get_pixel(x, y)
			if c.a > 0.1:
				out.set_pixel(x, y, c)
			else:
				var near = false
				for dy in [-1, 0, 1]:
					for dx in [-1, 0, 1]:
						var nx = x + dx
						var ny = y + dy
						if nx >= 0 and nx < 16 and ny >= 0 and ny < 16:
							if img.get_pixel(nx, ny).a > 0.1:
								near = true
				if near:
					out.set_pixel(x, y, Color(0.05, 0.03, 0.02, 0.88))
				else:
					out.set_pixel(x, y, Color(0, 0, 0, 0))
	var tex = ImageTexture.create_from_image(out)
	_cache[key] = tex
	return tex
