extends RefCounted

static var _cache = {}


static func _hash2(x, y):
	var n = (int(x) * 374761393 + int(y) * 668265263) ^ 0x5BF03635
	n = (n ^ (n >> 13)) * 1274126177
	return float(abs(n) % 1000) / 1000.0


static func get_3d_tex(kind):
	var key = "tex3d_" + kind
	if _cache.has(key):
		return _cache[key]
	var sz = 64 if kind == "wood_deck" else 32
	var img = Image.create(sz, sz, false, Image.FORMAT_RGBA8)

	for y in range(sz):
		for x in range(sz):
			var h = _hash2(x, y)
			var c = Color(0.42, 0.28, 0.15, 1.0)

			if kind == "wood_deck":
				var row = int(y / 16)
				var ly = y % 16
				var joint_x = (row * 23 + 14) % 64
				var base = Color(0.44, 0.29, 0.15) if (row % 2 == 0) else Color(0.38, 0.25, 0.13)
				if (row == 1 or row == 3) and x > joint_x:
					base = base.darkened(0.06)
				var streak = sin(float(x) * 0.38 + float(row) * 2.1 + float(ly) * 0.15) * 0.045
				var fine = (h - 0.5) * 0.05
				c = base.lightened(streak + fine)
				if ly == 0 or ly == 15 or x == joint_x or ((x == joint_x + 1) and ly > 0):
					c = Color(0.15, 0.09, 0.04)
				elif ly == 1:
					c = base.lightened(0.08)
				elif ly == 14:
					c = base.darkened(0.12)
				# Iron nails near joints
				var dx_nail = abs(x - ((joint_x + 4) % 64))
				var dx_nail2 = abs(x - ((joint_x + 59) % 64))
				if (dx_nail <= 1 or dx_nail2 <= 1) and (ly == 4 or ly == 11):
					c = Color(0.20, 0.21, 0.23)

			elif kind == "wood_log":
				var bark = Color(0.29, 0.19, 0.10)
				var ridge = int(x / 3) % 2
				if ridge == 0:
					c = bark.darkened(0.08 + h * 0.06)
				else:
					c = bark.lightened(0.04 + h * 0.05)
				if x % 8 == 0 or y % 16 == 0:
					c = bark.darkened(0.22)

			elif kind == "rope_3d":
				var base_r = Color(0.66, 0.53, 0.30)
				var braid = (x + y * 2) % 6
				if braid == 0:
					c = base_r.darkened(0.26)
				elif braid <= 2:
					c = base_r.lightened(0.08 - h * 0.05)
				else:
					c = base_r.darkened(0.06 + h * 0.06)

			elif kind == "metal_steel":
				var base_m = Color(0.52, 0.56, 0.62)
				var brush = ((x / 2 + y) % 4) * 0.025
				c = base_m.lightened(brush - 0.03 + (h - 0.5) * 0.05)
				if x == 0 or y == 0 or x == sz - 1 or y == sz - 1:
					c = base_m.darkened(0.25)
				elif (x == 3 or x == sz - 4) and (y == 3 or y == sz - 4):
					c = Color(0.74, 0.78, 0.84)

			elif kind == "rust_metal":
				var rust_a = Color(0.46, 0.25, 0.14)
				var iron_b = Color(0.32, 0.34, 0.37)
				var p = sin(float(x) * 0.45 + float(y) * 0.55) * 0.5 + 0.5
				c = iron_b.lerp(rust_a, clamp(p + (h - 0.5) * 0.35, 0.0, 1.0))
				if y % 8 == 0 or y % 8 == 1:
					c = Color(0.18, 0.19, 0.21)

			elif kind == "plastic_blue":
				var p_col = Color(0.14, 0.42, 0.68)
				if y >= 11 and y <= 19:
					p_col = Color(0.78, 0.82, 0.86)
					if y == 13 or y == 17:
						p_col = Color(0.75, 0.22, 0.18)
				elif y % 4 == 0:
					p_col = p_col.darkened(0.16)
				elif x % 6 == 0:
					p_col = p_col.lightened(0.10)
				c = p_col.lightened((h - 0.5) * 0.04)

			elif kind == "palm_leaf":
				var l_col = Color(0.17, 0.48, 0.20)
				if abs(x - sz / 2) <= 1:
					c = Color(0.36, 0.62, 0.24)
				elif (x + y) % 4 == 0 or (x - y + 64) % 4 == 0:
					c = l_col.darkened(0.16)
				else:
					c = l_col.lightened((h - 0.5) * 0.06)

			elif kind == "wood_crate":
				var cr_base = Color(0.48, 0.32, 0.16)
				var border = (x < 4 or x >= sz - 4 or y < 4 or y >= sz - 4)
				var diag = abs(x - y) <= 2 or abs(x - (sz - 1 - y)) <= 2
				if border or diag:
					c = Color(0.34, 0.22, 0.11).lightened((h - 0.5) * 0.05)
					if (x < 3 and y < 3) or (x >= sz - 3 and y < 3) or (x < 3 and y >= sz - 3) or (x >= sz - 3 and y >= sz - 3):
						c = Color(0.24, 0.26, 0.28)
				else:
					c = cr_base.darkened((0.18 if (y % 6 == 0) else ((h - 0.5) * 0.06)))

			elif kind == "sail_cloth":
				var sc_col = Color(0.76, 0.71, 0.60)
				var weave = ((x + y) % 2) * 0.03
				c = sc_col.darkened(weave + h * 0.04)
				if x % 8 == 0 or y % 8 == 0:
					c = sc_col.darkened(0.14)
				if x >= 20 and x <= 28 and y >= 18 and y <= 26:
					c = Color(0.58, 0.42, 0.26).darkened(weave)

			elif kind == "shark_skin":
				var sk = Color(0.22, 0.29, 0.38)
				var scale_pat = ((x * 3 + y * 5) % 4 == 0)
				c = sk.darkened(0.08 if scale_pat else 0.0).lightened((h - 0.5) * 0.05)

			elif kind == "shark_belly":
				var sb_col = Color(0.64, 0.69, 0.74)
				c = sb_col.lightened((h - 0.5) * 0.04)

			img.set_pixel(x, y, c)

	var tex = ImageTexture.create_from_image(img)
	_cache[key] = tex
	return tex


static func make_3d_mat(kind, uv_scale = Vector3(1, 1, 1), triplanar = false, metal = 0.0, rough = 0.85, tint = Color.WHITE):
	var m = StandardMaterial3D.new()
	m.albedo_texture = get_3d_tex(kind)
	m.albedo_color = tint
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	m.uv1_scale = uv_scale
	m.uv1_triplanar = triplanar
	m.metallic = metal
	m.roughness = rough
	return m


static func get_wood_panel_style(bg_col = Color(0.20, 0.13, 0.07, 0.96), border_col = Color(0.52, 0.34, 0.17, 1.0)):
	var key = "wood_panel_" + bg_col.to_html() + "_" + border_col.to_html()
	if _cache.has(key):
		return _cache[key]
	var img = Image.create(24, 24, false, Image.FORMAT_RGBA8)
	var dark_edge = Color(0.06, 0.03, 0.01, 0.98)
	var hi_edge = border_col.lightened(0.20)
	var sh_edge = border_col.darkened(0.28)
	var rivet = Color(0.64, 0.68, 0.72, 1.0)
	for y in range(24):
		for x in range(24):
			if (x == 0 or x == 23) and (y == 0 or y == 23):
				img.set_pixel(x, y, Color(0, 0, 0, 0))
				continue
			if x == 0 or x == 23 or y == 0 or y == 23:
				img.set_pixel(x, y, dark_edge)
			elif x == 1 or x == 22 or y == 1 or y == 22:
				if x == 1 or y == 1:
					img.set_pixel(x, y, hi_edge)
				else:
					img.set_pixel(x, y, sh_edge)
			elif x == 2 or x == 21 or y == 2 or y == 21:
				img.set_pixel(x, y, border_col)
			elif x == 3 or x == 20 or y == 3 or y == 20:
				img.set_pixel(x, y, dark_edge)
			else:
				var plank = floori(y / 5.0) % 2
				var grain = 0.035 * sin(float(x) * 0.9 + float(y) * 1.7)
				var c = bg_col.lightened(grain) if plank == 0 else bg_col.darkened(0.05 - grain)
				if y % 5 == 0:
					c = bg_col.darkened(0.14)
				img.set_pixel(x, y, c)
	for pt in [Vector2i(2, 2), Vector2i(21, 2), Vector2i(2, 21), Vector2i(21, 21)]:
		img.set_pixel(pt.x, pt.y, rivet)
	var tex = ImageTexture.create_from_image(img)
	var sb = StyleBoxTexture.new()
	sb.texture = tex
	sb.texture_margin_left = 6
	sb.texture_margin_right = 6
	sb.texture_margin_top = 6
	sb.texture_margin_bottom = 6
	_cache[key] = sb
	return sb


static func get_slot_style(selected = false, is_armor = false):
	var key = "mc_slot_" + ("sel" if selected else "norm") + ("_arm" if is_armor else "")
	if _cache.has(key):
		return _cache[key]
	var img = Image.create(20, 20, false, Image.FORMAT_RGBA8)
	var outer = Color(0.98, 0.86, 0.28, 1.0) if selected else Color(0.07, 0.04, 0.02, 0.96)
	var rim = Color(1.0, 0.94, 0.52, 1.0) if selected else (Color(0.32, 0.36, 0.42, 0.95) if is_armor else Color(0.38, 0.25, 0.14, 0.95))
	var top_in = Color(0.05, 0.03, 0.02, 0.95)
	var bot_in = Color(0.28, 0.19, 0.11, 0.95)
	var center_bg = Color(0.16, 0.12, 0.07, 0.94) if selected else (Color(0.10, 0.12, 0.15, 0.92) if is_armor else Color(0.11, 0.07, 0.04, 0.92))
	for y in range(20):
		for x in range(20):
			if x == 0 or x == 19 or y == 0 or y == 19:
				img.set_pixel(x, y, outer)
			elif x == 1 or x == 18 or y == 1 or y == 18:
				img.set_pixel(x, y, rim)
			elif x == 2 or y == 2:
				img.set_pixel(x, y, top_in)
			elif x == 17 or y == 17:
				img.set_pixel(x, y, bot_in)
			else:
				var checker = ((x + y) % 2 == 0)
				img.set_pixel(x, y, center_bg.lightened(0.015) if checker else center_bg.darkened(0.015))
	var sb = StyleBoxTexture.new()
	sb.texture = ImageTexture.create_from_image(img)
	sb.texture_margin_left = 4
	sb.texture_margin_right = 4
	sb.texture_margin_top = 4
	sb.texture_margin_bottom = 4
	_cache[key] = sb
	return sb


static func get_pixel_button_style(fill_col, border_col = Color(0.84, 0.70, 0.42, 0.95), pressed = false):
	var key = "btn_" + fill_col.to_html() + "_" + border_col.to_html() + ("_p" if pressed else "_n")
	if _cache.has(key):
		return _cache[key]
	var img = Image.create(20, 20, false, Image.FORMAT_RGBA8)
	var outline = Color(0.06, 0.04, 0.02, 0.96)
	var top_bevel = fill_col.darkened(0.22) if pressed else fill_col.lightened(0.22)
	var bot_bevel = fill_col.lightened(0.12) if pressed else fill_col.darkened(0.28)
	for y in range(20):
		for x in range(20):
			var d_corner = (x == 0 or x == 19) and (y <= 1 or y >= 18) or (y == 0 or y == 19) and (x <= 1 or x >= 18)
			if d_corner:
				img.set_pixel(x, y, Color(0, 0, 0, 0))
				continue
			if x == 0 or x == 19 or y == 0 or y == 19 or ((x == 1 or x == 18) and (y == 1 or y == 18)):
				img.set_pixel(x, y, outline)
			elif x == 1 or x == 18 or y == 1 or y == 18:
				img.set_pixel(x, y, border_col)
			elif y == 2 or x == 2:
				img.set_pixel(x, y, top_bevel)
			elif y == 17 or x == 17:
				img.set_pixel(x, y, bot_bevel)
			else:
				var checker = ((x + y) % 2 == 0)
				var c = fill_col.lightened(0.025) if checker else fill_col.darkened(0.025)
				img.set_pixel(x, y, c)
	var tex = ImageTexture.create_from_image(img)
	var sb = StyleBoxTexture.new()
	sb.texture = tex
	sb.texture_margin_left = 5
	sb.texture_margin_right = 5
	sb.texture_margin_top = 5
	sb.texture_margin_bottom = 5
	_cache[key] = sb
	return sb


static func get_bar_bg_style():
	if _cache.has("bar_bg"):
		return _cache["bar_bg"]
	var img = Image.create(16, 12, false, Image.FORMAT_RGBA8)
	var out = Color(0.05, 0.03, 0.02, 0.95)
	var rim = Color(0.46, 0.30, 0.15, 0.95)
	var bg = Color(0.09, 0.07, 0.06, 0.92)
	for y in range(12):
		for x in range(16):
			if (x == 0 or x == 15) and (y == 0 or y == 11):
				img.set_pixel(x, y, Color(0, 0, 0, 0))
			elif x == 0 or x == 15 or y == 0 or y == 11:
				img.set_pixel(x, y, out)
			elif x == 1 or x == 14 or y == 1 or y == 10:
				img.set_pixel(x, y, rim)
			else:
				img.set_pixel(x, y, bg)
	var sb = StyleBoxTexture.new()
	sb.texture = ImageTexture.create_from_image(img)
	sb.texture_margin_left = 3
	sb.texture_margin_right = 3
	sb.texture_margin_top = 3
	sb.texture_margin_bottom = 3
	_cache["bar_bg"] = sb
	return sb


static func get_bar_fill_style(col):
	var key = "bar_fill_" + col.to_html()
	if _cache.has(key):
		return _cache[key]
	var img = Image.create(12, 8, false, Image.FORMAT_RGBA8)
	var hi = col.lightened(0.26)
	var sh = col.darkened(0.28)
	for y in range(8):
		for x in range(12):
			var c = col
			if y <= 1:
				c = hi
			elif y >= 6:
				c = sh
			if x == 11:
				c = c.darkened(0.2)
			img.set_pixel(x, y, c)
	var sb = StyleBoxTexture.new()
	sb.texture = ImageTexture.create_from_image(img)
	sb.texture_margin_left = 2
	sb.texture_margin_right = 2
	sb.texture_margin_top = 2
	sb.texture_margin_bottom = 2
	_cache[key] = sb
	return sb


static func make_joy_ring_tex():
	if _cache.has("joy_ring"):
		return _cache["joy_ring"]
	var sz = 48
	var img = Image.create(sz, sz, false, Image.FORMAT_RGBA8)
	var center = Vector2(23.5, 23.5)
	for y in range(sz):
		for x in range(sz):
			var d = Vector2(x, y).distance_to(center)
			if d >= 21.0 and d <= 23.2:
				img.set_pixel(x, y, Color(0.08, 0.05, 0.02, 0.85))
			elif d >= 18.5 and d < 21.0:
				var c = Color(0.72, 0.50, 0.25, 0.72)
				if (x + y) % 4 == 0:
					c = c.lightened(0.18)
				img.set_pixel(x, y, c)
			elif d < 18.5:
				img.set_pixel(x, y, Color(0.08, 0.12, 0.18, 0.28))
			else:
				img.set_pixel(x, y, Color(0, 0, 0, 0))
	for i in range(3):
		img.set_pixel(23 + i - 1, 3, Color(0.92, 0.78, 0.42, 0.9))
		img.set_pixel(23 + i - 1, 44, Color(0.92, 0.78, 0.42, 0.9))
		img.set_pixel(3, 23 + i - 1, Color(0.92, 0.78, 0.42, 0.9))
		img.set_pixel(44, 23 + i - 1, Color(0.92, 0.78, 0.42, 0.9))
	var tex = ImageTexture.create_from_image(img)
	_cache["joy_ring"] = tex
	return tex


static func make_joy_knob_tex():
	if _cache.has("joy_knob"):
		return _cache["joy_knob"]
	var sz = 24
	var img = Image.create(sz, sz, false, Image.FORMAT_RGBA8)
	var center = Vector2(11.5, 11.5)
	for y in range(sz):
		for x in range(sz):
			var d = Vector2(x, y).distance_to(center)
			if d <= 10.8 and d >= 9.2:
				img.set_pixel(x, y, Color(0.08, 0.05, 0.02, 0.95))
			elif d < 9.2:
				var c = Color(0.82, 0.62, 0.32, 0.92)
				if y < 9 and x < 14:
					c = c.lightened(0.20)
				elif y > 14:
					c = c.darkened(0.2)
				img.set_pixel(x, y, c)
			else:
				img.set_pixel(x, y, Color(0, 0, 0, 0))
	var tex = ImageTexture.create_from_image(img)
	_cache["joy_knob"] = tex
	return tex


static func get_icon(id):
	var key = "icon_" + id
	if _cache.has(key):
		return _cache[key]
	var patterns = {
		"heart": [
			"................",
			"..####....####..",
			".######..######.",
			"################",
			"###@@###########",
			"##@#############",
			"################",
			".##############.",
			"..############..",
			"...##########...",
			"....########....",
			".....######.....",
			"......####......",
			".......##.......",
			"................",
			"................",
		],
		"hunger": [
			"..........####..",
			".........######.",
			"........#######.",
			".......########.",
			"......#########.",
			".....#########..",
			"....#########...",
			"....########....",
			"....#######.....",
			"...@@@###.......",
			"..@@@@@.........",
			".@@@.@@@........",
			"@@@...@@........",
			".@..............",
			"................",
			"................",
		],
		"thirst": [
			".......##.......",
			"......####......",
			"......####......",
			".....######.....",
			"....########....",
			"....########....",
			"...##########...",
			"..###@@#######..",
			"..##@@########..",
			"..##@@########..",
			"..###@@#######..",
			"...##########...",
			"....########....",
			".....######.....",
			"................",
			"................",
		],
		"hook": [
			"......####......",
			".....##..##.....",
			"..........##....",
			"....##....##....",
			"...##....##.....",
			"........##......",
			".......##..##...",
			"......##..##....",
			".....@@@.##.....",
			"....@@@.........",
			"...@@@..........",
			"..@@@...........",
			".@@@............",
			"@@@.............",
			"................",
			"................",
		],
		"spear": [
			".............###",
			"............####",
			"...........#####",
			"..........#####.",
			".........###@@..",
			"........@@@.#...",
			".......@@@......",
			"......@@@.......",
			".....@@@........",
			"....@@@.........",
			"...@@@..........",
			"..@@@...........",
			".@@@............",
			"@@@.............",
			"@@..............",
			"................",
		],
		"rod": [
			"...........###..",
			"..........###.#.",
			".........###..#.",
			"........###...#.",
			".......###....#.",
			"......###.....#.",
			".....###......#.",
			"....###......@@@",
			"...###.......###",
			"..###...........",
			".###............",
			"###.............",
			"##..............",
			"................",
			"................",
			"................",
		],
		"hammer": [
			"....########....",
			"...##########...",
			"...##########...",
			"....########....",
			".......@@.......",
			".......@@.......",
			".......@@.......",
			".......@@.......",
			".......@@.......",
			".......@@.......",
			".......@@.......",
			".......@@.......",
			"......@@@@......",
			"......@@@@......",
			"................",
			"................",
		],
		"bag": [
			".....######.....",
			"....##....##....",
			"...##########...",
			"..############..",
			"..############..",
			"..###@@@@@@###..",
			"..###@@##@@###..",
			"..############..",
			"..############..",
			"..############..",
			"..############..",
			"...##########...",
			"................",
			"................",
			"................",
			"................",
		],
		"settings": [
			"......####......",
			"..##..####..##..",
			".##############.",
			".####......####.",
			"..##..####..##..",
			"#####.####.#####",
			"####........####",
			"#####.####.#####",
			"..##..####..##..",
			".####......####.",
			".##############.",
			"..##..####..##..",
			"......####......",
			"................",
			"................",
			"................",
		],
		"jump": [
			".......##.......",
			"......####......",
			".....######.....",
			"....########....",
			"...###.##.###...",
			"......####......",
			"......####......",
			"......####......",
			"......####......",
			"....########....",
			"...##########...",
			"................",
			"..@@@@@@@@@@@@..",
			".@@@@@@@@@@@@@@.",
			"................",
			"................",
		],
		"wood": [
			"................",
			"..############..",
			".##############.",
			".###@@@##@@@###.",
			"..############..",
			"................",
			"...############.",
			"..##############",
			"..###@@@##@@@###",
			"...############.",
			"................",
			"..############..",
			".##############.",
			"..############..",
			"................",
			"................",
		],
		"foundation": [
			".##############.",
			"################",
			"##@@@######@@@##",
			"################",
			".##############.",
			"################",
			"##@@@######@@@##",
			"################",
			".##############.",
			"################",
			"##@@@######@@@##",
			"################",
			".##############.",
			"................",
			"................",
			"................",
		],
		"plastic": [
			"......@@@@......",
			"......@@@@......",
			".....######.....",
			"....########....",
			"....########....",
			"....@@@@@@@@....",
			"....@@@@@@@@....",
			"....########....",
			"....########....",
			"....########....",
			"....########....",
			".....######.....",
			"................",
			"................",
			"................",
			"................",
		],
		"scrap": [
			"....########....",
			"..############..",
			".####..##..####.",
			".###...##...###.",
			"#####@@@@@@#####",
			"####@@@@@@@@####",
			".###..@@@@..###.",
			"..###......###..",
			"...##########...",
			"....########....",
			"................",
			"................",
			"................",
			"................",
			"................",
			"................",
		],
		"leaf": [
			"...........###..",
			".........#####..",
			".......#######..",
			"......########..",
			".....#####@@##..",
			"....#####@@###..",
			"...#####@@###...",
			"...####@@###....",
			"..####@@###.....",
			"..###@@###......",
			"...#@@###.......",
			"...@@###........",
			"..@@............",
			".@@.............",
			"................",
			"................",
		],
		"rope": [
			"....########....",
			"..############..",
			".####@@@@@@####.",
			".###@@....@@###.",
			".###@..##..@###.",
			".###@..##..@###.",
			".###@@....@@###.",
			".####@@@@@@####.",
			"..############..",
			"....########....",
			".......###......",
			"......###.......",
			".....###........",
			"................",
			"................",
			"................",
		],
		"coconut": [
			".......@@@......",
			".....@@@@@@.....",
			"....########....",
			"...##########...",
			"..####@@@#####..",
			"..###@@@@#####..",
			"..############..",
			"..############..",
			"...##########...",
			"....########....",
			".....######.....",
			"................",
			"................",
			"................",
			"................",
			"................",
		],
		"can": [
			"....@@@@@@@@....",
			"...##########...",
			"...##########...",
			"...@@@@@@@@@@...",
			"...@@@@@@@@@@...",
			"...@@@@@@@@@@...",
			"...##########...",
			"...##########...",
			"...##########...",
			"....@@@@@@@@....",
			"................",
			"................",
			"................",
			"................",
			"................",
			"................",
		],
		"fish": [
			"................",
			"......#####.....",
			"....#########...",
			"...###@@######.#",
			"..############@@",
			"..#############@",
			"...##########.##",
			"....########...#",
			"......####......",
			"................",
			"................",
			"................",
			"................",
			"................",
			"................",
			"................",
		],
		"leaf_hat": [
			".....######.....",
			"...##########...",
			"..############..",
			"..###@@@@@@###..",
			".##############.",
			"################",
			"@@@##########@@@",
			"................",
			"................",
			"................",
			"................",
			"................",
			"................",
			"................",
			"................",
			"................",
		],
		"wood_vest": [
			"..####....####..",
			".######..######.",
			".##############.",
			"..############..",
			"..###@@@@@@###..",
			"..############..",
			"..###@@@@@@###..",
			"..############..",
			"..############..",
			"...##########...",
			"................",
			"................",
			"................",
			"................",
			"................",
			"................",
		],
		"rope_legs": [
			"...##########...",
			"...@@@@@@@@@@...",
			"...##########...",
			"...####..####...",
			"...####..####...",
			"...###....###...",
			"...###....###...",
			"...@@@....@@@...",
			"...###....###...",
			"...###....###...",
			"................",
			"................",
			"................",
			"................",
			"................",
			"................",
		],
		"scrap_boots": [
			"................",
			"................",
			"...####..####...",
			"...####..####...",
			"...####..####...",
			"...@@@@..@@@@...",
			"..#####..#####..",
			".######..######.",
			".@@@@@@..@@@@@@.",
			"................",
			"................",
			"................",
			"................",
			"................",
			"................",
			"................",
		],
	}
	var p_col = Color(0.92, 0.85, 0.72)
	var s_col = Color(0.98, 0.96, 0.9)
	match id:
		"heart":
			p_col = Color(0.90, 0.22, 0.24)
			s_col = Color(1.0, 0.75, 0.78)
		"hunger", "meat", "cooked_meat":
			p_col = Color(0.86, 0.48, 0.18)
			s_col = Color(0.95, 0.90, 0.80)
		"thirst", "water", "purifier":
			p_col = Color(0.24, 0.66, 0.96)
			s_col = Color(0.82, 0.95, 1.0)
		"hook":
			p_col = Color(0.76, 0.82, 0.88)
			s_col = Color(0.72, 0.50, 0.25)
		"spear":
			p_col = Color(0.80, 0.84, 0.90)
			s_col = Color(0.65, 0.42, 0.20)
		"rod":
			p_col = Color(0.70, 0.46, 0.22)
			s_col = Color(0.92, 0.25, 0.25)
		"hammer", "foundation", "wood":
			p_col = Color(0.68, 0.45, 0.22)
			s_col = Color(0.48, 0.31, 0.14)
		"bag":
			p_col = Color(0.74, 0.52, 0.26)
			s_col = Color(0.95, 0.82, 0.35)
		"settings", "scrap":
			p_col = Color(0.70, 0.74, 0.80)
			s_col = Color(0.42, 0.45, 0.52)
		"jump":
			p_col = Color(0.35, 0.85, 0.46)
			s_col = Color(0.76, 0.54, 0.28)
		"plastic":
			p_col = Color(0.28, 0.64, 0.88)
			s_col = Color(0.90, 0.26, 0.22)
		"leaf", "leaf_hat":
			p_col = Color(0.26, 0.72, 0.30)
			s_col = Color(0.68, 0.54, 0.28)
		"rope", "rope_legs":
			p_col = Color(0.78, 0.64, 0.36)
			s_col = Color(0.52, 0.38, 0.20)
		"coconut":
			p_col = Color(0.48, 0.30, 0.15)
			s_col = Color(0.92, 0.90, 0.82)
		"can", "grill":
			p_col = Color(0.72, 0.75, 0.78)
			s_col = Color(0.86, 0.26, 0.20)
		"fish":
			p_col = Color(0.42, 0.72, 0.88)
			s_col = Color(0.88, 0.94, 0.98)
		"cooked_fish":
			p_col = Color(0.84, 0.54, 0.20)
			s_col = Color(0.98, 0.82, 0.46)
		"wood_vest":
			p_col = Color(0.62, 0.40, 0.20)
			s_col = Color(0.82, 0.68, 0.38)
		"scrap_boots":
			p_col = Color(0.56, 0.62, 0.68)
			s_col = Color(0.24, 0.48, 0.74)
		"slot_head", "slot_chest", "slot_legs", "slot_feet":
			p_col = Color(0.32, 0.36, 0.42, 0.55)
			s_col = Color(0.24, 0.28, 0.34, 0.55)

	var pat_key = id
	if id == "cooked_fish":
		pat_key = "fish"
	elif id in ["meat", "cooked_meat"]:
		pat_key = "hunger"
	elif id == "water" or id == "purifier":
		pat_key = "thirst"
	elif id == "grill":
		pat_key = "can"
	elif id == "lantern":
		pat_key = "scrap"
	elif id == "slot_head":
		pat_key = "leaf_hat"
	elif id == "slot_chest":
		pat_key = "wood_vest"
	elif id == "slot_legs":
		pat_key = "rope_legs"
	elif id == "slot_feet":
		pat_key = "scrap_boots"

	var grid = patterns.get(pat_key, patterns["wood"])
	var img = Image.create(16, 16, false, Image.FORMAT_RGBA8)
	for y in range(16):
		var row = grid[y]
		for x in range(16):
			var ch = row[x]
			if ch == "#":
				img.set_pixel(x, y, p_col)
			elif ch == "@":
				img.set_pixel(x, y, s_col)
			else:
				img.set_pixel(x, y, Color(0, 0, 0, 0))
	var out = Image.create(16, 16, false, Image.FORMAT_RGBA8)
	for y in range(16):
		for x in range(16):
			var c = img.get_pixel(x, y)
			if c.a > 0.1:
				out.set_pixel(x, y, c)
			else:
				var near = false
				for dy in [-1, 0, 1]:
					for dx in [-1, 0, 1]:
						var nx = x + dx
						var ny = y + dy
						if nx >= 0 and nx < 16 and ny >= 0 and ny < 16:
							if img.get_pixel(nx, ny).a > 0.1:
								near = true
				if near:
					out.set_pixel(x, y, Color(0.05, 0.03, 0.02, 0.85))
				else:
					out.set_pixel(x, y, Color(0, 0, 0, 0))
	var tex = ImageTexture.create_from_image(out)
	_cache[key] = tex
	return tex
