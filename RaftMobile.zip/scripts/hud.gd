extends CanvasLayer

const PixelUI = preload("res://scripts/pixel_ui.gd")

var player
var main_node
var root
var status_panel
var bar_fills = {}
var bar_pcts = {}
var day_label
var fps_label

var btns = {}
var btn_labels = {}
var btn_icons = {}
var btn_colors = {}
var held = {}

var joy_finger = -1
var look_finger = -1
var joy_center = Vector2.ZERO
var joy_home = Vector2(190, 530)
var joy_vec = Vector2.ZERO
var vp = Vector2(1280, 720)
var joy_base
var joy_knob

var cross_box
var cross_h
var cross_v
var aim_label
var charge_bg
var charge_fill
var charge_label

var hotbar_panel
var hotbar_box
var msg_label
var msg_t = 0.0
var mode_banner
var mode_label

var menu
var inv_box
var rec_box
var settings_modal
var settings_tab_box
var settings_content_box
var current_settings_tab = "gfx"

var hud_edit_mode = false
var hud_edit_bar = null
var hud_edit_selected = "hook"
var hud_edit_dragging = false
var hud_edit_drag_offset = Vector2.ZERO
var hud_edit_info_lbl = null

var death_panel

const JOY_R = 86.0


func _ready():
	layer = 10
	root = Control.new()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(root)

	_build_status_hud()
	_build_joystick_and_crosshair()
	_build_action_buttons()
	_build_hotbar()
	_build_messages()
	_build_bag_menu()
	_build_settings_modal()
	_build_hud_editor_bar()
	_build_death()

	get_viewport().size_changed.connect(_layout)
	_layout()

	Game.stats_changed.connect(_on_stats)
	Game.inventory_changed.connect(_on_inventory_changed)
	Game.message.connect(show_message)
	Game.player_died.connect(_on_died)
	Game.settings_changed.connect(_on_settings_updated)

	_on_stats()
	_refresh_hotbar()
	show_message("Tahan & Lepas HOOK untuk melempar kail ke sampah laut! Tekan SETELAN untuk Grafik & Custom HUD.")


func _style_pixel_label(lbl, fsize, col = Color(0.98, 0.95, 0.86), outline = 5):
	lbl.add_theme_font_size_override("font_size", fsize)
	lbl.add_theme_color_override("font_color", col)
	lbl.add_theme_color_override("font_outline_color", Color(0.06, 0.03, 0.01, 1.0))
	lbl.add_theme_constant_override("outline_size", outline)


func _build_status_hud():
	status_panel = Panel.new()
	status_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	status_panel.position = Vector2(16, 14)
	status_panel.size = Vector2(288, 134)
	status_panel.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.18, 0.11, 0.06, 0.92)))
	root.add_child(status_panel)

	day_label = Label.new()
	day_label.text = "HARI 1  |  SIANG"
	day_label.position = Vector2(12, 8)
	day_label.size = Vector2(180, 22)
	day_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(day_label, 14, Color(0.98, 0.86, 0.45), 4)
	status_panel.add_child(day_label)

	fps_label = Label.new()
	fps_label.text = "60 FPS"
	fps_label.position = Vector2(200, 8)
	fps_label.size = Vector2(76, 22)
	fps_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	fps_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(fps_label, 13, Color(0.45, 0.95, 0.55), 4)
	status_panel.add_child(fps_label)

	_make_bar("health", "NYAWA", "heart", Color(0.88, 0.22, 0.22), 34)
	_make_bar("hunger", "LAPAR", "hunger", Color(0.90, 0.56, 0.16), 66)
	_make_bar("thirst", "HAUS", "thirst", Color(0.22, 0.64, 0.96), 98)


func _make_bar(key, title, icon_id, color, y):
	var ic = TextureRect.new()
	ic.texture = PixelUI.get_icon(icon_id)
	ic.stretch_mode = TextureRect.STRETCH_SCALE
	ic.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	ic.position = Vector2(10, y + 1)
	ic.size = Vector2(24, 24)
	ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	status_panel.add_child(ic)

	var bg = Panel.new()
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.position = Vector2(38, y)
	bg.size = Vector2(238, 26)
	bg.add_theme_stylebox_override("panel", PixelUI.get_bar_bg_style())
	status_panel.add_child(bg)

	var fill = Panel.new()
	fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fill.position = Vector2(3, 3)
	fill.size = Vector2(232, 20)
	fill.add_theme_stylebox_override("panel", PixelUI.get_bar_fill_style(color))
	bg.add_child(fill)

	var lb = Label.new()
	lb.text = title
	lb.position = Vector2(8, 2)
	lb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(lb, 13, Color(1, 0.98, 0.92), 4)
	bg.add_child(lb)

	var pct = Label.new()
	pct.text = "100%"
	pct.position = Vector2(170, 2)
	pct.size = Vector2(60, 20)
	pct.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	pct.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(pct, 13, Color(1, 0.98, 0.88), 4)
	bg.add_child(pct)

	bar_fills[key] = fill
	bar_pcts[key] = pct


func _build_joystick_and_crosshair():
	joy_base = TextureRect.new()
	joy_base.texture = PixelUI.make_joy_ring_tex()
	joy_base.stretch_mode = TextureRect.STRETCH_SCALE
	joy_base.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	joy_base.size = Vector2(JOY_R * 2.0, JOY_R * 2.0)
	joy_base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(joy_base)

	joy_knob = TextureRect.new()
	joy_knob.texture = PixelUI.make_joy_knob_tex()
	joy_knob.stretch_mode = TextureRect.STRETCH_SCALE
	joy_knob.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	joy_knob.size = Vector2(72.0, 72.0)
	joy_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(joy_knob)

	cross_box = Control.new()
	cross_box.size = Vector2(24, 24)
	cross_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(cross_box)

	cross_h = ColorRect.new()
	cross_h.color = Color(0.98, 0.95, 0.82, 0.92)
	cross_h.position = Vector2(3, 10)
	cross_h.size = Vector2(18, 4)
	cross_h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cross_box.add_child(cross_h)

	cross_v = ColorRect.new()
	cross_v.color = Color(0.98, 0.95, 0.82, 0.92)
	cross_v.position = Vector2(10, 3)
	cross_v.size = Vector2(4, 18)
	cross_v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cross_box.add_child(cross_v)

	aim_label = Label.new()
	aim_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	aim_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(aim_label, 15, Color(0.55, 1.0, 0.62), 5)
	root.add_child(aim_label)

	charge_bg = Panel.new()
	charge_bg.size = Vector2(164, 20)
	charge_bg.visible = false
	charge_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	charge_bg.add_theme_stylebox_override("panel", PixelUI.get_bar_bg_style())
	root.add_child(charge_bg)

	charge_fill = Panel.new()
	charge_fill.position = Vector2(3, 3)
	charge_fill.size = Vector2(158, 14)
	charge_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	charge_fill.add_theme_stylebox_override("panel", PixelUI.get_bar_fill_style(Color(0.25, 0.88, 0.45)))
	charge_bg.add_child(charge_fill)

	charge_label = Label.new()
	charge_label.text = "DAYA LEMPAR"
	charge_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	charge_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	charge_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	charge_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(charge_label, 11, Color(1, 1, 0.9), 3)
	charge_bg.add_child(charge_label)


func _build_action_buttons():
	_make_button("hook", "HOOK", "hook", Color(0.16, 0.48, 0.28, 0.92), 16)
	_make_button("attack", "SERANG", "spear", Color(0.62, 0.20, 0.16, 0.92), 15)
	_make_button("jump", "LOMPAT", "jump", Color(0.24, 0.34, 0.46, 0.92), 15)
	_make_button("fish", "PANCING", "rod", Color(0.16, 0.38, 0.62, 0.92), 14)
	_make_button("place", "PASANG", "hammer", Color(0.76, 0.52, 0.12, 0.96), 16)
	_make_button("bag", "TAS", "bag", Color(0.36, 0.24, 0.14, 0.94), 16)
	_make_button("build", "BANGUN", "hammer", Color(0.32, 0.26, 0.18, 0.94), 15)
	_make_button("settings", "SETELAN", "settings", Color(0.22, 0.28, 0.36, 0.94), 14)
	btns["place"].visible = false


func _make_button(id, text, icon_id, color, fsize):
	var p = Panel.new()
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_theme_stylebox_override("panel", PixelUI.get_pixel_button_style(color))
	btn_colors[id] = color

	var ic = TextureRect.new()
	ic.texture = PixelUI.get_icon(icon_id)
	ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	ic.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ic.position = Vector2(0, 8)
	p.add_child(ic)

	var l = Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(l, fsize, Color(0.99, 0.95, 0.84), 5)
	p.add_child(l)

	root.add_child(p)
	btns[id] = p
	btn_labels[id] = l
	btn_icons[id] = ic


func _build_hotbar():
	hotbar_panel = Panel.new()
	hotbar_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hotbar_panel.size = Vector2(450, 66)
	hotbar_panel.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.16, 0.10, 0.05, 0.90)))
	root.add_child(hotbar_panel)

	hotbar_box = HBoxContainer.new()
	hotbar_box.position = Vector2(10, 7)
	hotbar_box.size = Vector2(430, 52)
	hotbar_box.alignment = BoxContainer.ALIGNMENT_CENTER
	hotbar_box.mouse_filter = Control.MOUSE_FILTER_PASS
	hotbar_box.add_theme_constant_override("separation", 8)
	hotbar_panel.add_child(hotbar_box)


func _refresh_hotbar():
	if hotbar_box == null:
		return
	for c in hotbar_box.get_children():
		c.queue_free()

	var quick_ids = ["water", "coconut", "cooked_fish", "cooked_meat", "can", "fish", "wood", "plastic"]
	var shown = 0
	for id in quick_ids:
		var cnt = Game.count(id)
		if cnt <= 0 and id not in ["wood", "plastic", "water"]:
			continue
		if shown >= 6:
			break
		shown += 1
		var slot = Button.new()
		slot.custom_minimum_size = Vector2(64, 50)
		slot.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.24, 0.16, 0.09, 0.92)))
		slot.add_theme_stylebox_override("hover", PixelUI.get_pixel_button_style(Color(0.32, 0.22, 0.12, 0.95)))
		slot.add_theme_stylebox_override("pressed", PixelUI.get_pixel_button_style(Color(0.18, 0.12, 0.06, 0.95), Color(0.95, 0.8, 0.4), true))

		var icon_id = id
		if id in ["cooked_fish", "fish", "cooked_meat", "meat", "can", "coconut"]:
			icon_id = "hunger"
		var ic = TextureRect.new()
		ic.texture = PixelUI.get_icon(icon_id)
		ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		ic.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		ic.position = Vector2(6, 6)
		ic.size = Vector2(22, 22)
		ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
		slot.add_child(ic)

		var nm_lbl = Label.new()
		var short_nm = Game.ITEM_NAMES.get(id, id).split(" ")[0]
		nm_lbl.text = "%s\nx%d" % [short_nm, cnt]
		nm_lbl.position = Vector2(2, 4)
		nm_lbl.size = Vector2(60, 44)
		nm_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		nm_lbl.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
		nm_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_style_pixel_label(nm_lbl, 11, Color(0.98, 0.94, 0.82), 3)
		slot.add_child(nm_lbl)

		if Game.USABLE.has(id) and cnt > 0:
			slot.pressed.connect(Game.use_item.bind(id))
		else:
			slot.pressed.connect(open_menu)
		hotbar_box.add_child(slot)


func _build_messages():
	msg_label = Label.new()
	msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(msg_label, 20, Color(1.0, 0.96, 0.82), 7)
	msg_label.modulate.a = 0.0
	root.add_child(msg_label)

	# Prominent Pixel-Art Build Mode Active Banner
	mode_banner = Panel.new()
	mode_banner.size = Vector2(540, 42)
	mode_banner.visible = false
	mode_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mode_banner.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.14, 0.36, 0.18, 0.95), Color(0.45, 0.95, 0.52, 1.0)))
	root.add_child(mode_banner)

	mode_label = Label.new()
	mode_label.text = "[MODE BANGUN AKTIF] Arahkan + ke samping rakit (Hijau) lalu tekan PASANG"
	mode_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mode_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	mode_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mode_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(mode_label, 14, Color(0.75, 1.0, 0.78), 5)
	mode_banner.add_child(mode_label)


func _place_btn(id, default_pos, default_sz):
	var g_scale = clamp(float(Game.settings.get("hud_scale", 1.0)), 0.65, 1.45)
	var custom = Game.settings.get("custom_hud", {})
	var pos = default_pos
	var item_scale = g_scale
	if custom.has(id):
		var data = custom[id]
		if data.has("rx") and data.has("ry"):
			pos = Vector2(float(data["rx"]) * vp.x, float(data["ry"]) * vp.y)
		if data.has("scale"):
			item_scale = clamp(float(data["scale"]), 0.6, 1.55)
	var sz = default_sz * item_scale
	pos.x = clamp(pos.x, 4.0, max(4.0, vp.x - sz.x - 4.0))
	pos.y = clamp(pos.y, 4.0, max(4.0, vp.y - sz.y - 4.0))

	var b = btns[id]
	b.position = pos
	b.size = sz
	var ic = btn_icons[id]
	ic.position = Vector2(sz.x * 0.22, sz.y * 0.08)
	ic.size = Vector2(sz.x * 0.56, sz.y * 0.48)
	var lb = btn_labels[id]
	lb.position = Vector2(2, sz.y * 0.54)
	lb.size = Vector2(sz.x - 4, sz.y * 0.40)


func _layout():
	vp = get_viewport().get_visible_rect().size
	var W = vp.x
	var H = vp.y
	root.size = vp

	_place_btn("hook", Vector2(W - 295, H - 142), Vector2(118, 114))
	_place_btn("jump", Vector2(W - 148, H - 142), Vector2(114, 114))
	_place_btn("attack", Vector2(W - 148, H - 278), Vector2(114, 114))
	_place_btn("fish", Vector2(W - 295, H - 278), Vector2(114, 114))
	_place_btn("place", Vector2(W - 445, H - 142), Vector2(128, 114))
	_place_btn("bag", Vector2(W - 140, 14), Vector2(122, 64))
	_place_btn("build", Vector2(W - 274, 14), Vector2(122, 64))
	_place_btn("settings", Vector2(W - 408, 14), Vector2(122, 64))

	var custom = Game.settings.get("custom_hud", {})
	joy_home = Vector2(185, H - 185)
	if custom.has("joystick"):
		var jd = custom["joystick"]
		if jd.has("rx") and jd.has("ry"):
			joy_home = Vector2(float(jd["rx"]) * W, float(jd["ry"]) * H)
	_joy_idle()

	if custom.has("status_panel"):
		var sd = custom["status_panel"]
		if sd.has("rx") and sd.has("ry"):
			status_panel.position = Vector2(float(sd["rx"]) * W, float(sd["ry"]) * H)
	else:
		status_panel.position = Vector2(16, 14)

	hotbar_panel.position = Vector2(W / 2.0 - hotbar_panel.size.x / 2.0, H - 76)
	cross_box.position = vp / 2.0 - Vector2(12, 12)
	aim_label.position = Vector2(W / 2.0 - 200, H / 2.0 + 18)
	aim_label.size = Vector2(400, 26)
	charge_bg.position = Vector2(W / 2.0 - 82, H / 2.0 + 46)

	mode_banner.position = Vector2(W / 2.0 - mode_banner.size.x / 2.0, 86)
	msg_label.position = Vector2(W / 2.0 - 410, 134)
	msg_label.size = Vector2(820, 42)

	menu.position = (vp - menu.size) / 2.0
	settings_modal.position = (vp - settings_modal.size) / 2.0
	if hud_edit_bar != null:
		hud_edit_bar.position = Vector2(W / 2.0 - hud_edit_bar.size.x / 2.0, 12)
	death_panel.position = (vp - death_panel.size) / 2.0
	_apply_hud_opacity()


func _apply_hud_opacity():
	var op = clamp(float(Game.settings.get("hud_opacity", 0.92)), 0.30, 1.0)
	for id in btns:
		btns[id].modulate.a = op
	joy_base.modulate.a = op
	joy_knob.modulate.a = op
	status_panel.modulate.a = op
	hotbar_panel.modulate.a = op


func _on_settings_updated():
	if fps_label != null:
		fps_label.visible = bool(Game.settings.get("show_fps", true))
	_layout()


func _joy_idle():
	joy_base.position = joy_home - Vector2(JOY_R, JOY_R)
	joy_knob.position = joy_home - Vector2(36, 36)


func _on_stats():
	var h = clamp(Game.health, 0.0, 100.0)
	var hu = clamp(Game.hunger, 0.0, 100.0)
	var th = clamp(Game.thirst, 0.0, 100.0)
	bar_fills["health"].size.x = 232.0 * (h / 100.0)
	bar_fills["hunger"].size.x = 232.0 * (hu / 100.0)
	bar_fills["thirst"].size.x = 232.0 * (th / 100.0)
	bar_pcts["health"].text = "%d%%" % int(round(h))
	bar_pcts["hunger"].text = "%d%%" % int(round(hu))
	bar_pcts["thirst"].text = "%d%%" % int(round(th))

	var tod = Game.time_of_day
	var phase_txt = "MALAM"
	if tod >= 0.22 and tod < 0.35:
		phase_txt = "PAGI"
	elif tod >= 0.35 and tod < 0.68:
		phase_txt = "SIANG"
	elif tod >= 0.68 and tod < 0.80:
		phase_txt = "SENJA"
	day_label.text = "HARI %d  |  %s" % [Game.day_count, phase_txt]


func _on_inventory_changed():
	_refresh_menu()
	_refresh_hotbar()


func show_message(t):
	msg_label.text = t
	msg_label.modulate.a = 1.0
	msg_t = 3.2


func set_build_mode(on):
	btns["place"].visible = on
	mode_banner.visible = on
	if on:
		btn_labels["build"].text = "BATAL [X]"
		btns["build"].add_theme_stylebox_override("panel", PixelUI.get_pixel_button_style(Color(0.20, 0.62, 0.28, 0.98), Color(0.98, 0.90, 0.35, 1.0), true))
	else:
		btn_labels["build"].text = "BANGUN"
		btns["build"].add_theme_stylebox_override("panel", PixelUI.get_pixel_button_style(btn_colors["build"]))


func _process(delta):
	if msg_t > 0.0:
		msg_t -= delta
		msg_label.modulate.a = clamp(msg_t, 0.0, 1.0)
	if fps_label != null and fps_label.visible:
		fps_label.text = "%d FPS" % Engine.get_frames_per_second()
	if player == null:
		return

	if player.fishing:
		btn_labels["fish"].text = "BATAL"
		btns["fish"].add_theme_stylebox_override("panel", PixelUI.get_pixel_button_style(Color(0.65, 0.28, 0.16, 0.95), Color(1.0, 0.85, 0.35, 1.0), true))
	else:
		btn_labels["fish"].text = "PANCING"
		btns["fish"].add_theme_stylebox_override("panel", PixelUI.get_pixel_button_style(btn_colors["fish"]))

	if player.hook_state == player.HookState.CHARGING:
		btn_labels["hook"].text = "LEPAS!"
		charge_bg.visible = true
		charge_fill.size.x = 158.0 * clamp(player.hook_charge, 0.0, 1.0)
		charge_label.text = "DAYA LEMPAR %d%%" % int(round(player.hook_charge * 100.0))
	elif player.hook_state == player.HookState.FLYING or player.hook_state == player.HookState.REELING:
		btn_labels["hook"].text = "TARIK!"
		charge_bg.visible = true
		var d = 0.0
		if player.hook_proj != null:
			d = player.hook_proj.global_position.distance_to(player.global_position)
		var pct = clamp(1.0 - (d / 29.0), 0.05, 1.0)
		charge_fill.size.x = 158.0 * pct
		if player.snagged_items.size() > 0:
			charge_label.text = "MENARIK %d BARANG..." % player.snagged_items.size()
		else:
			charge_label.text = "MENARIK KAIL (%dm)" % int(d)
	else:
		btn_labels["hook"].text = "HOOK"
		charge_bg.visible = false
		for k in held.keys():
			if held[k] == "hook":
				held.erase(k)

	var aim_info = player.get_aim_target_text()
	aim_label.text = aim_info["text"]
	if aim_info["type"] == "debris":
		cross_h.color = Color(0.32, 1.0, 0.48, 0.95)
		cross_v.color = Color(0.32, 1.0, 0.48, 0.95)
		aim_label.add_theme_color_override("font_color", Color(0.45, 1.0, 0.58))
	elif aim_info["type"] == "shark":
		cross_h.color = Color(1.0, 0.25, 0.22, 0.95)
		cross_v.color = Color(1.0, 0.25, 0.22, 0.95)
		aim_label.add_theme_color_override("font_color", Color(1.0, 0.38, 0.35))
	else:
		cross_h.color = Color(0.98, 0.95, 0.82, 0.90)
		cross_v.color = Color(0.98, 0.95, 0.82, 0.90)


# ---------- Input Sentuh & Custom HUD Drag Editor ----------

func _hit_control(ctrl, raw_pos):
	if ctrl == null or not ctrl.visible:
		return false
	var r = Rect2(ctrl.position, ctrl.size).grow(6.0)
	if r.has_point(raw_pos):
		return true
	var c_pos = root.get_global_transform_with_canvas().affine_inverse() * raw_pos
	return r.has_point(c_pos)


func _input(event):
	if hud_edit_mode:
		_handle_hud_editor_input(event)
		return
	if Game.dead:
		return
	if Game.menu_open:
		if event is InputEventScreenTouch and event.pressed:
			if _hit_control(btns["bag"], event.position):
				if menu.visible:
					close_menu()
				else:
					open_menu()
				get_viewport().set_input_as_handled()
				return
			if _hit_control(btns["settings"], event.position):
				if settings_modal.visible:
					close_settings()
				else:
					open_settings()
				get_viewport().set_input_as_handled()
				return
		return

	if event is InputEventScreenTouch:
		if event.pressed:
			_touch_down(event.index, event.position)
		else:
			_touch_up(event.index)
	elif event is InputEventScreenDrag:
		_touch_drag(event.index, event.position, event.relative)


func _touch_down(idx, pos):
	if _hit_control(hotbar_panel, pos):
		return
	for id in ["bag", "settings", "build", "place", "hook", "attack", "jump", "fish"]:
		var b = btns[id]
		if _hit_control(b, pos):
			held[idx] = id
			_press(id)
			if id in ["bag", "settings", "build", "place"]:
				get_viewport().set_input_as_handled()
			return
	if pos.x < vp.x * 0.45 and joy_finger == -1:
		joy_finger = idx
		joy_center = pos
		joy_vec = Vector2.ZERO
		joy_base.position = pos - Vector2(JOY_R, JOY_R)
		joy_knob.position = pos - Vector2(36, 36)
	elif look_finger == -1 and pos.x >= vp.x * 0.28:
		look_finger = idx


func _touch_up(idx):
	if held.has(idx):
		var id = held[idx]
		if id == "jump":
			player.jump_held = false
		elif id == "hook":
			player.release_hook_action()
		held.erase(idx)
	if idx == joy_finger:
		joy_finger = -1
		joy_vec = Vector2.ZERO
		player.move_input = Vector2.ZERO
		_joy_idle()
	if idx == look_finger:
		look_finger = -1


func _touch_drag(idx, pos, rel):
	if idx == joy_finger:
		var v = pos - joy_center
		if v.length() > JOY_R:
			v = v.normalized() * JOY_R
		joy_vec = v / JOY_R
		var out = joy_vec
		if out.length() < 0.12:
			out = Vector2.ZERO
		player.move_input = out
		joy_knob.position = joy_base.position + Vector2(JOY_R, JOY_R) - Vector2(36, 36) + v
	elif idx == look_finger:
		player.look_delta += rel


func _press(id):
	match id:
		"jump":
			player.jump_held = true
		"hook":
			player.start_hook_action()
		"attack":
			player.attack()
		"fish":
			player.toggle_fishing()
		"bag":
			open_menu()
		"build":
			main_node.toggle_build()
		"place":
			main_node.place_foundation()
		"settings":
			open_settings()


func _release_all():
	joy_finger = -1
	look_finger = -1
	held.clear()
	joy_vec = Vector2.ZERO
	if player != null:
		player.move_input = Vector2.ZERO
		player.jump_held = false
		player.reel_boost = false
		if player.hook_state == player.HookState.CHARGING:
			player._reset_hook()
	_joy_idle()


# ---------- Menu Tas & Pembuatan (Pixel Art) ----------

func _build_bag_menu():
	menu = Panel.new()
	menu.visible = false
	menu.size = Vector2(860, 490)
	menu.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.14, 0.09, 0.05, 0.96)))
	root.add_child(menu)

	var title = Label.new()
	title.text = "TAS SURVIVAL  &  PEMBUATAN ALAT"
	title.position = Vector2(24, 14)
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(title, 22, Color(0.98, 0.86, 0.45), 6)
	menu.add_child(title)

	var btn_set = Button.new()
	btn_set.text = "PENGATURAN"
	btn_set.position = Vector2(540, 12)
	btn_set.size = Vector2(150, 46)
	btn_set.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.24, 0.34, 0.46)))
	_style_pixel_label(btn_set, 16)
	btn_set.pressed.connect(_open_settings_from_bag)
	menu.add_child(btn_set)

	var close = Button.new()
	close.text = "TUTUP [X]"
	close.position = Vector2(704, 12)
	close.size = Vector2(136, 46)
	close.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.58, 0.18, 0.16)))
	_style_pixel_label(close, 16)
	close.pressed.connect(close_menu)
	menu.add_child(close)

	var inv_hdr = Label.new()
	inv_hdr.text = "ISI TAS (INVENTORI)"
	inv_hdr.position = Vector2(24, 64)
	inv_hdr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(inv_hdr, 16, Color(0.85, 0.78, 0.62), 4)
	menu.add_child(inv_hdr)

	var rec_hdr = Label.new()
	rec_hdr.text = "RESEP PEMBUATAN (CRAFTING)"
	rec_hdr.position = Vector2(436, 64)
	rec_hdr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(rec_hdr, 16, Color(0.85, 0.78, 0.62), 4)
	menu.add_child(rec_hdr)

	var inv_scroll = ScrollContainer.new()
	inv_scroll.position = Vector2(22, 92)
	inv_scroll.size = Vector2(390, 378)
	inv_box = VBoxContainer.new()
	inv_box.custom_minimum_size = Vector2(370, 0)
	inv_box.mouse_filter = Control.MOUSE_FILTER_PASS
	inv_box.add_theme_constant_override("separation", 6)
	inv_scroll.add_child(inv_box)
	menu.add_child(inv_scroll)

	var rec_scroll = ScrollContainer.new()
	rec_scroll.position = Vector2(434, 92)
	rec_scroll.size = Vector2(404, 378)
	rec_box = VBoxContainer.new()
	rec_box.custom_minimum_size = Vector2(384, 0)
	rec_box.mouse_filter = Control.MOUSE_FILTER_PASS
	rec_box.add_theme_constant_override("separation", 8)
	rec_scroll.add_child(rec_box)
	menu.add_child(rec_scroll)


func open_menu():
	_release_all()
	if main_node != null and main_node.build_mode:
		main_node.set_build_mode_state(false)
	settings_modal.visible = false
	Game.menu_open = true
	menu.visible = true
	_refresh_menu()
	Game.play_sfx("ui", 1.0, 0.8)


func close_menu():
	Game.menu_open = false
	menu.visible = false
	Game.play_sfx("ui", 0.9, 0.7)


func _refresh_menu():
	if menu == null or inv_box == null:
		return
	for c in inv_box.get_children():
		c.queue_free()
	for c in rec_box.get_children():
		c.queue_free()

	var ids = Game.inventory.keys()
	ids.sort()
	if ids.is_empty():
		var empty = Label.new()
		empty.text = "Tas masih kosong. Lempar HOOK ke sampah laut!"
		_style_pixel_label(empty, 16, Color(0.8, 0.75, 0.65), 4)
		inv_box.add_child(empty)

	for id in ids:
		var row_panel = PanelContainer.new()
		row_panel.custom_minimum_size = Vector2(366, 52)
		row_panel.mouse_filter = Control.MOUSE_FILTER_PASS
		row_panel.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.22, 0.14, 0.08, 0.95)))
		var row = HBoxContainer.new()
		row.mouse_filter = Control.MOUSE_FILTER_PASS
		row.add_theme_constant_override("separation", 10)
		row_panel.add_child(row)

		var icon_id = id
		if id in ["cooked_fish", "fish", "cooked_meat", "meat", "can", "coconut"]:
			icon_id = "hunger"
		var ic = TextureRect.new()
		ic.texture = PixelUI.get_icon(icon_id)
		ic.custom_minimum_size = Vector2(32, 32)
		ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		ic.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(ic)

		var l = Label.new()
		l.text = "%s   x%d" % [Game.ITEM_NAMES.get(id, id), Game.inventory[id]]
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		l.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_style_pixel_label(l, 17)
		row.add_child(l)

		if Game.USABLE.has(id):
			var b = Button.new()
			b.text = "PAKAI"
			b.custom_minimum_size = Vector2(88, 38)
			b.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.18, 0.52, 0.28)))
			_style_pixel_label(b, 15)
			b.pressed.connect(Game.use_item.bind(id))
			row.add_child(b)
		inv_box.add_child(row_panel)

	for r in Game.RECIPES:
		var costs = ""
		for k in r["cost"]:
			costs += "%d %s, " % [r["cost"][k], Game.ITEM_NAMES.get(k, k)]
		costs = costs.trim_suffix(", ")
		var owned = (r["id"] == "rod" and Game.has_rod) or (r["id"] == "spear" and Game.has_spear)
		var can_craft = (not owned) and Game.has_items(r["cost"])
		var nm = r["name"]
		if owned:
			nm += " [DIMILIKI]"
		var b = Button.new()
		b.text = nm + "\nBahan: " + costs
		b.custom_minimum_size = Vector2(380, 68)
		var bg_c = Color(0.22, 0.44, 0.24) if can_craft else Color(0.22, 0.18, 0.15)
		b.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(bg_c))
		b.add_theme_stylebox_override("disabled", PixelUI.get_pixel_button_style(Color(0.16, 0.13, 0.11, 0.8)))
		_style_pixel_label(b, 15, Color(0.98, 0.95, 0.84) if can_craft else Color(0.65, 0.62, 0.58), 4)
		b.disabled = not can_craft
		b.pressed.connect(Game.craft.bind(r["id"]))
		rec_box.add_child(b)


# ---------- Menu Pengaturan (Grafik, Audio/Kontrol, Custom HUD) ----------

func _build_settings_modal():
	settings_modal = Panel.new()
	settings_modal.visible = false
	settings_modal.size = Vector2(860, 500)
	settings_modal.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.13, 0.10, 0.07, 0.97)))
	root.add_child(settings_modal)

	var title = Label.new()
	title.text = "PENGATURAN GAME  &  CUSTOM HUD"
	title.position = Vector2(24, 14)
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(title, 22, Color(0.98, 0.86, 0.45), 6)
	settings_modal.add_child(title)

	var close = Button.new()
	close.text = "SIMPAN & TUTUP"
	close.position = Vector2(666, 12)
	close.size = Vector2(172, 46)
	close.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.20, 0.52, 0.28)))
	_style_pixel_label(close, 15)
	close.pressed.connect(close_settings)
	settings_modal.add_child(close)

	settings_tab_box = HBoxContainer.new()
	settings_tab_box.position = Vector2(24, 66)
	settings_tab_box.size = Vector2(812, 46)
	settings_tab_box.mouse_filter = Control.MOUSE_FILTER_PASS
	settings_tab_box.add_theme_constant_override("separation", 10)
	settings_modal.add_child(settings_tab_box)

	var scroll = ScrollContainer.new()
	scroll.position = Vector2(24, 122)
	scroll.size = Vector2(812, 356)
	settings_content_box = VBoxContainer.new()
	settings_content_box.custom_minimum_size = Vector2(790, 0)
	settings_content_box.mouse_filter = Control.MOUSE_FILTER_PASS
	settings_content_box.add_theme_constant_override("separation", 10)
	scroll.add_child(settings_content_box)
	settings_modal.add_child(scroll)


func open_settings():
	_release_all()
	if main_node != null and main_node.build_mode:
		main_node.set_build_mode_state(false)
	menu.visible = false
	Game.menu_open = true
	settings_modal.visible = true
	_rebuild_settings_ui()
	Game.play_sfx("ui", 1.0, 0.8)


func close_settings():
	Game.save_settings()
	Game.menu_open = false
	settings_modal.visible = false
	Game.play_sfx("ui", 1.0, 0.8)


func _switch_settings_tab(tab_id):
	current_settings_tab = tab_id
	_rebuild_settings_ui()
	Game.play_sfx("ui", 1.05, 0.8)


func _open_settings_from_bag():
	close_menu()
	open_settings()


func _invoke_setting_cb(cb):
	if cb.is_valid():
		cb.call()
	_rebuild_settings_ui()
	Game.play_sfx("ui", 1.02, 0.8)


func _step_gfx_preset(dir):
	var order = ["low", "medium", "high"]
	var cur = order.find(str(Game.settings.get("gfx_preset", "medium")))
	if cur < 0:
		cur = 1
	var idx = (cur + dir + 3) % 3
	Game.apply_gfx_preset(order[idx])


func _step_float_setting(key, delta_v, min_v, max_v):
	Game.settings[key] = clamp(float(Game.settings.get(key, min_v)) + delta_v, min_v, max_v)
	Game.apply_settings()


func _step_fps_limit(dir):
	var opts = [30, 60, 90, 0]
	var cur = opts.find(int(Game.settings.get("max_fps", 60)))
	if cur < 0:
		cur = 1
	var idx = (cur + dir + 4) % 4
	Game.settings["max_fps"] = opts[idx]
	Game.apply_settings()


func _step_wave_quality(dir):
	var wq = int(Game.settings.get("wave_quality", 2))
	var nxt = wq + dir
	if nxt < 1:
		nxt = 3
	elif nxt > 3:
		nxt = 1
	Game.settings["wave_quality"] = nxt
	Game.apply_settings()


func _step_view_dist(dir):
	var vd = int(Game.settings.get("view_dist", 1))
	Game.settings["view_dist"] = (vd + dir + 3) % 3
	Game.apply_settings()


func _toggle_bool_setting(key):
	Game.settings[key] = not bool(Game.settings.get(key, false))
	Game.apply_settings()


func _on_reset_hud_pressed():
	Game.reset_custom_hud()
	_rebuild_settings_ui()
	show_message("Tata letak HUD dikembalikan ke standar awal.")
	Game.play_sfx("ui", 0.85, 0.8)


func _on_editor_reset_pressed():
	Game.reset_custom_hud()
	btns["place"].visible = true
	_layout()
	Game.play_sfx("ui", 0.9, 0.8)


func _add_setting_row(label_text, value_text, on_prev, on_next):
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(786, 54)
	panel.mouse_filter = Control.MOUSE_FILTER_PASS
	panel.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.20, 0.13, 0.08, 0.94)))
	var hb = HBoxContainer.new()
	hb.mouse_filter = Control.MOUSE_FILTER_PASS
	hb.add_theme_constant_override("separation", 12)
	panel.add_child(hb)

	var lbl = Label.new()
	lbl.text = "  " + label_text
	lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(lbl, 17)
	hb.add_child(lbl)

	if on_prev.is_valid():
		var b_prev = Button.new()
		b_prev.text = " < "
		b_prev.custom_minimum_size = Vector2(56, 40)
		b_prev.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.32, 0.24, 0.16)))
		_style_pixel_label(b_prev, 18)
		b_prev.pressed.connect(_invoke_setting_cb.bind(on_prev))
		hb.add_child(b_prev)

	var val_lbl = Label.new()
	val_lbl.text = value_text
	val_lbl.custom_minimum_size = Vector2(180, 40)
	val_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	val_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	val_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(val_lbl, 17, Color(0.48, 0.98, 0.58), 4)
	hb.add_child(val_lbl)

	var b_next = Button.new()
	b_next.text = " > " if on_prev.is_valid() else "UBAH"
	b_next.custom_minimum_size = Vector2(56 if on_prev.is_valid() else 110, 40)
	b_next.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.24, 0.44, 0.28)))
	_style_pixel_label(b_next, 17)
	b_next.pressed.connect(_invoke_setting_cb.bind(on_next))
	hb.add_child(b_next)

	settings_content_box.add_child(panel)


func _rebuild_settings_ui():
	for c in settings_tab_box.get_children():
		c.queue_free()
	for c in settings_content_box.get_children():
		c.queue_free()

	var tabs = [
		{"id": "gfx", "title": "1. GRAFIK & PERFORMA"},
		{"id": "ctrl", "title": "2. AUDIO & KONTROL HOOK"},
		{"id": "hud", "title": "3. CUSTOM HUD LAYOUT"},
	]
	for t in tabs:
		var tb = Button.new()
		tb.text = t["title"]
		tb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		tb.custom_minimum_size = Vector2(240, 44)
		var active = (current_settings_tab == t["id"])
		var col = Color(0.68, 0.46, 0.16) if active else Color(0.24, 0.17, 0.11)
		tb.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(col))
		_style_pixel_label(tb, 16, Color(1, 0.96, 0.82) if active else Color(0.75, 0.7, 0.62))
		tb.pressed.connect(_switch_settings_tab.bind(t["id"]))
		settings_tab_box.add_child(tb)

	if current_settings_tab == "gfx":
		var preset = str(Game.settings.get("gfx_preset", "medium")).to_upper()
		var p_map = {"LOW": "RENDAH (Hemat Baterai)", "MEDIUM": "SEDANG (Seimbang)", "HIGH": "TINGGI (Ultra)"}
		_add_setting_row("Preset Kualitas Grafik", p_map.get(preset, preset), _step_gfx_preset.bind(-1), _step_gfx_preset.bind(1))

		var rs = int(round(float(Game.settings.get("res_scale", 1.0)) * 100.0))
		_add_setting_row("Skala Resolusi 3D (Resolution Scale)", "%d%%" % rs, _step_float_setting.bind("res_scale", -0.15, 0.55, 1.0), _step_float_setting.bind("res_scale", 0.15, 0.55, 1.0))

		var fps_val = int(Game.settings.get("max_fps", 60))
		var fps_txt = "TANPA BATAS" if fps_val == 0 else ("%d FPS" % fps_val)
		_add_setting_row("Batas Frame Rate (Target FPS)", fps_txt, _step_fps_limit.bind(-1), _step_fps_limit.bind(1))

		var wq = int(Game.settings.get("wave_quality", 2))
		var wq_names = {1: "RENDAH", 2: "SEDANG", 3: "TINGGI + BUIH OMBAK"}
		_add_setting_row("Detail Gelombang & Shader Laut", wq_names.get(wq, "SEDANG"), _step_wave_quality.bind(-1), _step_wave_quality.bind(1))

		var sh_on = bool(Game.settings.get("shadows", false))
		_add_setting_row("Bayangan Matahari Real-Time (Shadows)", "AKTIF" if sh_on else "NONAKTIF", Callable(), _toggle_bool_setting.bind("shadows"))

		var vd = int(Game.settings.get("view_dist", 1))
		var vd_names = {0: "DEKAT (Cepat)", 1: "NORMAL", 2: "JAUH (Luas)"}
		_add_setting_row("Jarak Pandang & Kabut Laut", vd_names.get(vd, "NORMAL"), _step_view_dist.bind(-1), _step_view_dist.bind(1))

		var fov_v = int(round(float(Game.settings.get("fov", 75.0))))
		_add_setting_row("Sudut Pandang Kamera FPS (FOV)", "%d Derajat" % fov_v, _step_float_setting.bind("fov", -5.0, 65.0, 95.0), _step_float_setting.bind("fov", 5.0, 65.0, 95.0))

		var sfps = bool(Game.settings.get("show_fps", true))
		_add_setting_row("Indikator FPS di Pojok Status", "TAMPIL" if sfps else "SEMBUNYI", Callable(), _toggle_bool_setting.bind("show_fps"))

	elif current_settings_tab == "ctrl":
		var sv = int(round(float(Game.settings.get("sfx_vol", 0.85)) * 100.0))
		_add_setting_row("Volume Efek Suara (SFX Hook, Air, Hiu)", "%d%%" % sv, _step_float_setting.bind("sfx_vol", -0.15, 0.0, 1.0), _step_float_setting.bind("sfx_vol", 0.15, 0.0, 1.0))

		var av = int(round(float(Game.settings.get("amb_vol", 0.55)) * 100.0))
		_add_setting_row("Volume Suara Ombak Samudra (Ambience)", "%d%%" % av, _step_float_setting.bind("amb_vol", -0.15, 0.0, 1.0), _step_float_setting.bind("amb_vol", 0.15, 0.0, 1.0))

		var sens_v = int(round(float(Game.settings.get("sens", 1.0)) * 100.0))
		_add_setting_row("Sensitivitas Geser Kamera (Look Sensitivity)", "%d%%" % sens_v, _step_float_setting.bind("sens", -0.2, 0.4, 2.4), _step_float_setting.bind("sens", 0.2, 0.4, 2.4))

		var ch_mode = bool(Game.settings.get("hook_charge_mode", true))
		_add_setting_row("Mode Lempar Grappling Hook", "TAHAN & LEPAS (CHARGE)" if ch_mode else "SEKALI TEKAN (INSTAN)", Callable(), _toggle_bool_setting.bind("hook_charge_mode"))

		var ar_mode = bool(Game.settings.get("auto_reel", true))
		_add_setting_row("Tarik Tali Hook Otomatis Saat Mendarat", "OTOMATIS + TOMBOL TARIK" if ar_mode else "MANUAL (TEKAN TARIK)", Callable(), _toggle_bool_setting.bind("auto_reel"))

		var inv_y = bool(Game.settings.get("invert_y", false))
		_add_setting_row("Balik Sumbu Vertikal Kamera (Invert Y)", "AKTIF" if inv_y else "NORMAL", Callable(), _toggle_bool_setting.bind("invert_y"))

	elif current_settings_tab == "hud":
		var launch_btn = Button.new()
		launch_btn.text = "BUKA EDITOR POSISI TOMBOL (GESER & UBAH UKURAN DI LAYAR)"
		launch_btn.custom_minimum_size = Vector2(786, 62)
		launch_btn.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.20, 0.54, 0.30)))
		_style_pixel_label(launch_btn, 18, Color(1, 0.98, 0.85), 5)
		launch_btn.pressed.connect(start_hud_editor)
		settings_content_box.add_child(launch_btn)

		var hs = int(round(float(Game.settings.get("hud_scale", 1.0)) * 100.0))
		_add_setting_row("Ukuran Global Tombol HUD", "%d%%" % hs, _step_float_setting.bind("hud_scale", -0.1, 0.65, 1.45), _step_float_setting.bind("hud_scale", 0.1, 0.65, 1.45))

		var ho = int(round(float(Game.settings.get("hud_opacity", 0.92)) * 100.0))
		_add_setting_row("Transparansi / Opasitas HUD", "%d%%" % ho, _step_float_setting.bind("hud_opacity", -0.1, 0.35, 1.0), _step_float_setting.bind("hud_opacity", 0.1, 0.35, 1.0))

		var rst_btn = Button.new()
		rst_btn.text = "RESET POSISI & UKURAN HUD KE STANDAR AWAL"
		rst_btn.custom_minimum_size = Vector2(786, 52)
		rst_btn.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.58, 0.22, 0.16)))
		_style_pixel_label(rst_btn, 16)
		rst_btn.pressed.connect(_on_reset_hud_pressed)
		settings_content_box.add_child(rst_btn)


# ---------- Interactive Custom HUD Layout Editor ----------

func _build_hud_editor_bar():
	hud_edit_bar = Panel.new()
	hud_edit_bar.visible = false
	hud_edit_bar.size = Vector2(820, 96)
	hud_edit_bar.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.12, 0.08, 0.04, 0.96)))
	root.add_child(hud_edit_bar)

	hud_edit_info_lbl = Label.new()
	hud_edit_info_lbl.text = "MODE CUSTOM HUD: Geser tombol/joystick dengan jari! Pilih elemen untuk ubah ukuran."
	hud_edit_info_lbl.position = Vector2(16, 8)
	hud_edit_info_lbl.size = Vector2(788, 28)
	hud_edit_info_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hud_edit_info_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(hud_edit_info_lbl, 15, Color(0.98, 0.88, 0.45), 4)
	hud_edit_bar.add_child(hud_edit_info_lbl)

	var hb = HBoxContainer.new()
	hb.position = Vector2(18, 40)
	hb.size = Vector2(784, 46)
	hb.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.add_theme_constant_override("separation", 12)
	hud_edit_bar.add_child(hb)

	var b_smaller = Button.new()
	b_smaller.text = "- PERKECIL TOMBOL"
	b_smaller.custom_minimum_size = Vector2(180, 42)
	b_smaller.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.32, 0.24, 0.16)))
	_style_pixel_label(b_smaller, 14)
	b_smaller.pressed.connect(_scale_selected_hud.bind(-0.12))
	hb.add_child(b_smaller)

	var b_larger = Button.new()
	b_larger.text = "+ PERBESAR TOMBOL"
	b_larger.custom_minimum_size = Vector2(180, 42)
	b_larger.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.24, 0.42, 0.28)))
	_style_pixel_label(b_larger, 14)
	b_larger.pressed.connect(_scale_selected_hud.bind(0.12))
	hb.add_child(b_larger)

	var b_reset = Button.new()
	b_reset.text = "RESET DEFAULT"
	b_reset.custom_minimum_size = Vector2(165, 42)
	b_reset.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.58, 0.22, 0.16)))
	_style_pixel_label(b_reset, 14)
	b_reset.pressed.connect(_on_editor_reset_pressed)
	hb.add_child(b_reset)

	var b_save = Button.new()
	b_save.text = "SIMPAN & SELESAI"
	b_save.custom_minimum_size = Vector2(195, 42)
	b_save.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.18, 0.56, 0.30)))
	_style_pixel_label(b_save, 15, Color(1, 0.98, 0.85))
	b_save.pressed.connect(stop_hud_editor)
	hb.add_child(b_save)


func start_hud_editor():
	settings_modal.visible = false
	menu.visible = false
	hud_edit_mode = true
	Game.menu_open = true
	hud_edit_bar.visible = true
	btns["place"].visible = true
	_update_hud_editor_label()
	Game.play_sfx("ui", 1.05, 0.85)


func stop_hud_editor():
	hud_edit_mode = false
	hud_edit_dragging = false
	hud_edit_bar.visible = false
	btns["place"].visible = main_node.build_mode
	Game.save_settings()
	Game.menu_open = false
	show_message("Tata letak Custom HUD berhasil disimpan!")
	Game.play_sfx("build", 1.1, 0.85)


func _update_hud_editor_label():
	if hud_edit_info_lbl != null:
		hud_edit_info_lbl.text = "ELEMEN TERPILIH: [%s] — Geser di layar atau tekan +/- Ukuran" % hud_edit_selected.to_upper()


func _scale_selected_hud(delta_scale):
	if not btns.has(hud_edit_selected):
		Game.settings["hud_scale"] = clamp(float(Game.settings.get("hud_scale", 1.0)) + delta_scale, 0.65, 1.45)
		_layout()
		Game.play_sfx("ui", 1.0, 0.8)
		return
	var custom = Game.settings.get("custom_hud", {})
	if not custom.has(hud_edit_selected):
		var b = btns[hud_edit_selected]
		custom[hud_edit_selected] = {
			"rx": b.position.x / max(1.0, vp.x),
			"ry": b.position.y / max(1.0, vp.y),
			"scale": float(Game.settings.get("hud_scale", 1.0)),
		}
	var cur_s = float(custom[hud_edit_selected].get("scale", Game.settings.get("hud_scale", 1.0)))
	custom[hud_edit_selected]["scale"] = clamp(cur_s + delta_scale, 0.60, 1.55)
	Game.settings["custom_hud"] = custom
	_layout()
	Game.play_sfx("ui", 1.0, 0.8)


func _handle_hud_editor_input(event):
	var pos = Vector2.ZERO
	var is_down = false
	var is_up = false
	var is_move = false

	if event is InputEventScreenTouch:
		pos = event.position
		is_down = event.pressed
		is_up = not event.pressed
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		pos = event.position
		is_down = event.pressed
		is_up = not event.pressed
	elif event is InputEventScreenDrag or event is InputEventMouseMotion:
		pos = event.position
		is_move = true
	else:
		return

	if hud_edit_bar.visible and Rect2(hud_edit_bar.position, hud_edit_bar.size).has_point(pos) and is_down:
		return

	if is_down:
		for id in btns:
			var b = btns[id]
			if b.visible and Rect2(b.position, b.size).has_point(pos):
				hud_edit_selected = id
				hud_edit_dragging = true
				hud_edit_drag_offset = pos - b.position
				_update_hud_editor_label()
				return
		if Rect2(joy_base.position, joy_base.size).has_point(pos):
			hud_edit_selected = "joystick"
			hud_edit_dragging = true
			hud_edit_drag_offset = pos - joy_home
			_update_hud_editor_label()
			return
		if Rect2(status_panel.position, status_panel.size).has_point(pos):
			hud_edit_selected = "status_panel"
			hud_edit_dragging = true
			hud_edit_drag_offset = pos - status_panel.position
			_update_hud_editor_label()
			return

	elif is_move and hud_edit_dragging:
		var custom = Game.settings.get("custom_hud", {})
		if btns.has(hud_edit_selected):
			var b = btns[hud_edit_selected]
			var np = pos - hud_edit_drag_offset
			np.x = clamp(np.x, 4.0, max(4.0, vp.x - b.size.x - 4.0))
			np.y = clamp(np.y, 4.0, max(4.0, vp.y - b.size.y - 4.0))
			b.position = np
			var prev_s = float(Game.settings.get("hud_scale", 1.0))
			if custom.has(hud_edit_selected) and custom[hud_edit_selected].has("scale"):
				prev_s = float(custom[hud_edit_selected]["scale"])
			custom[hud_edit_selected] = {"rx": np.x / max(1.0, vp.x), "ry": np.y / max(1.0, vp.y), "scale": prev_s}
		elif hud_edit_selected == "joystick":
			var np = pos - hud_edit_drag_offset
			np.x = clamp(np.x, JOY_R + 8.0, vp.x - JOY_R - 8.0)
			np.y = clamp(np.y, JOY_R + 8.0, vp.y - JOY_R - 8.0)
			joy_home = np
			_joy_idle()
			custom["joystick"] = {"rx": np.x / max(1.0, vp.x), "ry": np.y / max(1.0, vp.y)}
		elif hud_edit_selected == "status_panel":
			var np = pos - hud_edit_drag_offset
			np.x = clamp(np.x, 4.0, vp.x - status_panel.size.x - 4.0)
			np.y = clamp(np.y, 4.0, vp.y - status_panel.size.y - 4.0)
			status_panel.position = np
			custom["status_panel"] = {"rx": np.x / max(1.0, vp.x), "ry": np.y / max(1.0, vp.y)}
		Game.settings["custom_hud"] = custom

	elif is_up:
		hud_edit_dragging = false


# ---------- Layar Kalah / Mati ----------

func _build_death():
	death_panel = Panel.new()
	death_panel.visible = false
	death_panel.size = Vector2(540, 270)
	death_panel.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.22, 0.04, 0.04, 0.96)))
	root.add_child(death_panel)

	var l = Label.new()
	l.text = "KAMU TIDAK BERTAHAN DI LAUT..."
	l.position = Vector2(0, 48)
	l.size = Vector2(540, 60)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(l, 28, Color(1.0, 0.35, 0.32), 7)
	death_panel.add_child(l)

	var b = Button.new()
	b.text = "MAIN LAGI"
	b.position = Vector2(170, 148)
	b.size = Vector2(200, 72)
	b.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.20, 0.52, 0.28)))
	_style_pixel_label(b, 22)
	b.pressed.connect(_restart)
	death_panel.add_child(b)


func _on_died():
	_release_all()
	menu.visible = false
	settings_modal.visible = false
	hud_edit_bar.visible = false
	hud_edit_mode = false
	Game.menu_open = false
	death_panel.visible = true


func _restart():
	Game.play_sfx("ui", 1.0, 0.8)
	Game.reset()
	get_tree().reload_current_scene()
