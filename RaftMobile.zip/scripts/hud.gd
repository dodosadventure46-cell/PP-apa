extends CanvasLayer

var player
var main_node
var root
var btns = {}
var btn_labels = {}
var held = {}
var joy_finger = -1
var look_finger = -1
var joy_center = Vector2.ZERO
var joy_home = Vector2(190, 530)
var joy_vec = Vector2.ZERO
var vp = Vector2(1280, 720)
var joy_base
var joy_knob
var bar_fills = {}
var msg_label
var msg_t = 0.0
var mode_label
var menu
var inv_box
var rec_box
var death_panel
var cross

const JOY_R = 85.0


func _ready():
	layer = 10
	root = Control.new()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	_make_bar("health", "NYAWA", Color(0.85, 0.2, 0.2), 20)
	_make_bar("hunger", "LAPAR", Color(0.9, 0.6, 0.15), 52)
	_make_bar("thirst", "HAUS", Color(0.25, 0.6, 0.95), 84)

	joy_base = _make_circle(JOY_R * 2.0, Color(1, 1, 1, 0.12))
	joy_knob = _make_circle(70.0, Color(1, 1, 1, 0.3))
	cross = _make_circle(8.0, Color(1, 1, 1, 0.85))

	_make_button("jump", "LOMPAT", Color(0.15, 0.15, 0.2, 0.55), 20)
	_make_button("hook", "AMBIL", Color(0.1, 0.45, 0.25, 0.65), 22)
	_make_button("attack", "SERANG", Color(0.6, 0.15, 0.15, 0.65), 20)
	_make_button("fish", "PANCING", Color(0.1, 0.35, 0.6, 0.65), 18)
	_make_button("place", "PASANG", Color(0.7, 0.5, 0.1, 0.8), 22)
	_make_button("bag", "TAS", Color(0.15, 0.15, 0.2, 0.7), 22)
	_make_button("build", "BANGUN", Color(0.15, 0.15, 0.2, 0.7), 18)
	btns["place"].visible = false

	msg_label = Label.new()
	msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	msg_label.add_theme_font_size_override("font_size", 24)
	msg_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 1))
	msg_label.add_theme_constant_override("outline_size", 8)
	msg_label.modulate.a = 0.0
	root.add_child(msg_label)

	mode_label = Label.new()
	mode_label.text = "MODE BANGUN: arahkan + ke air di samping rakit, lalu tekan PASANG"
	mode_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mode_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mode_label.add_theme_font_size_override("font_size", 18)
	mode_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 1))
	mode_label.add_theme_constant_override("outline_size", 6)
	mode_label.visible = false
	root.add_child(mode_label)

	_build_menu()
	_build_death()

	get_viewport().size_changed.connect(_layout)
	_layout()

	Game.stats_changed.connect(_on_stats)
	Game.inventory_changed.connect(_refresh_menu)
	Game.message.connect(show_message)
	Game.player_died.connect(_on_died)
	_on_stats()
	show_message("Ambil barang apung dengan AMBIL. Buka TAS untuk membuat alat.")


func _make_bar(key, title, color, y):
	var bg = Panel.new()
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.position = Vector2(20, y)
	bg.size = Vector2(250, 26)
	var sb = StyleBoxFlat.new()
	sb.bg_color = Color(0, 0, 0, 0.5)
	sb.set_corner_radius_all(6)
	bg.add_theme_stylebox_override("panel", sb)
	root.add_child(bg)
	var fill = Panel.new()
	fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fill.position = Vector2(3, 3)
	fill.size = Vector2(244, 20)
	var sf = StyleBoxFlat.new()
	sf.bg_color = color
	sf.set_corner_radius_all(5)
	fill.add_theme_stylebox_override("panel", sf)
	bg.add_child(fill)
	var lb = Label.new()
	lb.text = title
	lb.position = Vector2(10, 0)
	lb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	lb.add_theme_font_size_override("font_size", 15)
	bg.add_child(lb)
	bar_fills[key] = fill


func _make_circle(diameter, color):
	var p = Panel.new()
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.size = Vector2(diameter, diameter)
	var sb = StyleBoxFlat.new()
	sb.bg_color = color
	sb.set_corner_radius_all(int(diameter / 2.0))
	p.add_theme_stylebox_override("panel", sb)
	root.add_child(p)
	return p


func _make_button(id, text, color, fsize):
	var p = Panel.new()
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb = StyleBoxFlat.new()
	sb.bg_color = color
	sb.set_corner_radius_all(60)
	sb.set_border_width_all(3)
	sb.border_color = Color(1, 1, 1, 0.55)
	p.add_theme_stylebox_override("panel", sb)
	var l = Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_size_override("font_size", fsize)
	p.add_child(l)
	l.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(p)
	btns[id] = p
	btn_labels[id] = l


func _place(id, pos, sz):
	btns[id].position = pos
	btns[id].size = sz


func _layout():
	vp = get_viewport().get_visible_rect().size
	var W = vp.x
	var H = vp.y
	root.size = vp
	_place("jump", Vector2(W - 150, H - 150), Vector2(112, 112))
	_place("hook", Vector2(W - 290, H - 130), Vector2(112, 112))
	_place("attack", Vector2(W - 150, H - 290), Vector2(112, 112))
	_place("fish", Vector2(W - 290, H - 270), Vector2(112, 112))
	_place("place", Vector2(W - 450, H - 150), Vector2(130, 112))
	_place("bag", Vector2(W - 140, 16), Vector2(120, 64))
	_place("build", Vector2(W - 280, 16), Vector2(120, 64))
	joy_home = Vector2(190, H - 190)
	_joy_idle()
	cross.position = vp / 2.0 - Vector2(4, 4)
	msg_label.position = Vector2(W / 2.0 - 380, 90)
	msg_label.size = Vector2(760, 40)
	mode_label.position = Vector2(W / 2.0 - 400, 135)
	mode_label.size = Vector2(800, 30)
	menu.position = (vp - menu.size) / 2.0
	death_panel.position = (vp - death_panel.size) / 2.0


func _joy_idle():
	joy_base.position = joy_home - Vector2(JOY_R, JOY_R)
	joy_knob.position = joy_home - Vector2(35, 35)


func _on_stats():
	bar_fills["health"].size.x = 244.0 * clamp(Game.health / 100.0, 0.0, 1.0)
	bar_fills["hunger"].size.x = 244.0 * clamp(Game.hunger / 100.0, 0.0, 1.0)
	bar_fills["thirst"].size.x = 244.0 * clamp(Game.thirst / 100.0, 0.0, 1.0)


func show_message(t):
	msg_label.text = t
	msg_label.modulate.a = 1.0
	msg_t = 3.0


func set_build_mode(on):
	btns["place"].visible = on
	mode_label.visible = on
	if on:
		btn_labels["build"].text = "SELESAI"
	else:
		btn_labels["build"].text = "BANGUN"


func _process(delta):
	if msg_t > 0.0:
		msg_t -= delta
		msg_label.modulate.a = clamp(msg_t, 0.0, 1.0)
	if player != null:
		if player.fishing:
			btn_labels["fish"].text = "BATAL"
		else:
			btn_labels["fish"].text = "PANCING"


# ---------- Input sentuh ----------

func _input(event):
	if Game.menu_open or Game.dead:
		return
	if event is InputEventScreenTouch:
		if event.pressed:
			_touch_down(event.index, event.position)
		else:
			_touch_up(event.index)
	elif event is InputEventScreenDrag:
		_touch_drag(event.index, event.position, event.relative)


func _touch_down(idx, pos):
	for id in btns:
		var b = btns[id]
		if b.visible and Rect2(b.position, b.size).has_point(pos):
			held[idx] = id
			_press(id)
			return
	if pos.x < vp.x * 0.45 and joy_finger == -1:
		joy_finger = idx
		joy_center = pos
		joy_vec = Vector2.ZERO
		joy_base.position = pos - Vector2(JOY_R, JOY_R)
		joy_knob.position = pos - Vector2(35, 35)
	elif look_finger == -1 and pos.x >= vp.x * 0.3:
		look_finger = idx


func _touch_up(idx):
	if held.has(idx):
		if held[idx] == "jump":
			player.jump_held = false
		held.erase(idx)
	if idx == joy_finger:
		joy_finger = -1
		joy_vec = Vector2.ZERO
		player.move_input = Vector2.ZERO
		_joy_idle()
	if idx == look_finger:
		look_finger = -1


func _touch_drag(idx, pos, rel):
	if idx == joy_finger:
		var v = pos - joy_center
		if v.length() > JOY_R:
			v = v.normalized() * JOY_R
		joy_vec = v / JOY_R
		var out = joy_vec
		if out.length() < 0.12:
			out = Vector2.ZERO
		player.move_input = out
		joy_knob.position = joy_base.position + Vector2(JOY_R, JOY_R) - Vector2(35, 35) + v
	elif idx == look_finger:
		player.look_delta += rel


func _press(id):
	match id:
		"jump":
			player.jump_held = true
		"hook":
			player.throw_hook()
		"attack":
			player.attack()
		"fish":
			player.toggle_fishing()
		"bag":
			open_menu()
		"build":
			main_node.toggle_build()
		"place":
			main_node.place_foundation()


func _release_all():
	joy_finger = -1
	look_finger = -1
	held.clear()
	joy_vec = Vector2.ZERO
	if player != null:
		player.move_input = Vector2.ZERO
		player.jump_held = false
	_joy_idle()


# ---------- Menu tas & crafting ----------

func _build_menu():
	menu = Panel.new()
	menu.visible = false
	menu.size = Vector2(820, 470)
	var sb = StyleBoxFlat.new()
	sb.bg_color = Color(0.07, 0.1, 0.14, 0.95)
	sb.set_corner_radius_all(14)
	sb.set_border_width_all(2)
	sb.border_color = Color(1, 1, 1, 0.3)
	menu.add_theme_stylebox_override("panel", sb)
	root.add_child(menu)

	var title = Label.new()
	title.text = "TAS  &  PEMBUATAN"
	title.position = Vector2(20, 14)
	title.add_theme_font_size_override("font_size", 24)
	menu.add_child(title)

	var close = Button.new()
	close.text = "TUTUP"
	close.position = Vector2(680, 10)
	close.size = Vector2(130, 48)
	close.add_theme_font_size_override("font_size", 20)
	close.pressed.connect(close_menu)
	menu.add_child(close)

	var inv_scroll = ScrollContainer.new()
	inv_scroll.position = Vector2(20, 72)
	inv_scroll.size = Vector2(370, 380)
	inv_box = VBoxContainer.new()
	inv_box.custom_minimum_size = Vector2(350, 0)
	inv_scroll.add_child(inv_box)
	menu.add_child(inv_scroll)

	var rec_scroll = ScrollContainer.new()
	rec_scroll.position = Vector2(420, 72)
	rec_scroll.size = Vector2(385, 380)
	rec_box = VBoxContainer.new()
	rec_box.custom_minimum_size = Vector2(365, 0)
	rec_scroll.add_child(rec_box)
	menu.add_child(rec_scroll)


func open_menu():
	_release_all()
	Game.menu_open = true
	menu.visible = true
	_refresh_menu()


func close_menu():
	Game.menu_open = false
	menu.visible = false


func _refresh_menu():
	if menu == null or inv_box == null:
		return
	for c in inv_box.get_children():
		c.queue_free()
	for c in rec_box.get_children():
		c.queue_free()

	var ids = Game.inventory.keys()
	ids.sort()
	if ids.is_empty():
		var empty = Label.new()
		empty.text = "Tas kosong"
		empty.add_theme_font_size_override("font_size", 20)
		inv_box.add_child(empty)
	for id in ids:
		var row = HBoxContainer.new()
		row.custom_minimum_size = Vector2(340, 50)
		var l = Label.new()
		l.text = "%s   x%d" % [Game.ITEM_NAMES.get(id, id), Game.inventory[id]]
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		l.add_theme_font_size_override("font_size", 20)
		row.add_child(l)
		if Game.USABLE.has(id):
			var b = Button.new()
			b.text = "Pakai"
			b.custom_minimum_size = Vector2(90, 44)
			b.add_theme_font_size_override("font_size", 18)
			b.pressed.connect(Game.use_item.bind(id))
			row.add_child(b)
		inv_box.add_child(row)

	for r in Game.RECIPES:
		var costs = ""
		for k in r["cost"]:
			costs += "%d %s, " % [r["cost"][k], Game.ITEM_NAMES[k]]
		costs = costs.trim_suffix(", ")
		var owned = (r["id"] == "rod" and Game.has_rod) or (r["id"] == "spear" and Game.has_spear)
		var nm = r["name"]
		if owned:
			nm += " (dimiliki)"
		var b = Button.new()
		b.text = nm + "\n" + costs
		b.custom_minimum_size = Vector2(360, 66)
		b.add_theme_font_size_override("font_size", 17)
		b.disabled = owned or not Game.has_items(r["cost"])
		b.pressed.connect(Game.craft.bind(r["id"]))
		rec_box.add_child(b)


# ---------- Layar mati ----------

func _build_death():
	death_panel = Panel.new()
	death_panel.visible = false
	death_panel.size = Vector2(520, 260)
	var sb = StyleBoxFlat.new()
	sb.bg_color = Color(0.1, 0.02, 0.02, 0.92)
	sb.set_corner_radius_all(14)
	death_panel.add_theme_stylebox_override("panel", sb)
	root.add_child(death_panel)
	var l = Label.new()
	l.text = "KAMU TIDAK BERTAHAN..."
	l.position = Vector2(0, 50)
	l.size = Vector2(520, 60)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", 34)
	death_panel.add_child(l)
	var b = Button.new()
	b.text = "MAIN LAGI"
	b.position = Vector2(160, 150)
	b.size = Vector2(200, 70)
	b.add_theme_font_size_override("font_size", 24)
	b.pressed.connect(_restart)
	death_panel.add_child(b)


func _on_died():
	_release_all()
	menu.visible = false
	Game.menu_open = false
	death_panel.visible = true


func _restart():
	Game.reset()
	get_tree().reload_current_scene()
