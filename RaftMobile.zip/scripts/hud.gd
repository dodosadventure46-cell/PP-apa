extends CanvasLayer

const PixelUI = preload("res://scripts/pixel_ui.gd")

var player
var main_node
var root
var brightness_overlay
var hud_gameplay_layer
var status_panel
var bar_fills = {}
var bar_pcts = {}
var day_label
var fps_label
var compass_weather_lbl
var island_radar_lbl
var oxy_bg
var oxy_fill
var oxy_lbl

var sail_ctrl_panel
var sail_status_lbl
var sail_toggle_btn

var build_ctrl_panel
var build_type_btn
var build_rot_btn

var btns = {}
var btn_labels = {}
var btn_icons = {}
var btn_colors = {}
var held = {}
var last_water_state = false

var joy_finger = -1
var look_finger = -1
var joy_center = Vector2.ZERO
var joy_home = Vector2(190, 530)
var joy_vec = Vector2.ZERO
var vp = Vector2(1280, 720)
var joy_base
var joy_knob

var cross_box
var cross_h
var cross_v
var aim_label
var charge_bg
var charge_fill
var charge_label

var hotbar_panel
var hotbar_box
var msg_label
var msg_t = 0.0

var menu
var armor_slots_box
var armor_def_label
var bag_grid
var bag_hotbar_grid
var bag_sel_info_lbl
var bag_use_btn
var bag_drop_btn
var rec_box
var selected_inv_source = ""
var selected_inv_index = -1

var settings_modal
var settings_tab_box
var settings_content_box
var current_settings_tab = "gfx"

var hud_edit_mode = false
var hud_edit_bar = null
var hud_edit_selected = "hook"
var hud_edit_dragging = false
var hud_edit_drag_offset = Vector2.ZERO
var hud_edit_info_lbl = null

var title_screen = null
var world_select_screen = null
var world_slots_box = null
var create_world_modal = null
var create_slot_target = 1
var create_name_input = null
var create_diff_val = "survival"
var create_diff_btn = null

var loading_screen = null
var loading_bar_fill = null
var loading_pct_lbl = null
var loading_stage_lbl = null
var loading_tip_lbl = null
var loading_title_lbl = null
var is_loading = false
var loading_progress = 0.0
var loading_target_mode = "world"

var death_panel

const JOY_R = 86.0
const TIPS = [
	"TIP: Buat LAYAR KAPAL di menu TAS lalu putar arahnya 360° (◄ KIRI / KANAN ►) untuk berlayar ke Pulau!",
	"TIP: Tekan BANGUN untuk memasang Pondasi, Tembok Kayu, Jendela, Pagar, Atap Tingkat 2, & Jaring Sampah.",
	"TIP: Saat menyelam di dekat Pulau (tombol SELAM), tambang Rumput Laut & Tanah Liat di dasar laut!",
	"TIP: Buat Hammock untuk tidur melewati malam, serta Petak Tanaman untuk menanam Kelapa di rakit.",
]


func _ready():
	layer = 10
	root = Control.new()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(root)

	hud_gameplay_layer = Control.new()
	hud_gameplay_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_gameplay_layer.visible = false
	root.add_child(hud_gameplay_layer)

	_build_status_hud()
	_build_joystick_and_crosshair()
	_build_action_buttons()
	_build_sail_and_build_bars()
	_build_hotbar()
	_build_messages()
	_build_bag_menu()
	_build_settings_modal()
	_build_hud_editor_bar()
	_build_death()

	_build_title_screen()
	_build_world_select_screen()
	_build_create_world_modal()
	_build_loading_screen()

	brightness_overlay = ColorRect.new()
	brightness_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	brightness_overlay.color = Color(0.0, 0.02, 0.05, 0.14)
	root.add_child(brightness_overlay)

	get_viewport().size_changed.connect(_layout)
	_layout()

	Game.stats_changed.connect(_on_stats)
	Game.inventory_changed.connect(_on_inventory_changed)
	Game.message.connect(show_message)
	Game.player_died.connect(_on_died)
	Game.settings_changed.connect(_on_settings_updated)

	_on_stats()
	_refresh_hotbar()
	_update_brightness_overlay()

	_start_loading("boot", "MEMUAT RAFT MOBILE...")


func _style_pixel_label(lbl, fsize, col = Color(0.96, 0.93, 0.84), outline = 5):
	lbl.add_theme_font_size_override("font_size", fsize)
	lbl.add_theme_color_override("font_color", col)
	lbl.add_theme_color_override("font_outline_color", Color(0.05, 0.03, 0.01, 1.0))
	lbl.add_theme_constant_override("outline_size", outline)


func _update_brightness_overlay():
	if brightness_overlay == null:
		return
	var br = clamp(float(Game.settings.get("brightness", 0.75)), 0.30, 1.30)
	if br < 0.95:
		var dark_a = clamp((0.95 - br) * 0.68, 0.0, 0.55)
		brightness_overlay.color = Color(0.01, 0.02, 0.05, dark_a)
	else:
		var light_a = clamp((br - 0.95) * 0.25, 0.0, 0.12)
		brightness_overlay.color = Color(1.0, 0.98, 0.92, light_a)


# ---------- Main Title Screen, World Select & Loading Screen ----------

func _build_title_screen():
	title_screen = Control.new()
	title_screen.visible = false
	title_screen.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(title_screen)

	var dim = ColorRect.new()
	dim.color = Color(0.02, 0.05, 0.11, 0.48)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	title_screen.add_child(dim)

	var card = Panel.new()
	card.name = "TitleCard"
	card.size = Vector2(620, 430)
	card.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.14, 0.09, 0.05, 0.96)))
	title_screen.add_child(card)

	var badge = Label.new()
	badge.text = "SURVIVAL SAMUDRA 3D  •  EDISI MASTER EXPANSION"
	badge.position = Vector2(20, 22)
	badge.size = Vector2(580, 26)
	badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_style_pixel_label(badge, 15, Color(0.48, 0.95, 0.62), 4)
	card.add_child(badge)

	var title = Label.new()
	title.text = "RAFT MOBILE"
	title.position = Vector2(20, 52)
	title.size = Vector2(580, 64)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_style_pixel_label(title, 48, Color(0.98, 0.86, 0.36), 8)
	card.add_child(title)

	var sub = Label.new()
	sub.text = "Kemudi Layar 360°, Bangun Rumah Rakit, Jelajahi Pulau & Menyelam!"
	sub.position = Vector2(20, 120)
	sub.size = Vector2(580, 28)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_style_pixel_label(sub, 15, Color(0.90, 0.84, 0.72), 4)
	card.add_child(sub)

	var btn_play = Button.new()
	btn_play.text = "PLAY  /  PILIH DUNIA"
	btn_play.position = Vector2(110, 172)
	btn_play.size = Vector2(400, 68)
	btn_play.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.18, 0.52, 0.26), Color(0.96, 0.86, 0.40, 1.0)))
	_style_pixel_label(btn_play, 24, Color(1.0, 0.98, 0.88), 6)
	btn_play.pressed.connect(_on_title_play_pressed)
	card.add_child(btn_play)

	var btn_set = Button.new()
	btn_set.text = "PENGATURAN  &  BRIGHTNESS"
	btn_set.position = Vector2(110, 256)
	btn_set.size = Vector2(400, 58)
	btn_set.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.20, 0.32, 0.46)))
	_style_pixel_label(btn_set, 19)
	btn_set.pressed.connect(_on_title_settings_pressed)
	card.add_child(btn_set)

	var btn_quit = Button.new()
	btn_quit.text = "KELUAR GAME"
	btn_quit.position = Vector2(110, 330)
	btn_quit.size = Vector2(400, 54)
	btn_quit.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.52, 0.18, 0.16)))
	_style_pixel_label(btn_quit, 18)
	btn_quit.pressed.connect(_on_quit_pressed)
	card.add_child(btn_quit)


func _on_title_play_pressed():
	Game.play_sfx("ui", 1.05, 0.85)
	title_screen.visible = false
	_open_world_select()


func _on_title_settings_pressed():
	Game.play_sfx("ui", 1.0, 0.85)
	open_settings()


func _on_quit_pressed():
	Game.play_sfx("ui", 0.85, 0.8)
	get_tree().quit()


func _build_world_select_screen():
	world_select_screen = Control.new()
	world_select_screen.visible = false
	world_select_screen.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(world_select_screen)

	var dim = ColorRect.new()
	dim.color = Color(0.02, 0.05, 0.11, 0.58)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	world_select_screen.add_child(dim)

	var panel = Panel.new()
	panel.name = "WorldPanel"
	panel.size = Vector2(880, 520)
	panel.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.14, 0.09, 0.05, 0.97)))
	world_select_screen.add_child(panel)

	var title = Label.new()
	title.text = "PILIH DUNIA  ATAU  BUAT DUNIA BARU"
	title.position = Vector2(24, 16)
	_style_pixel_label(title, 22, Color(0.98, 0.86, 0.40), 6)
	panel.add_child(title)

	var btn_back = Button.new()
	btn_back.text = "< KEMBALI"
	btn_back.position = Vector2(706, 12)
	btn_back.size = Vector2(150, 46)
	btn_back.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.48, 0.22, 0.16)))
	_style_pixel_label(btn_back, 16)
	btn_back.pressed.connect(_on_world_back_pressed)
	panel.add_child(btn_back)

	var sub = Label.new()
	sub.text = "Pilih slot dunia untuk melanjutkan berlayar atau tekan [+ Buat Dunia Baru]:"
	sub.position = Vector2(24, 56)
	_style_pixel_label(sub, 15, Color(0.84, 0.78, 0.66), 4)
	panel.add_child(sub)

	var scroll = ScrollContainer.new()
	scroll.position = Vector2(24, 90)
	scroll.size = Vector2(832, 406)
	world_slots_box = VBoxContainer.new()
	world_slots_box.custom_minimum_size = Vector2(810, 0)
	world_slots_box.mouse_filter = Control.MOUSE_FILTER_PASS
	world_slots_box.add_theme_constant_override("separation", 12)
	scroll.add_child(world_slots_box)
	panel.add_child(scroll)


func _on_world_back_pressed():
	Game.play_sfx("ui", 0.95, 0.8)
	world_select_screen.visible = false
	title_screen.visible = true


func _open_world_select():
	Game.load_worlds_index()
	world_select_screen.visible = true
	create_world_modal.visible = false
	_refresh_world_slots()


func _refresh_world_slots():
	if world_slots_box == null:
		return
	for c in world_slots_box.get_children():
		c.queue_free()

	var diff_labels = {
		"peaceful": "MODE SANTAI",
		"survival": "MODE SURVIVAL",
		"hardcore": "MODE HARDCORE",
	}

	for slot in [1, 2, 3, 4]:
		var card = PanelContainer.new()
		card.custom_minimum_size = Vector2(808, 88)
		card.mouse_filter = Control.MOUSE_FILTER_PASS
		card.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.20, 0.12, 0.06, 0.95)))
		var hb = HBoxContainer.new()
		hb.mouse_filter = Control.MOUSE_FILTER_PASS
		hb.add_theme_constant_override("separation", 14)
		card.add_child(hb)

		if Game.has_world_slot(slot):
			var info = Game.worlds_meta[slot]
			var w_nm = str(info.get("name", "Dunia #%d" % slot))
			var diff = str(info.get("difficulty", "survival"))
			var days = int(info.get("day_count", 1))
			var tiles_arr = info.get("tiles", [[0, 0], [1, 0], [0, 1], [1, 1]])
			var t_cnt = tiles_arr.size() if tiles_arr is Array else 4

			var vb = VBoxContainer.new()
			vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			vb.alignment = BoxContainer.ALIGNMENT_CENTER
			vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
			hb.add_child(vb)

			var l_title = Label.new()
			l_title.text = "  SLOT %d: %s  [%s]" % [slot, w_nm.to_upper(), diff_labels.get(diff, "SURVIVAL")]
			_style_pixel_label(l_title, 19, Color(0.98, 0.90, 0.50), 5)
			vb.add_child(l_title)

			var l_meta = Label.new()
			l_meta.text = "   Hari ke-%d   •   Ukuran Rakit: %d Pondasi   •   Nyawa: %d%%" % [days, t_cnt, int(info.get("health", 100))]
			_style_pixel_label(l_meta, 14, Color(0.84, 0.94, 0.86), 4)
			vb.add_child(l_meta)

			var b_play = Button.new()
			b_play.text = "MASUK DUNIA"
			b_play.custom_minimum_size = Vector2(180, 56)
			b_play.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.18, 0.52, 0.26)))
			_style_pixel_label(b_play, 17, Color(1, 0.98, 0.88))
			b_play.pressed.connect(_on_play_world_slot.bind(slot))
			hb.add_child(b_play)

			var b_new = Button.new()
			b_new.text = "BUAT BARU"
			b_new.custom_minimum_size = Vector2(140, 56)
			b_new.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.58, 0.40, 0.14)))
			_style_pixel_label(b_new, 15)
			b_new.pressed.connect(_open_create_world_modal.bind(slot))
			hb.add_child(b_new)

			var b_del = Button.new()
			b_del.text = "HAPUS"
			b_del.custom_minimum_size = Vector2(105, 56)
			b_del.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.54, 0.18, 0.16)))
			_style_pixel_label(b_del, 15)
			b_del.pressed.connect(_on_delete_world_slot.bind(slot))
			hb.add_child(b_del)
		else:
			var l_empty = Label.new()
			l_empty.text = "  SLOT DUNIA %d   —   [ KOSONG / BELUM ADA DUNIA ]" % slot
			l_empty.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			l_empty.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
			_style_pixel_label(l_empty, 18, Color(0.70, 0.66, 0.58), 4)
			hb.add_child(l_empty)

			var b_create = Button.new()
			b_create.text = "+ BUAT DUNIA BARU"
			b_create.custom_minimum_size = Vector2(240, 56)
			b_create.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.18, 0.50, 0.28), Color(0.94, 0.84, 0.40, 1.0)))
			_style_pixel_label(b_create, 17, Color(1, 0.98, 0.85))
			b_create.pressed.connect(_open_create_world_modal.bind(slot))
			hb.add_child(b_create)

		world_slots_box.add_child(card)


func _on_play_world_slot(slot):
	Game.play_sfx("ui", 1.08, 0.9)
	world_select_screen.visible = false
	Game.load_world_slot(slot)
	_start_loading("world", "MEMUAT DUNIA: " + Game.world_name.to_upper())


func _on_delete_world_slot(slot):
	Game.play_sfx("ui", 0.85, 0.85)
	Game.delete_world_slot(slot)
	_refresh_world_slots()


func _build_create_world_modal():
	create_world_modal = Panel.new()
	create_world_modal.visible = false
	create_world_modal.size = Vector2(640, 380)
	create_world_modal.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.14, 0.09, 0.05, 0.98)))
	root.add_child(create_world_modal)

	var title = Label.new()
	title.text = "BUAT DUNIA BARU"
	title.position = Vector2(24, 18)
	title.size = Vector2(592, 32)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_style_pixel_label(title, 24, Color(0.98, 0.86, 0.40), 6)
	create_world_modal.add_child(title)

	var l_nm = Label.new()
	l_nm.text = "Nama Dunia Baru:"
	l_nm.position = Vector2(40, 72)
	_style_pixel_label(l_nm, 17)
	create_world_modal.add_child(l_nm)

	create_name_input = LineEdit.new()
	create_name_input.text = "Samudra Nusantara"
	create_name_input.position = Vector2(40, 104)
	create_name_input.size = Vector2(410, 48)
	create_name_input.add_theme_font_size_override("font_size", 18)
	create_world_modal.add_child(create_name_input)

	var b_rand = Button.new()
	b_rand.text = "ACAK NAMA"
	b_rand.position = Vector2(464, 104)
	b_rand.size = Vector2(136, 48)
	b_rand.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.32, 0.24, 0.16)))
	_style_pixel_label(b_rand, 15)
	b_rand.pressed.connect(_on_random_world_name)
	create_world_modal.add_child(b_rand)

	var l_df = Label.new()
	l_df.text = "Mode & Tingkat Kesulitan:"
	l_df.position = Vector2(40, 172)
	_style_pixel_label(l_df, 17)
	create_world_modal.add_child(l_df)

	create_diff_btn = Button.new()
	create_diff_btn.position = Vector2(40, 204)
	create_diff_btn.size = Vector2(560, 56)
	create_diff_btn.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.20, 0.34, 0.46)))
	_style_pixel_label(create_diff_btn, 17, Color(0.55, 0.98, 0.65))
	create_diff_btn.pressed.connect(_cycle_create_difficulty)
	create_world_modal.add_child(create_diff_btn)

	var b_cancel = Button.new()
	b_cancel.text = "BATAL"
	b_cancel.position = Vector2(40, 292)
	b_cancel.size = Vector2(220, 58)
	b_cancel.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.52, 0.18, 0.16)))
	_style_pixel_label(b_cancel, 18)
	b_cancel.pressed.connect(_close_create_world_modal)
	create_world_modal.add_child(b_cancel)

	var b_go = Button.new()
	b_go.text = "BUAT & MULAI BERLAYAR!"
	b_go.position = Vector2(280, 292)
	b_go.size = Vector2(320, 58)
	b_go.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.18, 0.52, 0.26), Color(0.96, 0.86, 0.40, 1.0)))
	_style_pixel_label(b_go, 19, Color(1, 0.98, 0.86))
	b_go.pressed.connect(_confirm_create_world)
	create_world_modal.add_child(b_go)


func _open_create_world_modal(slot):
	Game.play_sfx("ui", 1.05, 0.85)
	create_slot_target = slot
	var names = ["Samudra Biru #1", "Ekspedisi Rakit", "Kepulauan Tropis", "Arus Pasifik"]
	create_name_input.text = names[(slot - 1) % names.size()]
	create_diff_val = "survival"
	_update_create_diff_label()
	create_world_modal.visible = true


func _close_create_world_modal():
	Game.play_sfx("ui", 0.9, 0.8)
	create_world_modal.visible = false


func _on_random_world_name():
	Game.play_sfx("ui", 1.08, 0.8)
	var pool = [
		"Samudra Nusantara",
		"Ekspedisi Krakatau",
		"Lautan Hiu Putih",
		"Pulau Harapan",
		"Arus Khatulistiwa",
		"Rakit Penjelajah",
	]
	create_name_input.text = pool.pick_random()


func _cycle_create_difficulty():
	Game.play_sfx("ui", 1.02, 0.8)
	var order = ["peaceful", "survival", "hardcore"]
	var i = (order.find(create_diff_val) + 1) % 3
	create_diff_val = order[i]
	_update_create_diff_label()


func _update_create_diff_label():
	if create_diff_btn == null:
		return
	if create_diff_val == "peaceful":
		create_diff_btn.text = "MODE SANTAI (Mudah — Lapar & Haus Berkurang Lebih Lambat)"
	elif create_diff_val == "hardcore":
		create_diff_btn.text = "MODE HARDCORE (Sulit — Tantangan Bertahan Hidup Ekstrem)"
	else:
		create_diff_btn.text = "MODE SURVIVAL (Normal — Pengalaman Standar Raft Mobile)"


func _confirm_create_world():
	Game.play_sfx("build", 1.08, 0.95)
	create_world_modal.visible = false
	world_select_screen.visible = false
	Game.create_new_world(create_slot_target, create_name_input.text, create_diff_val)
	_start_loading("world", "MEMBANGUN DUNIA BARU: " + Game.world_name.to_upper())


func _build_loading_screen():
	loading_screen = Control.new()
	loading_screen.visible = false
	loading_screen.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(loading_screen)

	var bg = ColorRect.new()
	bg.color = Color(0.03, 0.07, 0.13, 0.98)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	loading_screen.add_child(bg)

	var box = Panel.new()
	box.name = "LoadBox"
	box.size = Vector2(680, 290)
	box.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.14, 0.09, 0.05, 0.98)))
	loading_screen.add_child(box)

	loading_title_lbl = Label.new()
	loading_title_lbl.text = "MEMUAT DUNIA..."
	loading_title_lbl.position = Vector2(24, 28)
	loading_title_lbl.size = Vector2(632, 38)
	loading_title_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_style_pixel_label(loading_title_lbl, 26, Color(0.98, 0.86, 0.40), 6)
	box.add_child(loading_title_lbl)

	loading_stage_lbl = Label.new()
	loading_stage_lbl.text = "Menyiapkan gelombang samudra & rakit..."
	loading_stage_lbl.position = Vector2(24, 78)
	loading_stage_lbl.size = Vector2(632, 28)
	loading_stage_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_style_pixel_label(loading_stage_lbl, 16, Color(0.84, 0.94, 0.86), 4)
	box.add_child(loading_stage_lbl)

	var bar_bg = Panel.new()
	bar_bg.position = Vector2(50, 122)
	bar_bg.size = Vector2(580, 42)
	bar_bg.add_theme_stylebox_override("panel", PixelUI.get_bar_bg_style())
	box.add_child(bar_bg)

	loading_bar_fill = Panel.new()
	loading_bar_fill.position = Vector2(4, 4)
	loading_bar_fill.size = Vector2(10, 34)
	loading_bar_fill.add_theme_stylebox_override("panel", PixelUI.get_bar_fill_style(Color(0.22, 0.78, 0.40)))
	bar_bg.add_child(loading_bar_fill)

	loading_pct_lbl = Label.new()
	loading_pct_lbl.text = "0%"
	loading_pct_lbl.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	loading_pct_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	loading_pct_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_style_pixel_label(loading_pct_lbl, 18, Color(1, 1, 0.92), 5)
	bar_bg.add_child(loading_pct_lbl)

	loading_tip_lbl = Label.new()
	loading_tip_lbl.text = TIPS[0]
	loading_tip_lbl.position = Vector2(28, 192)
	loading_tip_lbl.size = Vector2(624, 72)
	loading_tip_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	loading_tip_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_style_pixel_label(loading_tip_lbl, 15, Color(0.94, 0.84, 0.56), 4)
	box.add_child(loading_tip_lbl)


func _start_loading(target_mode, title_txt):
	_release_all()
	is_loading = true
	loading_progress = 0.0
	loading_target_mode = target_mode
	Game.menu_open = true
	hud_gameplay_layer.visible = false
	menu.visible = false
	settings_modal.visible = false
	death_panel.visible = false
	title_screen.visible = false
	world_select_screen.visible = false
	create_world_modal.visible = false
	loading_title_lbl.text = title_txt
	loading_tip_lbl.text = TIPS.pick_random()
	loading_screen.visible = true


func _update_loading(delta):
	if not is_loading:
		return
	var speed = 1.15 if loading_target_mode == "boot" else 0.78
	loading_progress = min(1.0, loading_progress + delta * speed)
	loading_bar_fill.size.x = 572.0 * loading_progress
	var pct = int(round(loading_progress * 100.0))
	loading_pct_lbl.text = "%d%%" % pct

	if loading_progress < 0.32:
		loading_stage_lbl.text = "Menyiapkan mesin audio SFX 22kHz & gelombang laut..."
	elif loading_progress < 0.68:
		loading_stage_lbl.text = "Merender ikon 3D, kemudi layar 360°, & pulau tropis..."
	elif loading_progress < 0.92:
		loading_stage_lbl.text = "Menyiapkan bangunan tembok, kebun, & bawah laut..."
	else:
		loading_stage_lbl.text = "Siap berlayar!"

	if loading_progress >= 1.0:
		is_loading = false
		loading_screen.visible = false
		if loading_target_mode == "boot":
			Game.in_world = false
			Game.menu_open = true
			title_screen.visible = true
		else:
			Game.in_world = true
			Game.menu_open = false
			hud_gameplay_layer.visible = true
			_on_stats()
			_refresh_hotbar()
			show_message("Selamat datang di %s! Buat Layar Kapal di TAS untuk berlayar ke Pulau." % Game.world_name)


func return_to_main_menu():
	_release_all()
	if main_node != null and main_node.raft != null and Game.in_world:
		Game.save_current_world(main_node.raft.export_tile_list(), main_node.raft.structures)
	if main_node != null and main_node.build_mode:
		main_node.set_build_mode_state(false)
	menu.visible = false
	settings_modal.visible = false
	hud_edit_bar.visible = false
	hud_edit_mode = false
	death_panel.visible = false
	hud_gameplay_layer.visible = false
	Game.in_world = false
	Game.menu_open = true
	title_screen.visible = true
	Game.play_sfx("ui", 0.95, 0.85)


# ---------- Gameplay HUD ----------

func _build_status_hud():
	status_panel = Panel.new()
	status_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	status_panel.position = Vector2(16, 14)
	status_panel.size = Vector2(292, 134)
	status_panel.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.16, 0.10, 0.05, 0.92)))
	hud_gameplay_layer.add_child(status_panel)

	day_label = Label.new()
	day_label.text = "HARI 1  |  SIANG"
	day_label.position = Vector2(12, 8)
	day_label.size = Vector2(195, 22)
	day_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(day_label, 13, Color(0.96, 0.84, 0.42), 4)
	status_panel.add_child(day_label)

	fps_label = Label.new()
	fps_label.text = "60 FPS"
	fps_label.position = Vector2(204, 8)
	fps_label.size = Vector2(76, 22)
	fps_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	fps_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(fps_label, 13, Color(0.45, 0.92, 0.55), 4)
	status_panel.add_child(fps_label)

	_make_bar("health", "NYAWA", "heart", Color(0.84, 0.22, 0.22), 34)
	_make_bar("hunger", "LAPAR", "hunger", Color(0.86, 0.52, 0.16), 66)
	_make_bar("thirst", "HAUS", "thirst", Color(0.20, 0.60, 0.92), 98)

	# F1 & F2: Compass + Wind + Weather HUD Bar
	compass_weather_lbl = Label.new()
	compass_weather_lbl.text = "KOMPAS: UTARA  |  CUACA: CERAH"
	compass_weather_lbl.position = Vector2(320, 12)
	compass_weather_lbl.size = Vector2(400, 22)
	compass_weather_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(compass_weather_lbl, 13, Color(0.96, 0.90, 0.68), 4)
	hud_gameplay_layer.add_child(compass_weather_lbl)

	island_radar_lbl = Label.new()
	island_radar_lbl.text = ""
	island_radar_lbl.position = Vector2(320, 34)
	island_radar_lbl.size = Vector2(420, 24)
	island_radar_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(island_radar_lbl, 14, Color(0.48, 0.98, 0.68), 5)
	hud_gameplay_layer.add_child(island_radar_lbl)

	# F4: Oxygen Bar when Diving Underwater
	oxy_bg = Panel.new()
	oxy_bg.size = Vector2(220, 24)
	oxy_bg.visible = false
	oxy_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	oxy_bg.add_theme_stylebox_override("panel", PixelUI.get_bar_bg_style())
	hud_gameplay_layer.add_child(oxy_bg)

	oxy_fill = Panel.new()
	oxy_fill.position = Vector2(3, 3)
	oxy_fill.size = Vector2(214, 18)
	oxy_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	oxy_fill.add_theme_stylebox_override("panel", PixelUI.get_bar_fill_style(Color(0.22, 0.82, 0.98)))
	oxy_bg.add_child(oxy_fill)

	oxy_lbl = Label.new()
	oxy_lbl.text = "OKSIGEN SELAM: 100%"
	oxy_lbl.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	oxy_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	oxy_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	oxy_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(oxy_lbl, 12, Color(1, 1, 0.95), 4)
	oxy_bg.add_child(oxy_lbl)


# Point #5 & Point #3: Interactive 360° Sail Steering Bar + Modular Build Selector Bar
func _build_sail_and_build_bars():
	sail_ctrl_panel = Panel.new()
	sail_ctrl_panel.size = Vector2(460, 48)
	sail_ctrl_panel.visible = false
	sail_ctrl_panel.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.14, 0.10, 0.06, 0.94)))
	hud_gameplay_layer.add_child(sail_ctrl_panel)

	var shb = HBoxContainer.new()
	shb.position = Vector2(8, 5)
	shb.size = Vector2(444, 38)
	shb.alignment = BoxContainer.ALIGNMENT_CENTER
	shb.add_theme_constant_override("separation", 6)
	sail_ctrl_panel.add_child(shb)

	var b_left = Button.new()
	b_left.text = "◄ PUTAR KIRI"
	b_left.custom_minimum_size = Vector2(118, 36)
	b_left.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.24, 0.34, 0.46)))
	_style_pixel_label(b_left, 12)
	b_left.pressed.connect(Game.rotate_sail.bind(-30.0))
	shb.add_child(b_left)

	sail_toggle_btn = Button.new()
	sail_toggle_btn.text = "LAYAR: TUTUP (0°)"
	sail_toggle_btn.custom_minimum_size = Vector2(190, 36)
	sail_toggle_btn.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.18, 0.50, 0.28)))
	_style_pixel_label(sail_toggle_btn, 12, Color(1, 0.98, 0.85))
	sail_toggle_btn.pressed.connect(Game.toggle_sail)
	shb.add_child(sail_toggle_btn)

	var b_right = Button.new()
	b_right.text = "PUTAR KANAN ►"
	b_right.custom_minimum_size = Vector2(118, 36)
	b_right.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.24, 0.34, 0.46)))
	_style_pixel_label(b_right, 12)
	b_right.pressed.connect(Game.rotate_sail.bind(30.0))
	shb.add_child(b_right)

	# Build Mode Selector Bar (Point #3 & F15)
	build_ctrl_panel = Panel.new()
	build_ctrl_panel.size = Vector2(620, 50)
	build_ctrl_panel.visible = false
	build_ctrl_panel.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.14, 0.30, 0.16, 0.96), Color(0.45, 0.92, 0.50, 1.0)))
	hud_gameplay_layer.add_child(build_ctrl_panel)

	var bhb = HBoxContainer.new()
	bhb.position = Vector2(8, 6)
	bhb.size = Vector2(604, 38)
	bhb.alignment = BoxContainer.ALIGNMENT_CENTER
	bhb.add_theme_constant_override("separation", 8)
	build_ctrl_panel.add_child(bhb)

	build_type_btn = Button.new()
	build_type_btn.text = "TIPE: PONDASI RAKIT"
	build_type_btn.custom_minimum_size = Vector2(250, 36)
	build_type_btn.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.22, 0.48, 0.26)))
	_style_pixel_label(build_type_btn, 13, Color(1, 0.98, 0.84))
	build_type_btn.pressed.connect(_cycle_build_type)
	bhb.add_child(build_type_btn)

	build_rot_btn = Button.new()
	build_rot_btn.text = "PUTAR ARAH (0°)"
	build_rot_btn.custom_minimum_size = Vector2(160, 36)
	build_rot_btn.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.26, 0.36, 0.48)))
	_style_pixel_label(build_rot_btn, 13)
	build_rot_btn.pressed.connect(_rotate_build_dir)
	bhb.add_child(build_rot_btn)

	var paint_btn = Button.new()
	paint_btn.text = "CAT WARNA RAKIT"
	paint_btn.custom_minimum_size = Vector2(168, 36)
	paint_btn.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.56, 0.36, 0.16)))
	_style_pixel_label(paint_btn, 13)
	paint_btn.pressed.connect(Game.cycle_paint_theme)
	bhb.add_child(paint_btn)


func _cycle_build_type():
	var idx = (Game.BUILDABLE_ITEMS.find(Game.build_selected_type) + 1) % Game.BUILDABLE_ITEMS.size()
	Game.build_selected_type = Game.BUILDABLE_ITEMS[idx]
	Game.play_sfx("ui", 1.06, 0.8)
	_update_build_bar_labels()


func _rotate_build_dir():
	Game.build_rot = (Game.build_rot + 1) % 4
	Game.play_sfx("ui", 1.04, 0.8)
	_update_build_bar_labels()


func _update_build_bar_labels():
	if build_type_btn != null:
		var bt = Game.build_selected_type
		build_type_btn.text = "PILIH: %s (x%d)" % [Game.ITEM_NAMES.get(bt, bt).to_upper(), Game.count(bt)]
	if build_rot_btn != null:
		build_rot_btn.text = "PUTAR ARAH (%d°)" % ((Game.build_rot % 4) * 90)


func _make_bar(key, title, icon_id, color, y):
	var ic = TextureRect.new()
	ic.texture = PixelUI.get_icon(icon_id)
	ic.stretch_mode = TextureRect.STRETCH_SCALE
	ic.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	ic.position = Vector2(10, y + 1)
	ic.size = Vector2(24, 24)
	ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	status_panel.add_child(ic)

	var bg = Panel.new()
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.position = Vector2(38, y)
	bg.size = Vector2(242, 26)
	bg.add_theme_stylebox_override("panel", PixelUI.get_bar_bg_style())
	status_panel.add_child(bg)

	var fill = Panel.new()
	fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fill.position = Vector2(3, 3)
	fill.size = Vector2(236, 20)
	fill.add_theme_stylebox_override("panel", PixelUI.get_bar_fill_style(color))
	bg.add_child(fill)

	var lb = Label.new()
	lb.text = title
	lb.position = Vector2(8, 2)
	lb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(lb, 13, Color(0.98, 0.96, 0.90), 4)
	bg.add_child(lb)

	var pct = Label.new()
	pct.text = "100%"
	pct.position = Vector2(172, 2)
	pct.size = Vector2(62, 20)
	pct.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	pct.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(pct, 13, Color(0.98, 0.96, 0.86), 4)
	bg.add_child(pct)

	bar_fills[key] = fill
	bar_pcts[key] = pct


func _build_joystick_and_crosshair():
	joy_base = TextureRect.new()
	joy_base.texture = PixelUI.make_joy_ring_tex()
	joy_base.stretch_mode = TextureRect.STRETCH_SCALE
	joy_base.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	joy_base.size = Vector2(JOY_R * 2.0, JOY_R * 2.0)
	joy_base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_gameplay_layer.add_child(joy_base)

	joy_knob = TextureRect.new()
	joy_knob.texture = PixelUI.make_joy_knob_tex()
	joy_knob.stretch_mode = TextureRect.STRETCH_SCALE
	joy_knob.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	joy_knob.size = Vector2(72.0, 72.0)
	joy_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_gameplay_layer.add_child(joy_knob)

	cross_box = Control.new()
	cross_box.size = Vector2(24, 24)
	cross_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_gameplay_layer.add_child(cross_box)

	cross_h = ColorRect.new()
	cross_h.color = Color(0.95, 0.92, 0.80, 0.90)
	cross_h.position = Vector2(3, 10)
	cross_h.size = Vector2(18, 4)
	cross_h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cross_box.add_child(cross_h)

	cross_v = ColorRect.new()
	cross_v.color = Color(0.95, 0.92, 0.80, 0.90)
	cross_v.position = Vector2(10, 3)
	cross_v.size = Vector2(4, 18)
	cross_v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cross_box.add_child(cross_v)

	aim_label = Label.new()
	aim_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	aim_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(aim_label, 15, Color(0.52, 0.96, 0.60), 5)
	hud_gameplay_layer.add_child(aim_label)

	charge_bg = Panel.new()
	charge_bg.size = Vector2(164, 20)
	charge_bg.visible = false
	charge_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	charge_bg.add_theme_stylebox_override("panel", PixelUI.get_bar_bg_style())
	hud_gameplay_layer.add_child(charge_bg)

	charge_fill = Panel.new()
	charge_fill.position = Vector2(3, 3)
	charge_fill.size = Vector2(158, 14)
	charge_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	charge_fill.add_theme_stylebox_override("panel", PixelUI.get_bar_fill_style(Color(0.24, 0.84, 0.42)))
	charge_bg.add_child(charge_fill)

	charge_label = Label.new()
	charge_label.text = "DAYA LEMPAR"
	charge_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	charge_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	charge_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	charge_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(charge_label, 11, Color(1, 1, 0.9), 3)
	charge_bg.add_child(charge_label)


func _build_action_buttons():
	_make_button("hook", "HOOK", "hook", Color(0.16, 0.46, 0.26, 0.92), 16)
	_make_button("attack", "SERANG", "spear", Color(0.58, 0.19, 0.16, 0.92), 15)
	_make_button("jump", "LOMPAT", "jump", Color(0.22, 0.32, 0.44, 0.92), 15)
	_make_button("dive", "SELAM", "dive", Color(0.14, 0.42, 0.64, 0.92), 14)
	_make_button("fish", "PANCING", "rod", Color(0.16, 0.36, 0.58, 0.92), 14)
	_make_button("place", "PASANG", "hammer", Color(0.72, 0.48, 0.12, 0.96), 16)
	_make_button("use_hand", "PAKAI", "water", Color(0.20, 0.50, 0.32, 0.94), 15)
	_make_button("anchor", "JANGKAR", "anchor", Color(0.28, 0.34, 0.44, 0.94), 13)
	_make_button("sleep", "TIDUR", "hammock", Color(0.32, 0.24, 0.52, 0.94), 14)
	_make_button("bag", "TAS", "bag", Color(0.34, 0.22, 0.12, 0.94), 16)
	_make_button("build", "BANGUN", "hammer", Color(0.30, 0.24, 0.16, 0.94), 15)
	_make_button("settings", "SETELAN", "settings", Color(0.20, 0.26, 0.34, 0.94), 14)
	btns["place"].visible = false
	btns["use_hand"].visible = false
	btns["anchor"].visible = false
	btns["dive"].visible = false
	btns["sleep"].visible = false


func _make_button(id, text, icon_id, color, fsize):
	var p = Panel.new()
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_theme_stylebox_override("panel", PixelUI.get_pixel_button_style(color))
	btn_colors[id] = color

	var ic = TextureRect.new()
	ic.texture = PixelUI.get_icon(icon_id)
	ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	ic.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ic.position = Vector2(0, 6)
	p.add_child(ic)

	var l = Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(l, fsize, Color(0.98, 0.94, 0.82), 5)
	p.add_child(l)

	hud_gameplay_layer.add_child(p)
	btns[id] = p
	btn_labels[id] = l
	btn_icons[id] = ic


# ---------- Minecraft-Style 8-Slot Hotbar ----------

func _build_hotbar():
	hotbar_panel = Panel.new()
	hotbar_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hotbar_panel.size = Vector2(494, 68)
	hotbar_panel.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.14, 0.09, 0.05, 0.92)))
	hud_gameplay_layer.add_child(hotbar_panel)

	hotbar_box = HBoxContainer.new()
	hotbar_box.position = Vector2(9, 7)
	hotbar_box.size = Vector2(476, 54)
	hotbar_box.alignment = BoxContainer.ALIGNMENT_CENTER
	hotbar_box.mouse_filter = Control.MOUSE_FILTER_PASS
	hotbar_box.add_theme_constant_override("separation", 6)
	hotbar_panel.add_child(hotbar_box)


func _refresh_hotbar():
	if hotbar_box == null:
		return
	for c in hotbar_box.get_children():
		c.queue_free()

	for i in range(Game.HOTBAR_SIZE):
		var slot_data = Game.hotbar[i] if i < Game.hotbar.size() else {"id": "", "count": 0}
		var id = str(slot_data.get("id", ""))
		var cnt = int(slot_data.get("count", 0))
		var is_sel = (Game.selected_hotbar == i)

		var slot_btn = Button.new()
		slot_btn.custom_minimum_size = Vector2(54, 54)
		var st = PixelUI.get_slot_style(is_sel, false)
		slot_btn.add_theme_stylebox_override("normal", st)
		slot_btn.add_theme_stylebox_override("hover", st)
		slot_btn.add_theme_stylebox_override("pressed", PixelUI.get_slot_style(true, false))
		slot_btn.pressed.connect(_on_hotbar_slot_pressed.bind(i))

		if id != "" and cnt > 0:
			var ic = TextureRect.new()
			ic.texture = PixelUI.get_icon(id)
			ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			ic.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
			ic.position = Vector2(7, 5)
			ic.size = Vector2(40, 40)
			ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
			slot_btn.add_child(ic)

			if cnt > 1:
				var cnt_lbl = Label.new()
				cnt_lbl.text = str(cnt)
				cnt_lbl.position = Vector2(4, 30)
				cnt_lbl.size = Vector2(46, 20)
				cnt_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
				cnt_lbl.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
				cnt_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
				_style_pixel_label(cnt_lbl, 13, Color(1.0, 0.96, 0.82), 4)
				slot_btn.add_child(cnt_lbl)

		hotbar_box.add_child(slot_btn)


func _on_hotbar_slot_pressed(idx):
	if idx < 0 or idx >= Game.hotbar.size():
		return
	var s = Game.hotbar[idx]
	var id = str(s.get("id", ""))
	var cnt = int(s.get("count", 0))
	if Game.selected_hotbar == idx and id != "" and cnt > 0:
		if Game.USABLE.has(id) or Game.is_armor_item(id):
			Game.use_item(id)
			return
	Game.selected_hotbar = idx
	if id in Game.BUILDABLE_ITEMS:
		Game.build_selected_type = id
	Game.play_sfx("ui", 1.05, 0.7)
	_refresh_hotbar()
	if id != "" and cnt > 0:
		show_message(Game.ITEM_NAMES.get(id, id))


func _build_messages():
	msg_label = Label.new()
	msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(msg_label, 19, Color(0.98, 0.94, 0.80), 7)
	msg_label.modulate.a = 0.0
	hud_gameplay_layer.add_child(msg_label)


func _place_btn(id, default_pos, default_sz):
	var g_scale = clamp(float(Game.settings.get("hud_scale", 1.0)), 0.65, 1.45)
	var custom = Game.settings.get("custom_hud", {})
	var pos = default_pos
	var item_scale = g_scale
	if custom.has(id):
		var data = custom[id]
		if data.has("rx") and data.has("ry"):
			pos = Vector2(float(data["rx"]) * vp.x, float(data["ry"]) * vp.y)
		if data.has("scale"):
			item_scale = clamp(float(data["scale"]), 0.6, 1.55)
	var sz = default_sz * item_scale
	pos.x = clamp(pos.x, 4.0, max(4.0, vp.x - sz.x - 4.0))
	pos.y = clamp(pos.y, 4.0, max(4.0, vp.y - sz.y - 4.0))

	var b = btns[id]
	b.position = pos
	b.size = sz
	var ic = btn_icons[id]
	ic.position = Vector2(sz.x * 0.18, sz.y * 0.06)
	ic.size = Vector2(sz.x * 0.64, sz.y * 0.52)
	var lb = btn_labels[id]
	lb.position = Vector2(2, sz.y * 0.56)
	lb.size = Vector2(sz.x - 4, sz.y * 0.38)


func _layout():
	vp = get_viewport().get_visible_rect().size
	var W = vp.x
	var H = vp.y
	root.size = vp
	hud_gameplay_layer.size = vp
	if brightness_overlay != null:
		brightness_overlay.size = vp

	_place_btn("hook", Vector2(W - 295, H - 142), Vector2(118, 114))
	_place_btn("jump", Vector2(W - 148, H - 142), Vector2(114, 114))
	_place_btn("dive", Vector2(W - 295, H - 278), Vector2(114, 114))
	_place_btn("attack", Vector2(W - 148, H - 278), Vector2(114, 114))
	_place_btn("fish", Vector2(W - 295, H - 142), Vector2(118, 114))
	_place_btn("place", Vector2(W - 295, H - 142), Vector2(124, 114))
	_place_btn("use_hand", Vector2(W - 295, H - 142), Vector2(118, 114))
	_place_btn("anchor", Vector2(W - 542, 14), Vector2(122, 64))
	_place_btn("sleep", Vector2(W - 676, 14), Vector2(122, 64))
	_place_btn("bag", Vector2(W - 140, 14), Vector2(122, 64))
	_place_btn("build", Vector2(W - 274, 14), Vector2(122, 64))
	_place_btn("settings", Vector2(W - 408, 14), Vector2(122, 64))

	var custom = Game.settings.get("custom_hud", {})
	joy_home = Vector2(185, H - 185)
	if custom.has("joystick"):
		var jd = custom["joystick"]
		if jd.has("rx") and jd.has("ry"):
			joy_home = Vector2(float(jd["rx"]) * W, float(jd["ry"]) * H)
	_joy_idle()

	if custom.has("status_panel"):
		var sd = custom["status_panel"]
		if sd.has("rx") and sd.has("ry"):
			status_panel.position = Vector2(float(sd["rx"]) * W, float(sd["ry"]) * H)
	else:
		status_panel.position = Vector2(16, 14)

	hotbar_panel.position = Vector2(W / 2.0 - hotbar_panel.size.x / 2.0, H - 76)
	if sail_ctrl_panel != null:
		sail_ctrl_panel.position = Vector2(W / 2.0 - sail_ctrl_panel.size.x / 2.0, H - 130)
	if build_ctrl_panel != null:
		build_ctrl_panel.position = Vector2(W / 2.0 - build_ctrl_panel.size.x / 2.0, 84)
	if oxy_bg != null:
		oxy_bg.position = Vector2(W / 2.0 - 110, H / 2.0 - 76)

	cross_box.position = vp / 2.0 - Vector2(12, 12)
	aim_label.position = Vector2(W / 2.0 - 200, H / 2.0 + 18)
	aim_label.size = Vector2(400, 26)
	charge_bg.position = Vector2(W / 2.0 - 82, H / 2.0 + 46)

	msg_label.position = Vector2(W / 2.0 - 410, 142)
	msg_label.size = Vector2(820, 42)

	menu.position = (vp - menu.size) / 2.0
	settings_modal.position = (vp - settings_modal.size) / 2.0
	if hud_edit_bar != null:
		hud_edit_bar.position = Vector2(W / 2.0 - hud_edit_bar.size.x / 2.0, 12)
	death_panel.position = (vp - death_panel.size) / 2.0

	if title_screen != null:
		title_screen.size = vp
		var tc = title_screen.get_node_or_null("TitleCard")
		if tc != null:
			tc.position = (vp - tc.size) / 2.0
	if world_select_screen != null:
		world_select_screen.size = vp
		var wp = world_select_screen.get_node_or_null("WorldPanel")
		if wp != null:
			wp.position = (vp - wp.size) / 2.0
	if create_world_modal != null:
		create_world_modal.position = (vp - create_world_modal.size) / 2.0
	if loading_screen != null:
		loading_screen.size = vp
		var lb = loading_screen.get_node_or_null("LoadBox")
		if lb != null:
			lb.position = (vp - lb.size) / 2.0

	_apply_hud_opacity()


func _apply_hud_opacity():
	var op = clamp(float(Game.settings.get("hud_opacity", 0.92)), 0.30, 1.0)
	for id in btns:
		btns[id].modulate.a = op
	joy_base.modulate.a = op
	joy_knob.modulate.a = op
	status_panel.modulate.a = op
	hotbar_panel.modulate.a = op


func _on_settings_updated():
	if fps_label != null:
		fps_label.visible = bool(Game.settings.get("show_fps", true))
	_update_brightness_overlay()
	_layout()


func _joy_idle():
	joy_base.position = joy_home - Vector2(JOY_R, JOY_R)
	joy_knob.position = joy_home - Vector2(36, 36)


func _on_stats():
	var h = clamp(Game.health, 0.0, 100.0)
	var hu = clamp(Game.hunger, 0.0, 100.0)
	var th = clamp(Game.thirst, 0.0, 100.0)
	bar_fills["health"].size.x = 236.0 * (h / 100.0)
	bar_fills["hunger"].size.x = 236.0 * (hu / 100.0)
	bar_fills["thirst"].size.x = 236.0 * (th / 100.0)
	bar_pcts["health"].text = "%d%%" % int(round(h))
	bar_pcts["hunger"].text = "%d%%" % int(round(hu))
	bar_pcts["thirst"].text = "%d%%" % int(round(th))

	var tod = Game.time_of_day
	var phase_txt = "MALAM"
	if tod >= 0.22 and tod < 0.35:
		phase_txt = "PAGI"
	elif tod >= 0.35 and tod < 0.68:
		phase_txt = "SIANG"
	elif tod >= 0.68 and tod < 0.80:
		phase_txt = "SENJA"
	var def_val = Game.get_armor_defense()
	if def_val > 0:
		day_label.text = "HARI %d | %s | DEF +%d%%" % [Game.day_count, phase_txt, def_val]
	else:
		day_label.text = "HARI %d  |  %s" % [Game.day_count, phase_txt]


func _on_inventory_changed():
	_refresh_menu()
	_refresh_hotbar()
	_update_build_bar_labels()


func show_message(t):
	msg_label.text = t
	msg_label.modulate.a = 1.0
	msg_t = 3.2


func set_build_mode(on):
	build_ctrl_panel.visible = on
	_update_build_bar_labels()
	if on:
		btn_labels["build"].text = "BATAL [X]"
		btns["build"].add_theme_stylebox_override("panel", PixelUI.get_pixel_button_style(Color(0.20, 0.58, 0.28, 0.98), Color(0.96, 0.88, 0.34, 1.0), true))
	else:
		btn_labels["build"].text = "BANGUN"
		btns["build"].add_theme_stylebox_override("panel", PixelUI.get_pixel_button_style(btn_colors["build"]))


func _update_contextual_buttons():
	if hud_edit_mode:
		for k in ["hook", "attack", "fish", "place", "jump"]:
			btns[k].visible = true
		btns["use_hand"].visible = false
		btns["anchor"].visible = true
		btns["dive"].visible = false
		btns["sleep"].visible = false
		return

	var held_id = Game.get_selected_item_id()
	var b_mode = (main_node != null and main_node.build_mode) or (held_id in Game.BUILDABLE_ITEMS)
	build_ctrl_panel.visible = b_mode

	# Point #5: Sail 360° Steering Bar visibility & state
	sail_ctrl_panel.visible = Game.has_sail and (not Game.menu_open)
	if Game.has_sail and sail_toggle_btn != null:
		var s_deg = int(round(rad_to_deg(wrapf(Game.sail_angle, 0.0, TAU)))) % 360
		var s_dir = Game.get_compass_dir_name(Game.sail_angle)
		if Game.sail_open:
			sail_toggle_btn.text = "LAYAR: BUKA (%d° %s)" % [s_deg, s_dir]
			sail_toggle_btn.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.20, 0.58, 0.30), Color(0.98, 0.88, 0.36, 1.0), true))
		else:
			sail_toggle_btn.text = "BUKA LAYAR (%d° %s)" % [s_deg, s_dir]
			sail_toggle_btn.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.32, 0.24, 0.16)))

	# Anchor & Hammock Sleep buttons
	btns["anchor"].visible = Game.has_anchor
	if Game.has_anchor:
		if Game.anchor_down:
			btn_labels["anchor"].text = "REM: ON"
			btns["anchor"].add_theme_stylebox_override("panel", PixelUI.get_pixel_button_style(Color(0.20, 0.56, 0.30, 0.96), Color(0.98, 0.88, 0.36, 1.0), true))
		else:
			btn_labels["anchor"].text = "JANGKAR"
			btns["anchor"].add_theme_stylebox_override("panel", PixelUI.get_pixel_button_style(btn_colors["anchor"]))

	var is_night_or_dusk = (Game.time_of_day >= 0.70 or Game.time_of_day < 0.25)
	btns["sleep"].visible = (Game.hammocks > 0) and is_night_or_dusk

	# F4: Dive button & Oxygen bar when in water
	btns["dive"].visible = player.in_water
	oxy_bg.visible = player.in_water or Game.oxygen < 99.0
	if oxy_bg.visible:
		var ox = clamp(Game.oxygen, 0.0, 100.0)
		oxy_fill.size.x = 214.0 * (ox / 100.0)
		oxy_lbl.text = "OKSIGEN SELAM: %d%%" % int(round(ox))

	# Jump button switches to "Climbing Person" icon when player falls into water!
	if player.in_water != last_water_state:
		last_water_state = player.in_water
		if player.in_water:
			btn_icons["jump"].texture = PixelUI.get_icon("climb_person")
			btn_labels["jump"].text = "PANJAT"
			btns["jump"].add_theme_stylebox_override("panel", PixelUI.get_pixel_button_style(Color(0.18, 0.56, 0.42, 0.96), Color(0.98, 0.88, 0.36, 1.0)))
		else:
			btn_icons["jump"].texture = PixelUI.get_icon("jump")
			btn_labels["jump"].text = "LOMPAT"
			btns["jump"].add_theme_stylebox_override("panel", PixelUI.get_pixel_button_style(btn_colors["jump"]))

	# Contextual weapon/tool action buttons based on held item!
	if b_mode:
		btns["hook"].visible = false
		btns["attack"].visible = false
		btns["fish"].visible = false
		btns["use_hand"].visible = false
		btns["place"].visible = true
	elif held_id == "hook":
		btns["hook"].visible = true
		btns["attack"].visible = true
		btn_icons["attack"].texture = PixelUI.get_icon("hook")
		btn_labels["attack"].text = "SERANG"
		btns["fish"].visible = false
		btns["place"].visible = false
		btns["use_hand"].visible = false
	elif held_id == "spear":
		btns["hook"].visible = false
		btns["attack"].visible = true
		btn_icons["attack"].texture = PixelUI.get_icon("spear")
		btn_labels["attack"].text = "SERANG"
		btns["fish"].visible = false
		btns["place"].visible = false
		btns["use_hand"].visible = false
	elif held_id == "bow":
		btns["hook"].visible = false
		btns["attack"].visible = true
		btn_icons["attack"].texture = PixelUI.get_icon("bow")
		btn_labels["attack"].text = "PANAH (%d)" % Game.count("arrow")
		btns["fish"].visible = false
		btns["place"].visible = false
		btns["use_hand"].visible = false
	elif held_id == "paddle":
		btns["hook"].visible = false
		btns["attack"].visible = true
		btn_icons["attack"].texture = PixelUI.get_icon("paddle")
		btn_labels["attack"].text = "KAYUH"
		btns["fish"].visible = false
		btns["place"].visible = false
		btns["use_hand"].visible = false
	elif held_id == "hammer":
		btns["hook"].visible = false
		btns["attack"].visible = true
		btn_icons["attack"].texture = PixelUI.get_icon("hammer")
		btn_labels["attack"].text = "PERBAIKI"
		btns["fish"].visible = false
		btns["place"].visible = false
		btns["use_hand"].visible = false
	elif held_id == "shark_bait":
		btns["hook"].visible = false
		btns["attack"].visible = true
		btn_icons["attack"].texture = PixelUI.get_icon("shark_bait")
		btn_labels["attack"].text = "LEMPAR"
		btns["fish"].visible = false
		btns["place"].visible = false
		btns["use_hand"].visible = false
	elif held_id == "rod":
		btns["hook"].visible = false
		btns["attack"].visible = false
		btns["fish"].visible = true
		btns["place"].visible = false
		btns["use_hand"].visible = false
	elif Game.USABLE.has(held_id) or Game.is_armor_item(held_id):
		btns["hook"].visible = false
		btns["attack"].visible = false
		btns["fish"].visible = false
		btns["place"].visible = false
		btns["use_hand"].visible = true
		btn_icons["use_hand"].texture = PixelUI.get_icon(held_id)
		if held_id == "water":
			btn_labels["use_hand"].text = "MINUM"
		elif Game.is_armor_item(held_id):
			btn_labels["use_hand"].text = "PAKAI"
		else:
			btn_labels["use_hand"].text = "MAKAN"
	else:
		btns["hook"].visible = false
		btns["attack"].visible = true
		btn_icons["attack"].texture = PixelUI.get_icon("spear")
		btn_labels["attack"].text = "PUKUL"
		btns["fish"].visible = false
		btns["place"].visible = false
		btns["use_hand"].visible = false


func _process(delta):
	if is_loading:
		_update_loading(delta)
		return
	if msg_t > 0.0:
		msg_t -= delta
		msg_label.modulate.a = clamp(msg_t, 0.0, 1.0)
	if fps_label != null and fps_label.visible:
		fps_label.text = "%d FPS" % Engine.get_frames_per_second()
	if player == null or not Game.in_world:
		return

	_update_contextual_buttons()

	# F1 & F2: Update Compass & Weather Bar
	var cam_dir_name = Game.get_compass_dir_name(-player.yaw)
	compass_weather_lbl.text = "HADAP: %s  •  CUACA: %s" % [cam_dir_name, Game.weather_state.to_upper()]

	var nearest_isl = null
	var nearest_d = 9999.0
	for isl in get_tree().get_nodes_in_group("island"):
		if isl != null and is_instance_valid(isl):
			var d = player.global_position.distance_to(isl.global_position)
			if d < nearest_d:
				nearest_d = d
				nearest_isl = isl
	if nearest_isl != null and nearest_d <= 115.0:
		var to_isl = nearest_isl.global_position - player.global_position
		var isl_ang = wrapf(atan2(to_isl.z, to_isl.x), 0.0, TAU)
		var dir_str = Game.get_compass_dir_name(isl_ang)
		var kind_str = "RERUNTUHAN RAKIT" if nearest_isl.is_abandoned_raft else "PULAU TROPIS"
		island_radar_lbl.text = "%s: %dm di arah %s" % [kind_str, int(nearest_d), dir_str]
	else:
		island_radar_lbl.text = ""

	if player.fishing:
		btn_labels["fish"].text = "BATAL"
		btns["fish"].add_theme_stylebox_override("panel", PixelUI.get_pixel_button_style(Color(0.62, 0.26, 0.16, 0.95), Color(0.98, 0.84, 0.34, 1.0), true))
	else:
		btn_labels["fish"].text = "PANCING"
		btns["fish"].add_theme_stylebox_override("panel", PixelUI.get_pixel_button_style(btn_colors["fish"]))

	if player.hook_state == player.HookState.CHARGING:
		btn_labels["hook"].text = "LEPAS!"
		charge_bg.visible = true
		charge_fill.size.x = 158.0 * clamp(player.hook_charge, 0.0, 1.0)
		charge_label.text = "DAYA LEMPAR %d%%" % int(round(player.hook_charge * 100.0))
	elif player.hook_state == player.HookState.FLYING or player.hook_state == player.HookState.REELING:
		btn_labels["hook"].text = "TARIK!"
		charge_bg.visible = true
		var d = 0.0
		if player.hook_proj != null:
			d = player.hook_proj.global_position.distance_to(player.global_position)
		var pct = clamp(1.0 - (d / 29.0), 0.05, 1.0)
		charge_fill.size.x = 158.0 * pct
		if player.snagged_items.size() > 0:
			charge_label.text = "MENARIK %d BARANG..." % player.snagged_items.size()
		else:
			charge_label.text = "MENARIK KAIL (%dm)" % int(d)
	else:
		btn_labels["hook"].text = "HOOK"
		charge_bg.visible = false
		for k in held.keys():
			if held[k] == "hook":
				held.erase(k)

	var aim_info = player.get_aim_target_text()
	aim_label.text = aim_info["text"]
	if aim_info["type"] == "debris":
		cross_h.color = Color(0.32, 0.96, 0.48, 0.95)
		cross_v.color = Color(0.32, 0.96, 0.48, 0.95)
		aim_label.add_theme_color_override("font_color", Color(0.45, 0.98, 0.56))
	elif aim_info["type"] == "shark":
		cross_h.color = Color(0.98, 0.25, 0.22, 0.95)
		cross_v.color = Color(0.98, 0.25, 0.22, 0.95)
		aim_label.add_theme_color_override("font_color", Color(0.98, 0.38, 0.35))
	else:
		cross_h.color = Color(0.95, 0.92, 0.80, 0.90)
		cross_v.color = Color(0.95, 0.92, 0.80, 0.90)


# ---------- Input Sentuh & Custom HUD Drag Editor ----------

func _hit_control(ctrl, pos):
	if ctrl == null or not ctrl.visible:
		return false
	return Rect2(ctrl.position, ctrl.size).grow(8.0).has_point(pos)


func _input(event):
	if is_loading:
		return
	if hud_edit_mode:
		_handle_hud_editor_input(event)
		return
	if Game.dead or not Game.in_world:
		return
	if Game.menu_open:
		if event is InputEventScreenTouch and event.pressed:
			if _hit_control(btns["bag"], event.position):
				if menu.visible:
					close_menu()
				else:
					open_menu()
				return
			if _hit_control(btns["settings"], event.position):
				if settings_modal.visible:
					close_settings()
				else:
					open_settings()
				return
		return

	if event is InputEventScreenTouch:
		if event.pressed:
			_touch_down(event.index, event.position)
		else:
			_touch_up(event.index)
	elif event is InputEventScreenDrag:
		_touch_drag(event.index, event.position, event.relative)


func _touch_down(idx, pos):
	if _hit_control(hotbar_panel, pos) or _hit_control(sail_ctrl_panel, pos) or _hit_control(build_ctrl_panel, pos):
		return
	for id in ["bag", "settings", "build", "anchor", "sleep", "place", "use_hand", "hook", "attack", "jump", "dive", "fish"]:
		var b = btns[id]
		if _hit_control(b, pos):
			held[idx] = id
			_press(id)
			return
	if pos.x < vp.x * 0.45 and joy_finger == -1:
		joy_finger = idx
		joy_center = pos
		joy_vec = Vector2.ZERO
		joy_base.position = pos - Vector2(JOY_R, JOY_R)
		joy_knob.position = pos - Vector2(36, 36)
	elif look_finger == -1 and pos.x >= vp.x * 0.28:
		look_finger = idx


func _touch_up(idx):
	if held.has(idx):
		var id = held[idx]
		if id == "jump":
			player.jump_held = false
		elif id == "dive":
			player.dive_held = false
		elif id == "hook":
			player.release_hook_action()
		held.erase(idx)
	if idx == joy_finger:
		joy_finger = -1
		joy_vec = Vector2.ZERO
		player.move_input = Vector2.ZERO
		_joy_idle()
	if idx == look_finger:
		look_finger = -1


func _touch_drag(idx, pos, rel):
	if idx == joy_finger:
		var v = pos - joy_center
		if v.length() > JOY_R:
			v = v.normalized() * JOY_R
		joy_vec = v / JOY_R
		var out = joy_vec
		if out.length() < 0.12:
			out = Vector2.ZERO
		player.move_input = out
		joy_knob.position = joy_base.position + Vector2(JOY_R, JOY_R) - Vector2(36, 36) + v
	elif idx == look_finger:
		player.look_delta += rel


func _press(id):
	match id:
		"jump":
			player.jump_held = true
			if player.in_water:
				player._try_climb()
		"dive":
			player.dive_held = true
		"hook":
			player.start_hook_action()
		"attack":
			player.attack()
		"fish":
			player.toggle_fishing()
		"use_hand":
			var hid = Game.get_selected_item_id()
			if hid != "":
				Game.use_item(hid)
		"anchor":
			Game.toggle_anchor()
		"sleep":
			Game.sleep_until_morning()
		"bag":
			open_menu()
		"build":
			main_node.toggle_build()
		"place":
			main_node.place_foundation()
		"settings":
			open_settings()


func _release_all():
	joy_finger = -1
	look_finger = -1
	held.clear()
	joy_vec = Vector2.ZERO
	if player != null:
		player.move_input = Vector2.ZERO
		player.jump_held = false
		player.dive_held = false
		player.reel_boost = false
		if player.hook_state == player.HookState.CHARGING:
			player._reset_hook()
	_joy_idle()


# ---------- Menu TAS Bergaya Minecraft (4 Slot Armor + 20 Slot Tas + 8 Slot Hotbar + Crafting & Riset) ----------

func _build_bag_menu():
	menu = Panel.new()
	menu.visible = false
	menu.size = Vector2(960, 540)
	menu.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.13, 0.08, 0.04, 0.97)))
	root.add_child(menu)

	var title = Label.new()
	title.text = "TAS PENYIMPANAN  •  ARMOR  •  CRAFTING & RISET"
	title.position = Vector2(22, 14)
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(title, 19, Color(0.98, 0.86, 0.42), 6)
	menu.add_child(title)

	var btn_res = Button.new()
	btn_res.text = "RISET BAHAN"
	btn_res.position = Vector2(500, 12)
	btn_res.size = Vector2(140, 44)
	btn_res.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.46, 0.32, 0.16)))
	_style_pixel_label(btn_res, 14, Color(1, 0.95, 0.75))
	btn_res.pressed.connect(Game.do_research)
	menu.add_child(btn_res)

	var btn_set = Button.new()
	btn_set.text = "PENGATURAN"
	btn_set.position = Vector2(648, 12)
	btn_set.size = Vector2(148, 44)
	btn_set.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.22, 0.32, 0.44)))
	_style_pixel_label(btn_set, 15)
	btn_set.pressed.connect(_open_settings_from_bag)
	menu.add_child(btn_set)

	var close = Button.new()
	close.text = "TUTUP [X]"
	close.position = Vector2(806, 12)
	close.size = Vector2(134, 44)
	close.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.56, 0.18, 0.16)))
	_style_pixel_label(close, 15)
	close.pressed.connect(close_menu)
	menu.add_child(close)

	var arm_panel = Panel.new()
	arm_panel.position = Vector2(18, 64)
	arm_panel.size = Vector2(198, 456)
	arm_panel.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.17, 0.11, 0.06, 0.95)))
	menu.add_child(arm_panel)

	var arm_hdr = Label.new()
	arm_hdr.text = "SLOT ARMOR"
	arm_hdr.position = Vector2(12, 10)
	arm_hdr.size = Vector2(174, 24)
	arm_hdr.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_style_pixel_label(arm_hdr, 16, Color(0.96, 0.86, 0.48), 4)
	arm_panel.add_child(arm_hdr)

	armor_slots_box = VBoxContainer.new()
	armor_slots_box.position = Vector2(14, 42)
	armor_slots_box.size = Vector2(170, 320)
	armor_slots_box.add_theme_constant_override("separation", 10)
	arm_panel.add_child(armor_slots_box)

	armor_def_label = Label.new()
	armor_def_label.text = "PERTAHANAN: +0%\n(Ketuk armor untuk lepas)"
	armor_def_label.position = Vector2(10, 376)
	armor_def_label.size = Vector2(178, 68)
	armor_def_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_style_pixel_label(armor_def_label, 13, Color(0.55, 0.96, 0.65), 4)
	arm_panel.add_child(armor_def_label)

	var center_panel = Panel.new()
	center_panel.position = Vector2(226, 64)
	center_panel.size = Vector2(364, 456)
	center_panel.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.17, 0.11, 0.06, 0.95)))
	menu.add_child(center_panel)

	var bag_hdr = Label.new()
	bag_hdr.text = "PENYIMPANAN TAS (20 SLOT)"
	bag_hdr.position = Vector2(14, 10)
	_style_pixel_label(bag_hdr, 15, Color(0.94, 0.86, 0.68), 4)
	center_panel.add_child(bag_hdr)

	bag_grid = GridContainer.new()
	bag_grid.columns = 5
	bag_grid.position = Vector2(24, 38)
	bag_grid.add_theme_constant_override("h_separation", 8)
	bag_grid.add_theme_constant_override("v_separation", 8)
	center_panel.add_child(bag_grid)

	var hb_hdr = Label.new()
	hb_hdr.text = "SLOT HOTBAR BAWAH (8 SLOT)"
	hb_hdr.position = Vector2(14, 278)
	_style_pixel_label(hb_hdr, 14, Color(0.94, 0.86, 0.68), 4)
	center_panel.add_child(hb_hdr)

	bag_hotbar_grid = GridContainer.new()
	bag_hotbar_grid.columns = 4
	bag_hotbar_grid.position = Vector2(54, 302)
	bag_hotbar_grid.add_theme_constant_override("h_separation", 8)
	bag_hotbar_grid.add_theme_constant_override("v_separation", 6)
	center_panel.add_child(bag_hotbar_grid)

	bag_sel_info_lbl = Label.new()
	bag_sel_info_lbl.text = "Ketuk slot untuk memilih / memindahkan barang"
	bag_sel_info_lbl.position = Vector2(10, 418)
	bag_sel_info_lbl.size = Vector2(204, 32)
	_style_pixel_label(bag_sel_info_lbl, 12, Color(0.95, 0.90, 0.72), 3)
	center_panel.add_child(bag_sel_info_lbl)

	bag_use_btn = Button.new()
	bag_use_btn.text = "PAKAI"
	bag_use_btn.position = Vector2(216, 412)
	bag_use_btn.size = Vector2(70, 36)
	bag_use_btn.visible = false
	bag_use_btn.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.18, 0.52, 0.28)))
	_style_pixel_label(bag_use_btn, 13)
	bag_use_btn.pressed.connect(_on_bag_use_pressed)
	center_panel.add_child(bag_use_btn)

	bag_drop_btn = Button.new()
	bag_drop_btn.text = "BUANG"
	bag_drop_btn.position = Vector2(290, 412)
	bag_drop_btn.size = Vector2(64, 36)
	bag_drop_btn.visible = false
	bag_drop_btn.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.54, 0.18, 0.16)))
	_style_pixel_label(bag_drop_btn, 12)
	bag_drop_btn.pressed.connect(_on_bag_drop_pressed)
	center_panel.add_child(bag_drop_btn)

	var craft_panel = Panel.new()
	craft_panel.position = Vector2(600, 64)
	craft_panel.size = Vector2(342, 456)
	craft_panel.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.17, 0.11, 0.06, 0.95)))
	menu.add_child(craft_panel)

	var rec_hdr = Label.new()
	rec_hdr.text = "MEJA CRAFTING (LAYAR, TEMBOK, ALAT)"
	rec_hdr.position = Vector2(14, 10)
	_style_pixel_label(rec_hdr, 14, Color(0.98, 0.86, 0.45), 4)
	craft_panel.add_child(rec_hdr)

	var rec_scroll = ScrollContainer.new()
	rec_scroll.position = Vector2(12, 38)
	rec_scroll.size = Vector2(318, 406)
	rec_box = VBoxContainer.new()
	rec_box.custom_minimum_size = Vector2(300, 0)
	rec_box.mouse_filter = Control.MOUSE_FILTER_PASS
	rec_box.add_theme_constant_override("separation", 8)
	rec_scroll.add_child(rec_box)
	craft_panel.add_child(rec_scroll)


func open_menu():
	_release_all()
	if main_node != null and main_node.build_mode:
		main_node.set_build_mode_state(false)
	settings_modal.visible = false
	selected_inv_source = ""
	selected_inv_index = -1
	Game.menu_open = true
	menu.visible = true
	_refresh_menu()
	Game.play_sfx("ui", 1.0, 0.8)


func close_menu():
	menu.visible = false
	selected_inv_source = ""
	selected_inv_index = -1
	Game.menu_open = (not Game.in_world)
	Game.play_sfx("ui", 0.9, 0.7)


func _make_inv_slot_button(id, cnt, is_selected, is_armor_slot = false, placeholder_icon = ""):
	var b = Button.new()
	b.custom_minimum_size = Vector2(56, 52) if not is_armor_slot else Vector2(62, 62)
	var st = PixelUI.get_slot_style(is_selected, is_armor_slot)
	b.add_theme_stylebox_override("normal", st)
	b.add_theme_stylebox_override("hover", st)
	b.add_theme_stylebox_override("pressed", PixelUI.get_slot_style(true, is_armor_slot))

	if id != "" and cnt > 0:
		var ic = TextureRect.new()
		ic.texture = PixelUI.get_icon(id)
		ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		ic.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		ic.position = Vector2(8, 4) if not is_armor_slot else Vector2(10, 10)
		ic.size = Vector2(40, 40) if not is_armor_slot else Vector2(42, 42)
		ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
		b.add_child(ic)

		if cnt > 1:
			var l = Label.new()
			l.text = str(cnt)
			l.position = Vector2(4, 28)
			l.size = Vector2(48, 20)
			l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
			l.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
			l.mouse_filter = Control.MOUSE_FILTER_IGNORE
			_style_pixel_label(l, 12, Color(1, 0.96, 0.82), 4)
			b.add_child(l)
	elif is_armor_slot and placeholder_icon != "":
		var ph = TextureRect.new()
		ph.texture = PixelUI.get_icon(placeholder_icon)
		ph.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		ph.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		ph.position = Vector2(13, 13)
		ph.size = Vector2(36, 36)
		ph.modulate = Color(1, 1, 1, 0.25)
		ph.mouse_filter = Control.MOUSE_FILTER_IGNORE
		b.add_child(ph)

	return b


func _on_bag_slot_clicked(src_type, idx):
	var arr = Game.hotbar if src_type == "hotbar" else Game.bag_slots
	if idx < 0 or idx >= arr.size():
		return
	var clicked_id = str(arr[idx].get("id", ""))
	var clicked_cnt = int(arr[idx].get("count", 0))

	if selected_inv_source == "":
		if clicked_id != "" and clicked_cnt > 0:
			selected_inv_source = src_type
			selected_inv_index = idx
			Game.play_sfx("ui", 1.05, 0.75)
	elif selected_inv_source == src_type and selected_inv_index == idx:
		selected_inv_source = ""
		selected_inv_index = -1
		Game.play_sfx("ui", 0.92, 0.7)
	else:
		Game.swap_or_move_slots(selected_inv_source, selected_inv_index, src_type, idx)
		selected_inv_source = ""
		selected_inv_index = -1
	_refresh_menu()
	_refresh_hotbar()


func _on_armor_slot_clicked(part):
	if selected_inv_source in ["bag", "hotbar"] and selected_inv_index >= 0:
		var arr = Game.hotbar if selected_inv_source == "hotbar" else Game.bag_slots
		if selected_inv_index < arr.size():
			var sel_id = str(arr[selected_inv_index].get("id", ""))
			if Game.ARMOR_DEFS.has(sel_id) and Game.ARMOR_DEFS[sel_id]["slot"] == part:
				Game.equip_armor_from_slot(selected_inv_source, selected_inv_index)
				selected_inv_source = ""
				selected_inv_index = -1
				_refresh_menu()
				_refresh_hotbar()
				return
	var equipped = str(Game.armor_slots.get(part, ""))
	if equipped != "":
		Game.unequip_armor(part)
		selected_inv_source = ""
		selected_inv_index = -1
		_refresh_menu()
		_refresh_hotbar()


func _on_bag_use_pressed():
	if selected_inv_source not in ["bag", "hotbar"] or selected_inv_index < 0:
		return
	var arr = Game.hotbar if selected_inv_source == "hotbar" else Game.bag_slots
	if selected_inv_index >= arr.size():
		return
	var id = str(arr[selected_inv_index].get("id", ""))
	if id == "":
		return
	if Game.is_armor_item(id):
		Game.equip_armor_from_slot(selected_inv_source, selected_inv_index)
		selected_inv_source = ""
		selected_inv_index = -1
	elif Game.USABLE.has(id):
		Game.use_item(id)
		if int(arr[selected_inv_index].get("count", 0)) <= 0:
			selected_inv_source = ""
			selected_inv_index = -1
	_refresh_menu()
	_refresh_hotbar()


func _on_bag_drop_pressed():
	if selected_inv_source not in ["bag", "hotbar"] or selected_inv_index < 0:
		return
	Game.drop_one_from_slot(selected_inv_source, selected_inv_index)
	var arr = Game.hotbar if selected_inv_source == "hotbar" else Game.bag_slots
	if selected_inv_index < arr.size() and str(arr[selected_inv_index].get("id", "")) == "":
		selected_inv_source = ""
		selected_inv_index = -1
	_refresh_menu()
	_refresh_hotbar()


func _refresh_menu():
	if menu == null or bag_grid == null:
		return
	for c in armor_slots_box.get_children():
		c.queue_free()
	for c in bag_grid.get_children():
		c.queue_free()
	for c in bag_hotbar_grid.get_children():
		c.queue_free()
	for c in rec_box.get_children():
		c.queue_free()

	var armor_meta = [
		{"part": "head", "title": "KEPALA", "ph": "slot_head"},
		{"part": "chest", "title": "DADA", "ph": "slot_chest"},
		{"part": "legs", "title": "KAKI", "ph": "slot_legs"},
		{"part": "feet", "title": "SEPATU", "ph": "slot_feet"},
	]
	for am in armor_meta:
		var part = am["part"]
		var eq_id = str(Game.armor_slots.get(part, ""))
		var row = HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		var slot_btn = _make_inv_slot_button(eq_id, 1 if eq_id != "" else 0, false, true, am["ph"])
		slot_btn.pressed.connect(_on_armor_slot_clicked.bind(part))
		row.add_child(slot_btn)

		var lbl = Label.new()
		if eq_id != "" and Game.ARMOR_DEFS.has(eq_id):
			lbl.text = "%s\n+%d%% DEF" % [am["title"], int(Game.ARMOR_DEFS[eq_id]["def"])]
			_style_pixel_label(lbl, 13, Color(0.55, 0.98, 0.65), 4)
		else:
			lbl.text = "%s\n[Kosong]" % am["title"]
			_style_pixel_label(lbl, 12, Color(0.68, 0.64, 0.56), 3)
		lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(lbl)
		armor_slots_box.add_child(row)

	armor_def_label.text = "TOTAL PERTAHANAN: +%d%%\n(Mengurangi serangan hiu)" % Game.get_armor_defense()

	for i in range(Game.BAG_SIZE):
		var s = Game.bag_slots[i] if i < Game.bag_slots.size() else {"id": "", "count": 0}
		var is_sel = (selected_inv_source == "bag" and selected_inv_index == i)
		var btn = _make_inv_slot_button(str(s.get("id", "")), int(s.get("count", 0)), is_sel, false)
		btn.pressed.connect(_on_bag_slot_clicked.bind("bag", i))
		bag_grid.add_child(btn)

	for i in range(Game.HOTBAR_SIZE):
		var s = Game.hotbar[i] if i < Game.hotbar.size() else {"id": "", "count": 0}
		var is_sel = (selected_inv_source == "hotbar" and selected_inv_index == i)
		var btn = _make_inv_slot_button(str(s.get("id", "")), int(s.get("count", 0)), is_sel, false)
		btn.pressed.connect(_on_bag_slot_clicked.bind("hotbar", i))
		bag_hotbar_grid.add_child(btn)

	var sel_id = ""
	var sel_cnt = 0
	if selected_inv_source in ["bag", "hotbar"] and selected_inv_index >= 0:
		var arr = Game.hotbar if selected_inv_source == "hotbar" else Game.bag_slots
		if selected_inv_index < arr.size():
			sel_id = str(arr[selected_inv_index].get("id", ""))
			sel_cnt = int(arr[selected_inv_index].get("count", 0))

	if sel_id != "" and sel_cnt > 0:
		bag_sel_info_lbl.text = "%s (x%d)\nKetuk slot lain untuk pindah" % [Game.ITEM_NAMES.get(sel_id, sel_id), sel_cnt]
		bag_drop_btn.visible = true
		if Game.is_armor_item(sel_id):
			bag_use_btn.text = "PASANG"
			bag_use_btn.visible = true
		elif Game.USABLE.has(sel_id):
			bag_use_btn.text = "MAKAN"
			bag_use_btn.visible = true
		else:
			bag_use_btn.visible = false
	else:
		bag_sel_info_lbl.text = "Ketuk barang lalu ketuk slot kosong/lain untuk memindahkan"
		bag_use_btn.visible = false
		bag_drop_btn.visible = false

	for r in Game.RECIPES:
		var rid = r["id"]
		var costs = ""
		for k in r["cost"]:
			costs += "%d %s, " % [r["cost"][k], Game.ITEM_NAMES.get(k, k)]
		costs = costs.trim_suffix(", ")
		var owned = (rid == "rod" and Game.has_rod) or (rid == "spear" and Game.has_spear) or (rid == "bow" and Game.has_bow) or (rid == "paddle" and Game.has_paddle) or (rid == "hammer" and Game.has_hammer) or (rid == "anchor" and Game.has_anchor) or (rid == "sail" and Game.has_sail)
		if Game.ARMOR_DEFS.has(rid):
			var part = Game.ARMOR_DEFS[rid]["slot"]
			if str(Game.armor_slots.get(part, "")) == rid or Game.count(rid) > 0:
				owned = true
		var can_craft = (not owned) and Game.has_items(r["cost"])

		var row_card = PanelContainer.new()
		row_card.custom_minimum_size = Vector2(298, 66)
		row_card.mouse_filter = Control.MOUSE_FILTER_PASS
		var bg_c = Color(0.18, 0.34, 0.20, 0.95) if can_craft else Color(0.16, 0.12, 0.08, 0.92)
		row_card.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(bg_c))

		var hb = HBoxContainer.new()
		hb.mouse_filter = Control.MOUSE_FILTER_PASS
		hb.add_theme_constant_override("separation", 8)
		row_card.add_child(hb)

		var ic = TextureRect.new()
		ic.texture = PixelUI.get_icon(rid)
		ic.custom_minimum_size = Vector2(38, 38)
		ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		ic.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
		hb.add_child(ic)

		var txt_lbl = Label.new()
		var nm = r["name"] + (" [ADA]" if owned else "")
		txt_lbl.text = "%s\n%s" % [nm, costs]
		txt_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		txt_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		txt_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_style_pixel_label(txt_lbl, 11, Color(0.98, 0.95, 0.84) if can_craft else Color(0.68, 0.64, 0.58), 3)
		hb.add_child(txt_lbl)

		var b_craft = Button.new()
		b_craft.text = "BUAT"
		b_craft.custom_minimum_size = Vector2(66, 44)
		b_craft.disabled = not can_craft
		b_craft.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.20, 0.54, 0.28) if can_craft else Color(0.22, 0.18, 0.15)))
		b_craft.add_theme_stylebox_override("disabled", PixelUI.get_pixel_button_style(Color(0.15, 0.12, 0.10, 0.75)))
		_style_pixel_label(b_craft, 13, Color(1, 0.98, 0.86) if can_craft else Color(0.55, 0.52, 0.48), 3)
		b_craft.pressed.connect(Game.craft.bind(rid))
		hb.add_child(b_craft)

		rec_box.add_child(row_card)


# ---------- Menu Pengaturan ----------

func _build_settings_modal():
	settings_modal = Panel.new()
	settings_modal.visible = false
	settings_modal.size = Vector2(860, 500)
	settings_modal.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.13, 0.09, 0.06, 0.97)))
	root.add_child(settings_modal)

	var title = Label.new()
	title.text = "PENGATURAN GAME, BRIGHTNESS, & CUSTOM HUD"
	title.position = Vector2(24, 14)
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(title, 20, Color(0.98, 0.86, 0.42), 6)
	settings_modal.add_child(title)

	var btn_main_menu = Button.new()
	btn_main_menu.text = "MENU UTAMA"
	btn_main_menu.position = Vector2(494, 12)
	btn_main_menu.size = Vector2(160, 46)
	btn_main_menu.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.54, 0.25, 0.14)))
	_style_pixel_label(btn_main_menu, 15)
	btn_main_menu.pressed.connect(return_to_main_menu)
	settings_modal.add_child(btn_main_menu)

	var close = Button.new()
	close.text = "SIMPAN & TUTUP"
	close.position = Vector2(666, 12)
	close.size = Vector2(172, 46)
	close.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.18, 0.50, 0.26)))
	_style_pixel_label(close, 15)
	close.pressed.connect(close_settings)
	settings_modal.add_child(close)

	settings_tab_box = HBoxContainer.new()
	settings_tab_box.position = Vector2(24, 66)
	settings_tab_box.size = Vector2(812, 46)
	settings_tab_box.mouse_filter = Control.MOUSE_FILTER_PASS
	settings_tab_box.add_theme_constant_override("separation", 10)
	settings_modal.add_child(settings_tab_box)

	var scroll = ScrollContainer.new()
	scroll.position = Vector2(24, 122)
	scroll.size = Vector2(812, 356)
	settings_content_box = VBoxContainer.new()
	settings_content_box.custom_minimum_size = Vector2(790, 0)
	settings_content_box.mouse_filter = Control.MOUSE_FILTER_PASS
	settings_content_box.add_theme_constant_override("separation", 10)
	scroll.add_child(settings_content_box)
	settings_modal.add_child(scroll)


func open_settings():
	_release_all()
	if main_node != null and main_node.build_mode:
		main_node.set_build_mode_state(false)
	menu.visible = false
	Game.menu_open = true
	settings_modal.visible = true
	_rebuild_settings_ui()
	Game.play_sfx("ui", 1.0, 0.8)


func close_settings():
	Game.save_settings()
	settings_modal.visible = false
	if Game.in_world:
		Game.menu_open = false
	else:
		Game.menu_open = true
		if not world_select_screen.visible:
			title_screen.visible = true
	Game.play_sfx("ui", 1.0, 0.8)


func _switch_settings_tab(tab_id):
	current_settings_tab = tab_id
	_rebuild_settings_ui()
	Game.play_sfx("ui", 1.05, 0.8)


func _open_settings_from_bag():
	close_menu()
	open_settings()


func _invoke_setting_cb(cb):
	if cb.is_valid():
		cb.call()
	_rebuild_settings_ui()
	Game.play_sfx("ui", 1.02, 0.8)


func _step_gfx_preset(dir):
	var order = ["low", "medium", "high"]
	var cur = order.find(str(Game.settings.get("gfx_preset", "medium")))
	if cur < 0:
		cur = 1
	var idx = (cur + dir + 3) % 3
	Game.apply_gfx_preset(order[idx])


func _step_float_setting(key, delta_v, min_v, max_v):
	Game.settings[key] = clamp(float(Game.settings.get(key, min_v)) + delta_v, min_v, max_v)
	Game.apply_settings()


func _step_fps_limit(dir):
	var opts = [30, 60, 90, 0]
	var cur = opts.find(int(Game.settings.get("max_fps", 60)))
	if cur < 0:
		cur = 1
	var idx = (cur + dir + 4) % 4
	Game.settings["max_fps"] = opts[idx]
	Game.apply_settings()


func _step_wave_quality(dir):
	var wq = int(Game.settings.get("wave_quality", 2))
	var nxt = wq + dir
	if nxt < 1:
		nxt = 3
	elif nxt > 3:
		nxt = 1
	Game.settings["wave_quality"] = nxt
	Game.apply_settings()


func _step_view_dist(dir):
	var vd = int(Game.settings.get("view_dist", 1))
	Game.settings["view_dist"] = (vd + dir + 3) % 3
	Game.apply_settings()


func _toggle_bool_setting(key):
	Game.settings[key] = not bool(Game.settings.get(key, false))
	Game.apply_settings()


func _on_reset_hud_pressed():
	Game.reset_custom_hud()
	_rebuild_settings_ui()
	show_message("Tata letak HUD dikembalikan ke standar awal.")
	Game.play_sfx("ui", 0.85, 0.8)


func _on_editor_reset_pressed():
	Game.reset_custom_hud()
	_layout()
	Game.play_sfx("ui", 0.9, 0.8)


func _add_setting_row(label_text, value_text, on_prev, on_next):
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(786, 54)
	panel.mouse_filter = Control.MOUSE_FILTER_PASS
	panel.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.19, 0.12, 0.07, 0.94)))
	var hb = HBoxContainer.new()
	hb.mouse_filter = Control.MOUSE_FILTER_PASS
	hb.add_theme_constant_override("separation", 12)
	panel.add_child(hb)

	var lbl = Label.new()
	lbl.text = "  " + label_text
	lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(lbl, 16)
	hb.add_child(lbl)

	if on_prev.is_valid():
		var b_prev = Button.new()
		b_prev.text = " - "
		b_prev.custom_minimum_size = Vector2(56, 40)
		b_prev.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.32, 0.24, 0.16)))
		_style_pixel_label(b_prev, 18)
		b_prev.pressed.connect(_invoke_setting_cb.bind(on_prev))
		hb.add_child(b_prev)

	var val_lbl = Label.new()
	val_lbl.text = value_text
	val_lbl.custom_minimum_size = Vector2(185, 40)
	val_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	val_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	val_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(val_lbl, 16, Color(0.48, 0.96, 0.58), 4)
	hb.add_child(val_lbl)

	var b_next = Button.new()
	b_next.text = " + " if on_prev.is_valid() else "UBAH"
	b_next.custom_minimum_size = Vector2(56 if on_prev.is_valid() else 110, 40)
	b_next.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.22, 0.42, 0.26)))
	_style_pixel_label(b_next, 17)
	b_next.pressed.connect(_invoke_setting_cb.bind(on_next))
	hb.add_child(b_next)

	settings_content_box.add_child(panel)


func _rebuild_settings_ui():
	for c in settings_tab_box.get_children():
		c.queue_free()
	for c in settings_content_box.get_children():
		c.queue_free()

	var tabs = [
		{"id": "gfx", "title": "1. BRIGHTNESS, OMBAK & GRAFIK"},
		{"id": "ctrl", "title": "2. AUDIO & KONTROL HOOK"},
		{"id": "hud", "title": "3. CUSTOM HUD LAYOUT"},
	]
	for t in tabs:
		var tb = Button.new()
		tb.text = t["title"]
		tb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		tb.custom_minimum_size = Vector2(240, 44)
		var active = (current_settings_tab == t["id"])
		var col = Color(0.64, 0.44, 0.16) if active else Color(0.22, 0.15, 0.10)
		tb.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(col))
		_style_pixel_label(tb, 15, Color(1, 0.96, 0.82) if active else Color(0.75, 0.7, 0.62))
		tb.pressed.connect(_switch_settings_tab.bind(t["id"]))
		settings_tab_box.add_child(tb)

	if current_settings_tab == "gfx":
		var br_v = int(round(float(Game.settings.get("brightness", 0.75)) * 100.0))
		_add_setting_row("Kecerahan Layar (Brightness — Nyaman di Mata)", "%d%%" % br_v, _step_float_setting.bind("brightness", -0.10, 0.30, 1.30), _step_float_setting.bind("brightness", 0.10, 0.30, 1.30))

		var ws_v = int(round(float(Game.settings.get("wave_strength", 1.0)) * 100.0))
		_add_setting_row("Kekuatan Ombak & Goyangan Rakit", "%d%%" % ws_v, _step_float_setting.bind("wave_strength", -0.20, 0.40, 1.60), _step_float_setting.bind("wave_strength", 0.20, 0.40, 1.60))

		var preset = str(Game.settings.get("gfx_preset", "medium")).to_upper()
		var p_map = {"LOW": "RENDAH (Hemat Baterai)", "MEDIUM": "SEDANG (Seimbang)", "HIGH": "TINGGI (Ultra)"}
		_add_setting_row("Preset Kualitas Grafik", p_map.get(preset, preset), _step_gfx_preset.bind(-1), _step_gfx_preset.bind(1))

		var fps_val = int(Game.settings.get("max_fps", 60))
		var fps_txt = "TANPA BATAS" if fps_val == 0 else ("%d FPS" % fps_val)
		_add_setting_row("Batas Frame Rate (Target FPS)", fps_txt, _step_fps_limit.bind(-1), _step_fps_limit.bind(1))

		var wq = int(Game.settings.get("wave_quality", 2))
		var wq_names = {1: "RENDAH", 2: "SEDANG", 3: "TINGGI + BUIH OMBAK"}
		_add_setting_row("Detail Mesh Lautan Biru Tua", wq_names.get(wq, "SEDANG"), _step_wave_quality.bind(-1), _step_wave_quality.bind(1))

		var sh_on = bool(Game.settings.get("shadows", false))
		_add_setting_row("Bayangan Matahari Real-Time (Shadows)", "AKTIF" if sh_on else "NONAKTIF", Callable(), _toggle_bool_setting.bind("shadows"))

		var vd = int(Game.settings.get("view_dist", 1))
		var vd_names = {0: "DEKAT (Cepat)", 1: "NORMAL", 2: "JAUH (Luas)"}
		_add_setting_row("Jarak Pandang & Kabut Laut", vd_names.get(vd, "NORMAL"), _step_view_dist.bind(-1), _step_view_dist.bind(1))

		var fov_v = int(round(float(Game.settings.get("fov", 75.0))))
		_add_setting_row("Sudut Pandang Kamera FPS (FOV)", "%d Derajat" % fov_v, _step_float_setting.bind("fov", -5.0, 65.0, 95.0), _step_float_setting.bind("fov", 5.0, 65.0, 95.0))

		var sfps = bool(Game.settings.get("show_fps", true))
		_add_setting_row("Indikator FPS di Pojok Status", "TAMPIL" if sfps else "SEMBUNYI", Callable(), _toggle_bool_setting.bind("show_fps"))

	elif current_settings_tab == "ctrl":
		var sv = int(round(float(Game.settings.get("sfx_vol", 0.90)) * 100.0))
		_add_setting_row("Volume Efek Suara (SFX Hook, Air, Hiu)", "%d%%" % sv, _step_float_setting.bind("sfx_vol", -0.15, 0.0, 1.0), _step_float_setting.bind("sfx_vol", 0.15, 0.0, 1.0))

		var av = int(round(float(Game.settings.get("amb_vol", 0.65)) * 100.0))
		_add_setting_row("Volume Suara Ombak Samudra (Ambience)", "%d%%" % av, _step_float_setting.bind("amb_vol", -0.15, 0.0, 1.0), _step_float_setting.bind("amb_vol", 0.15, 0.0, 1.0))

		var sens_v = int(round(float(Game.settings.get("sens", 1.0)) * 100.0))
		_add_setting_row("Sensitivitas Geser Kamera (Look Sensitivity)", "%d%%" % sens_v, _step_float_setting.bind("sens", -0.2, 0.4, 2.4), _step_float_setting.bind("sens", 0.2, 0.4, 2.4))

		var ch_mode = bool(Game.settings.get("hook_charge_mode", true))
		_add_setting_row("Mode Lempar Grappling Hook", "TAHAN & LEPAS (CHARGE)" if ch_mode else "SEKALI TEKAN (INSTAN)", Callable(), _toggle_bool_setting.bind("hook_charge_mode"))

		var ar_mode = bool(Game.settings.get("auto_reel", true))
		_add_setting_row("Tarik Tali Hook Otomatis Saat Mendarat", "OTOMATIS + TOMBOL TARIK" if ar_mode else "MANUAL (TEKAN TARIK)", Callable(), _toggle_bool_setting.bind("auto_reel"))

		var inv_y = bool(Game.settings.get("invert_y", false))
		_add_setting_row("Balik Sumbu Vertikal Kamera (Invert Y)", "AKTIF" if inv_y else "NORMAL", Callable(), _toggle_bool_setting.bind("invert_y"))

	elif current_settings_tab == "hud":
		var launch_btn = Button.new()
		launch_btn.text = "BUKA EDITOR POSISI TOMBOL (GESER & UBAH UKURAN DI LAYAR)"
		launch_btn.custom_minimum_size = Vector2(786, 62)
		launch_btn.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.20, 0.52, 0.28)))
		_style_pixel_label(launch_btn, 18, Color(1, 0.98, 0.85), 5)
		launch_btn.pressed.connect(start_hud_editor)
		settings_content_box.add_child(launch_btn)

		var hs = int(round(float(Game.settings.get("hud_scale", 1.0)) * 100.0))
		_add_setting_row("Ukuran Global Tombol HUD", "%d%%" % hs, _step_float_setting.bind("hud_scale", -0.1, 0.65, 1.45), _step_float_setting.bind("hud_scale", 0.1, 0.65, 1.45))

		var ho = int(round(float(Game.settings.get("hud_opacity", 0.92)) * 100.0))
		_add_setting_row("Transparansi / Opasitas HUD", "%d%%" % ho, _step_float_setting.bind("hud_opacity", -0.1, 0.35, 1.0), _step_float_setting.bind("hud_opacity", 0.1, 0.35, 1.0))

		var rst_btn = Button.new()
		rst_btn.text = "RESET POSISI & UKURAN HUD KE STANDAR AWAL"
		rst_btn.custom_minimum_size = Vector2(786, 52)
		rst_btn.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.54, 0.20, 0.15)))
		_style_pixel_label(rst_btn, 16)
		rst_btn.pressed.connect(_on_reset_hud_pressed)
		settings_content_box.add_child(rst_btn)


# ---------- Interactive Custom HUD Layout Editor ----------

func _build_hud_editor_bar():
	hud_edit_bar = Panel.new()
	hud_edit_bar.visible = false
	hud_edit_bar.size = Vector2(820, 96)
	hud_edit_bar.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.12, 0.08, 0.04, 0.96)))
	root.add_child(hud_edit_bar)

	hud_edit_info_lbl = Label.new()
	hud_edit_info_lbl.text = "MODE CUSTOM HUD: Geser tombol/joystick dengan jari! Pilih elemen untuk ubah ukuran."
	hud_edit_info_lbl.position = Vector2(16, 8)
	hud_edit_info_lbl.size = Vector2(788, 28)
	hud_edit_info_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hud_edit_info_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(hud_edit_info_lbl, 15, Color(0.98, 0.88, 0.45), 4)
	hud_edit_bar.add_child(hud_edit_info_lbl)

	var hb = HBoxContainer.new()
	hb.position = Vector2(18, 40)
	hb.size = Vector2(784, 46)
	hb.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.add_theme_constant_override("separation", 12)
	hud_edit_bar.add_child(hb)

	var b_smaller = Button.new()
	b_smaller.text = "- PERKECIL TOMBOL"
	b_smaller.custom_minimum_size = Vector2(180, 42)
	b_smaller.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.32, 0.24, 0.16)))
	_style_pixel_label(b_smaller, 14)
	b_smaller.pressed.connect(_scale_selected_hud.bind(-0.12))
	hb.add_child(b_smaller)

	var b_larger = Button.new()
	b_larger.text = "+ PERBESAR TOMBOL"
	b_larger.custom_minimum_size = Vector2(180, 42)
	b_larger.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.24, 0.42, 0.28)))
	_style_pixel_label(b_larger, 14)
	b_larger.pressed.connect(_scale_selected_hud.bind(0.12))
	hb.add_child(b_larger)

	var b_reset = Button.new()
	b_reset.text = "RESET DEFAULT"
	b_reset.custom_minimum_size = Vector2(165, 42)
	b_reset.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.54, 0.20, 0.15)))
	_style_pixel_label(b_reset, 14)
	b_reset.pressed.connect(_on_editor_reset_pressed)
	hb.add_child(b_reset)

	var b_save = Button.new()
	b_save.text = "SIMPAN & SELESAI"
	b_save.custom_minimum_size = Vector2(195, 42)
	b_save.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.18, 0.54, 0.28)))
	_style_pixel_label(b_save, 15, Color(1, 0.98, 0.85))
	b_save.pressed.connect(stop_hud_editor)
	hb.add_child(b_save)


func start_hud_editor():
	settings_modal.visible = false
	menu.visible = false
	title_screen.visible = false
	world_select_screen.visible = false
	hud_gameplay_layer.visible = true
	hud_edit_mode = true
	Game.menu_open = true
	hud_edit_bar.visible = true
	_update_contextual_buttons()
	_update_hud_editor_label()
	Game.play_sfx("ui", 1.05, 0.85)


func stop_hud_editor():
	hud_edit_mode = false
	hud_edit_dragging = false
	hud_edit_bar.visible = false
	_update_contextual_buttons()
	Game.save_settings()
	if Game.in_world:
		Game.menu_open = false
		hud_gameplay_layer.visible = true
		show_message("Tata letak Custom HUD berhasil disimpan!")
	else:
		Game.menu_open = true
		hud_gameplay_layer.visible = false
		title_screen.visible = true
	Game.play_sfx("build", 1.1, 0.85)


func _update_hud_editor_label():
	if hud_edit_info_lbl != null:
		hud_edit_info_lbl.text = "ELEMEN TERPILIH: [%s] — Geser di layar atau tekan +/- Ukuran" % hud_edit_selected.to_upper()


func _scale_selected_hud(delta_scale):
	if not btns.has(hud_edit_selected):
		Game.settings["hud_scale"] = clamp(float(Game.settings.get("hud_scale", 1.0)) + delta_scale, 0.65, 1.45)
		_layout()
		Game.play_sfx("ui", 1.0, 0.8)
		return
	var custom = Game.settings.get("custom_hud", {})
	if not custom.has(hud_edit_selected):
		var b = btns[hud_edit_selected]
		custom[hud_edit_selected] = {
			"rx": b.position.x / max(1.0, vp.x),
			"ry": b.position.y / max(1.0, vp.y),
			"scale": float(Game.settings.get("hud_scale", 1.0)),
		}
	var cur_s = float(custom[hud_edit_selected].get("scale", Game.settings.get("hud_scale", 1.0)))
	custom[hud_edit_selected]["scale"] = clamp(cur_s + delta_scale, 0.60, 1.55)
	Game.settings["custom_hud"] = custom
	_layout()
	Game.play_sfx("ui", 1.0, 0.8)


func _handle_hud_editor_input(event):
	var pos = Vector2.ZERO
	var is_down = false
	var is_up = false
	var is_move = false

	if event is InputEventScreenTouch:
		pos = event.position
		is_down = event.pressed
		is_up = not event.pressed
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		pos = event.position
		is_down = event.pressed
		is_up = not event.pressed
	elif event is InputEventScreenDrag or event is InputEventMouseMotion:
		pos = event.position
		is_move = true
	else:
		return

	if hud_edit_bar.visible and Rect2(hud_edit_bar.position, hud_edit_bar.size).has_point(pos) and is_down:
		return

	if is_down:
		for id in btns:
			var b = btns[id]
			if b.visible and Rect2(b.position, b.size).has_point(pos):
				hud_edit_selected = id
				hud_edit_dragging = true
				hud_edit_drag_offset = pos - b.position
				_update_hud_editor_label()
				return
		if Rect2(joy_base.position, joy_base.size).has_point(pos):
			hud_edit_selected = "joystick"
			hud_edit_dragging = true
			hud_edit_drag_offset = pos - joy_home
			_update_hud_editor_label()
			return
		if Rect2(status_panel.position, status_panel.size).has_point(pos):
			hud_edit_selected = "status_panel"
			hud_edit_dragging = true
			hud_edit_drag_offset = pos - status_panel.position
			_update_hud_editor_label()
			return

	elif is_move and hud_edit_dragging:
		var custom = Game.settings.get("custom_hud", {})
		if btns.has(hud_edit_selected):
			var b = btns[hud_edit_selected]
			var np = pos - hud_edit_drag_offset
			np.x = clamp(np.x, 4.0, max(4.0, vp.x - b.size.x - 4.0))
			np.y = clamp(np.y, 4.0, max(4.0, vp.y - b.size.y - 4.0))
			b.position = np
			var prev_s = float(Game.settings.get("hud_scale", 1.0))
			if custom.has(hud_edit_selected) and custom[hud_edit_selected].has("scale"):
				prev_s = float(custom[hud_edit_selected]["scale"])
			custom[hud_edit_selected] = {"rx": np.x / max(1.0, vp.x), "ry": np.y / max(1.0, vp.y), "scale": prev_s}
		elif hud_edit_selected == "joystick":
			var np = pos - hud_edit_drag_offset
			np.x = clamp(np.x, JOY_R + 8.0, vp.x - JOY_R - 8.0)
			np.y = clamp(np.y, JOY_R + 8.0, vp.y - JOY_R - 8.0)
			joy_home = np
			_joy_idle()
			custom["joystick"] = {"rx": np.x / max(1.0, vp.x), "ry": np.y / max(1.0, vp.y)}
		elif hud_edit_selected == "status_panel":
			var np = pos - hud_edit_drag_offset
			np.x = clamp(np.x, 4.0, vp.x - status_panel.size.x - 4.0)
			np.y = clamp(np.y, 4.0, vp.y - status_panel.size.y - 4.0)
			status_panel.position = np
			custom["status_panel"] = {"rx": np.x / max(1.0, vp.x), "ry": np.y / max(1.0, vp.y)}
		Game.settings["custom_hud"] = custom

	elif is_up:
		hud_edit_dragging = false


# ---------- Layar Kalah / Mati ----------

func _build_death():
	death_panel = Panel.new()
	death_panel.visible = false
	death_panel.size = Vector2(540, 310)
	death_panel.add_theme_stylebox_override("panel", PixelUI.get_wood_panel_style(Color(0.20, 0.04, 0.04, 0.96)))
	root.add_child(death_panel)

	var l = Label.new()
	l.text = "KAMU TIDAK BERTAHAN DI LAUT..."
	l.position = Vector2(0, 36)
	l.size = Vector2(540, 56)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style_pixel_label(l, 26, Color(0.98, 0.35, 0.32), 7)
	death_panel.add_child(l)

	var b = Button.new()
	b.text = "COBA LAGI DI DUNIA INI"
	b.position = Vector2(120, 118)
	b.size = Vector2(300, 62)
	b.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.18, 0.50, 0.26)))
	_style_pixel_label(b, 19)
	b.pressed.connect(_restart)
	death_panel.add_child(b)

	var b_menu = Button.new()
	b_menu.text = "KEMBALI KE MENU UTAMA"
	b_menu.position = Vector2(120, 198)
	b_menu.size = Vector2(300, 58)
	b_menu.add_theme_stylebox_override("normal", PixelUI.get_pixel_button_style(Color(0.36, 0.22, 0.14)))
	_style_pixel_label(b_menu, 18)
	b_menu.pressed.connect(return_to_main_menu)
	death_panel.add_child(b_menu)


func _on_died():
	_release_all()
	menu.visible = false
	settings_modal.visible = false
	hud_edit_bar.visible = false
	hud_edit_mode = false
	Game.menu_open = true
	death_panel.visible = true


func _restart():
	Game.play_sfx("ui", 1.0, 0.8)
	death_panel.visible = false
	Game.reset()
	Game.save_current_world([[0, 0], [1, 0], [0, 1], [1, 1]], [])
	Game.world_loaded.emit()
	_start_loading("world", "MEMULAI ULANG DUNIA: " + Game.world_name.to_upper())
