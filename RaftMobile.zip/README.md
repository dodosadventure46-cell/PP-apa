# Raft Mobile (Godot 4.3, Android) — Pixel Art UI & Grappling Hook Update

Game survival 3D First-Person (FPS) ala **Raft** untuk Android dengan **Grappling Hook & Rope 3D**, **Pixel Art UI**, **Custom HUD Editor**, **Pengaturan Grafik**, dan **SFX Prosedural**.

## Fitur Baru pada Update Ini
- **Mekanik Grappling Hook & Tali 3D (FPS):**
  - Tangan karakter di layar FPS memegang **Kail Besi 3-Cabang (Grappling Hook)** lengkap dengan gulungan tali.
  - **Tahan & Lepas tombol `HOOK`** untuk mengisi daya lemparan (*Charge Bar*), lalu kail fisik 3D beserta tali (*3D Rope*) akan meluncur ke laut!
  - Begitu kail mengenai air atau sampah laut (*Kayu, Plastik, Besi Tua, Daun, Tong, Peti*), kail akan **mengait barang apung** dan **menariknya di atas ombak bersama tali** menuju rakit (tidak lagi terbang sendiri secara instan).
- **UI & HUD Pixel Art Bertema Raft:**
  - Panel kayu apung bergaya *pixel art*, ikon *pixel art* tajam (`TEXTURE_FILTER_NEAREST`), indikator target di *crosshair*, serta **Quick Hotbar** di bagian bawah layar untuk makan/minum cepat.
- **Menu Pengaturan (`SETELAN`), Custom HUD & Grafik:**
  - **Pengaturan Grafik:** Preset *Rendah / Sedang / Tinggi*, *Resolution Scale* (55%–100%), *Target FPS* (30/60/90/Unlimited), *Real-Time Shadows*, *Kualitas Gelombang & Buih Laut*, *Jarak Pandang*, *FOV Kamera*, dan *FPS Counter*.
  - **Custom HUD Layout Editor:** Geser posisi tombol sentuh, *joystick*, maupun panel status langsung di layar Android, ubah ukuran (*scale*) dan transparansi (*opacity*), serta simpan permanen ke `user://raft_settings.cfg`.
  - **Audio & Kontrol:** Pengaturan volume *SFX*, volume *Ambience Ombak*, sensitivitas kamera, pilihan mode *Charge / Instan Hook*, dan *Auto-Reel*.
- **Perbaikan SFX & Fitur Survival Baru:**
  - Synthesizer efek suara prosedural (`sfx.gd`) tanpa ketergantungan file audio eksternal: suara lempar *hook*, cipratan air, kaitan besi, putaran *reel* tali, *item pickup*, tusukan tombak, gigitan hiu, ketukan palu bangun rakit, dan deburan ombak.
  - Tambahan resep **Pemanggang Ikan & Daging (Grill)**, **Lentera Rakit (Penerang Malam)**, **Tali Serat**, siklus **Siang–Senja–Malam**, serta model **Hiu 3D** dengan animasi kibasan ekor.

## Cara Build APK Otomatis lewat GitHub Actions
1. Ekstrak dan upload semua isi `RaftMobile.zip` ke root repository GitHub kamu (pastikan `project.godot` dan folder `.github/workflows/build-android.yml` berada di root repo).
2. Buka tab **Actions** di repository GitHub > pilih workflow **"Build Android APK (Godot)"** > klik **Run workflow** (atau cukup *push* ke branch `main`/`master`).
3. Tunggu proses selesai (~2–3 menit), lalu unduh hasil **RaftMobile-APK** pada bagian **Artifacts** di halaman hasil *workflow*.
