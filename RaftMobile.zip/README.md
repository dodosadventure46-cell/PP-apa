# Raft Mobile (Godot 4.3, Android)

Game survival ala Raft untuk Android. Kontrol sentuh:
- Kiri layar: joystick (jalan/berenang)
- Geser kanan layar: lihat sekeliling
- AMBIL: lempar kail ke barang apung yang ditandai "+"
- TAS: inventori + crafting (Pondasi, Pancing, Tombak, Penyaring Air)
- BANGUN: mode pasang pondasi, lalu tekan PASANG (kotak hijau = boleh)
- SERANG: tusuk hiu (tombak lebih kuat). PANCING: dapat ikan
- Jatuh ke air? Dekati rakit lalu tekan LOMPAT untuk naik

## Build lewat GitHub
1. Upload semua isi zip ini ke root repo (project.godot harus di root).
2. Buka tab Actions > "Build Android APK (Godot)" > Run workflow (atau push ke main).
3. Download APK dari Artifacts (RaftMobile-APK).
